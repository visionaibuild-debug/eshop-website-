# E - SHOP | Modern Full-Stack E-Commerce & Admin Platform

E - SHOP is a modern, production-grade e-commerce application powered by React, TypeScript, Tailwind CSS, and Google Firebase (Cloud Firestore, Firebase Authentication, and Firebase Storage).

---

## Architecture Overview

The system is architected into two seamlessly integrated sections:
1. **Customer Website**:
   - **Pages**: Home, Products (with debounced search, filters, and multi-sort), Product Details (image gallery, stock indicator, related items), Categories, Search Results, Cart (with guest localStorage & user cloud sync), Checkout, Authentication (Login, Register, Password Reset, Google Sign-in), User Profile, My Orders, Order Details (order tracker timeline), About, Contact, Privacy Policy, Terms & Conditions.
   - **Features**: Live Firestore real-time listeners for instant price/stock/banner sync, dynamic position-aware banners, mobile sticky bottom navigation, skeleton loaders, and responsive toasts.
2. **Admin Panel** (`/admin`):
   - **Secure Access**: Role-based access control protecting admin endpoints; authenticated against Firebase UID & bootstrap admin list.
   - **Dashboard**: Live analytics (Total Sales, Total Orders, Pending Orders, Completed Orders, Total Products, Total Customers), revenue visualization, recent orders, inventory warnings.
   - **Product Management**: Full CRUD, image uploads, multiple gallery images, slug generation, SKU, pricing, discount, stock, tags, featured/popular toggles, publish state.
   - **Category Management**: Create, edit, image upload, active/inactive toggle, item counts.
   - **Order Management**: Search orders, filter by status (`Pending`, `Confirmed`, `Processing`, `Shipped`, `Delivered`, `Cancelled`), view full customer/shipping data, update order tracking.
   - **Banner & Ads System**: Dynamic banner placement (`home_hero`, `homepage_middle`, `bottom_advertisement`, `category_page`, `product_page`), title, subtitle, CTA text, destination URL, date ranges, active status.

---

## Admin Source Package & Standalone Deployment

The admin source code is located in `/admin` and can be built and deployed independently or as part of the unified applet.

### How to Deploy the Admin Panel Standalone:
1. **Download the Admin Source**:
   Copy or archive the repository containing `/admin` and root config files.
2. **Extract ZIP** (if archived):
   `unzip eshop-admin.zip -d eshop-admin && cd eshop-admin`
3. **Install Dependencies**:
   ```bash
   npm install
   ```
4. **Add Firebase Configuration**:
   Ensure `firebase-applet-config.json` or `.env` contains your Firebase project keys.
5. **Build**:
   ```bash
   npm run build
   ```
6. **Deploy**:
   ```bash
   firebase deploy --only hosting
   ```

---

## Bootstrapping the Admin User

The platform comes pre-configured with the owner's email (`mrokan753@gmail.com`) recognized as an administrator. 
To add additional admins:
1. Sign up or log in with the new user in Firebase Auth.
2. In Firestore, create a document in the `admins` collection with ID set to the user's `uid`:
   ```json
   {
     "email": "admin@example.com",
     "role": "super_admin",
     "createdAt": "2026-10-02T00:00:00Z"
   }
   ```
3. The security rules strictly verify both the authorized email and existence of the admin record in the `admins` collection before granting write permissions.

---

## Versioning

See `version.json` for current release version:
```json
{
  "name": "E-SHOP Admin",
  "version": "1.0.0"
}
```
