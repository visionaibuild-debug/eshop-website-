import React, { useState } from 'react';
import {
  LayoutDashboard,
  Package,
  Layers,
  ShoppingBag,
  Users,
  AlertTriangle,
  Tag,
  Megaphone,
  Star,
  Settings,
  ExternalLink,
  LogOut,
  ShieldCheck,
  Menu,
  X,
  UserCheck,
  FileCode,
  GitBranch,
  History,
  Download,
  Terminal,
} from 'lucide-react';
import { useAuth } from '../src/contexts/AuthContext';

export type AdminTab =
  | 'dashboard'
  | 'products'
  | 'categories'
  | 'orders'
  | 'customers'
  | 'stock_alerts'
  | 'coupons'
  | 'banners'
  | 'reviews'
  | 'settings'
  | 'source_manager'
  | 'source_versions'
  | 'source_changelog'
  | 'source_export';

interface AdminLayoutProps {
  currentTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
  onNavigateHome: () => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onTabChange,
  onNavigateHome,
  children,
}) => {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const mainMenuItems: { id: AdminTab; label: string; icon: any }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'categories', label: 'Categories', icon: Layers },
    { id: 'orders', label: 'Orders', icon: ShoppingBag },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'stock_alerts', label: 'Stock Alerts', icon: AlertTriangle },
    { id: 'coupons', label: 'Coupons', icon: Tag },
    { id: 'banners', label: 'Ads & Promo', icon: Megaphone },
    { id: 'reviews', label: 'Reviews', icon: Star },
    { id: 'settings', label: 'Website Settings', icon: Settings },
  ];

  const systemMenuItems: { id: AdminTab; label: string; icon: any }[] = [
    { id: 'source_manager', label: 'Source Manager', icon: FileCode },
    { id: 'source_versions', label: 'Version History', icon: GitBranch },
    { id: 'source_changelog', label: 'Change Log', icon: History },
    { id: 'source_export', label: 'Export Source', icon: Download },
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col lg:flex-row">
      {/* Mobile Top Bar */}
      <div className="lg:hidden flex items-center justify-between p-4 bg-slate-950 border-b border-slate-800 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 font-black flex items-center justify-center text-sm shadow-sm shadow-amber-500/20">
            A
          </div>
          <span className="font-extrabold text-base tracking-wider text-white">
            E - SHOP <span className="text-amber-400 font-mono text-xs">ADMIN</span>
          </span>
        </div>

        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
          aria-label="Toggle navigation"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={`${
          mobileMenuOpen ? 'fixed inset-y-0 left-0 w-72 z-50 shadow-2xl' : 'hidden'
        } lg:static lg:block lg:w-64 bg-slate-950 border-r border-slate-800 p-5 flex flex-col justify-between shrink-0 transition-all`}
      >
        <div className="space-y-5 overflow-y-auto max-h-[calc(100vh-140px)] pr-1">
          {/* Brand header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-yellow-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-md shadow-amber-500/20">
                A
              </div>
              <div>
                <h2 className="font-extrabold text-base tracking-wider text-white">
                  E - SHOP
                </h2>
                <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Admin Suite v2.0</span>
                </div>
              </div>
            </div>

            {mobileMenuOpen && (
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="lg:hidden p-1.5 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Main Navigation Links */}
          <div className="space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 px-3 block mb-1">
              Store Management
            </span>
            {mainMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                      : 'text-slate-400 hover:text-white hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* System & Updates Group */}
          <div className="space-y-1 pt-3 border-t border-slate-800/80">
            <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-cyan-400 px-3 mb-1">
              <Terminal className="w-3 h-3" />
              <span>System & Updates</span>
            </div>
            {systemMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onTabChange(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                      : 'text-slate-400 hover:text-cyan-300 hover:bg-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom links: Storefront & Logout */}
        <div className="pt-4 border-t border-slate-800 space-y-1.5">
          {user && (
            <div className="flex items-center gap-2 px-3 py-1.5 text-[11px] text-slate-400 bg-slate-900/60 rounded-lg">
              <UserCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate">{user.email}</span>
            </div>
          )}

          <button
            onClick={onNavigateHome}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-900 transition-colors"
          >
            <ExternalLink className="w-4 h-4 text-indigo-400" />
            <span>Customer Website</span>
          </button>

          <button
            onClick={logout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-rose-400 hover:bg-rose-500/10 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Log Out Admin</span>
          </button>
        </div>
      </aside>

      {/* Backdrop for mobile drawer */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Main Admin Content Body */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto max-w-7xl">
        {children}
      </main>
    </div>
  );
};
