import React, { useState } from 'react';
import { useAuth } from '../src/contexts/AuthContext';
import { AdminLayout, AdminTab } from './AdminLayout';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { AdminProductsPage } from './pages/AdminProductsPage';
import { AdminCategoriesPage } from './pages/AdminCategoriesPage';
import { AdminOrdersPage } from './pages/AdminOrdersPage';
import { AdminCustomersPage } from './pages/AdminCustomersPage';
import { AdminStockAlertsPage } from './pages/AdminStockAlertsPage';
import { AdminCouponsPage } from './pages/AdminCouponsPage';
import { AdminBannersPage } from './pages/AdminBannersPage';
import { AdminReviewsPage } from './pages/AdminReviewsPage';
import { AdminSettingsPage } from './pages/AdminSettingsPage';
import { AdminSourceManagerPage } from './pages/AdminSourceManagerPage';
import { AdminSourceVersionsPage } from './pages/AdminSourceVersionsPage';
import { AdminSourceChangeLogPage } from './pages/AdminSourceChangeLogPage';
import { AdminSourceExportPage } from './pages/AdminSourceExportPage';
import { AdminLoginPage } from './pages/AdminLoginPage';

interface AdminRootProps {
  onNavigateHome: () => void;
}

export const AdminRoot: React.FC<AdminRootProps> = ({ onNavigateHome }) => {
  const { user, isAdmin, loading } = useAuth();
  const [currentTab, setCurrentTab] = useState<AdminTab>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-300 gap-3">
        <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-semibold tracking-wider text-amber-400 uppercase">
          Verifying Admin Credentials...
        </span>
      </div>
    );
  }

  // If user is not logged in or not admin, show dedicated Admin Login Page
  if (!user || !isAdmin) {
    return <AdminLoginPage onNavigateHome={onNavigateHome} />;
  }

  return (
    <AdminLayout
      currentTab={currentTab}
      onTabChange={setCurrentTab}
      onNavigateHome={onNavigateHome}
    >
      {currentTab === 'dashboard' && (
        <AdminDashboardPage onNavigateTab={(tab) => setCurrentTab(tab)} />
      )}
      {currentTab === 'products' && <AdminProductsPage />}
      {currentTab === 'categories' && <AdminCategoriesPage />}
      {currentTab === 'orders' && <AdminOrdersPage />}
      {currentTab === 'customers' && <AdminCustomersPage />}
      {currentTab === 'stock_alerts' && <AdminStockAlertsPage />}
      {currentTab === 'coupons' && <AdminCouponsPage />}
      {currentTab === 'banners' && <AdminBannersPage />}
      {currentTab === 'reviews' && <AdminReviewsPage />}
      {currentTab === 'settings' && <AdminSettingsPage />}
      {currentTab === 'source_manager' && <AdminSourceManagerPage />}
      {currentTab === 'source_versions' && <AdminSourceVersionsPage />}
      {currentTab === 'source_changelog' && <AdminSourceChangeLogPage />}
      {currentTab === 'source_export' && <AdminSourceExportPage />}
    </AdminLayout>
  );
};
