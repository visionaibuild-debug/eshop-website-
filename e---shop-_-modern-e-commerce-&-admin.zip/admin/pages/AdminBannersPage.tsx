import React, { useState, useEffect } from 'react';
import { Banner, BannerPosition } from '../../src/types';
import {
  getBanners,
  createBanner,
  updateBanner,
  deleteBanner,
  uploadImage,
} from '../../src/firebase/services';
import { useToast } from '../../src/contexts/ToastContext';
import { Plus, Edit2, Trash2, Upload, X, Image as ImageIcon, ExternalLink } from 'lucide-react';

export const AdminBannersPage: React.FC = () => {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bannerToEdit, setBannerToEdit] = useState<Banner | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    buttonText: 'Shop Now',
    destinationUrl: '/products',
    position: 'home_hero' as BannerPosition,
    isActive: true,
    startDate: '',
    endDate: '',
    image: '',
  });

  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const { showToast } = useToast();

  const loadBanners = async () => {
    setLoading(true);
    try {
      const res = await getBanners();
      setBanners(res || []);
    } catch (err) {
      console.error('Failed to load banners:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBanners();
  }, []);

  const openModal = (b: Banner | null = null) => {
    setBannerToEdit(b);
    if (b) {
      setFormData({
        title: b.title,
        subtitle: b.subtitle || '',
        buttonText: b.buttonText || 'Discover',
        destinationUrl: b.destinationUrl || '/products',
        position: b.position,
        isActive: b.isActive,
        startDate: b.startDate ? b.startDate.slice(0, 10) : '',
        endDate: b.endDate ? b.endDate.slice(0, 10) : '',
        image: b.image,
      });
    } else {
      setFormData({
        title: '',
        subtitle: '',
        buttonText: 'Discover Now',
        destinationUrl: '/products',
        position: 'home_hero',
        isActive: true,
        startDate: '',
        endDate: '',
        image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=1600&q=80',
      });
    }
    setIsModalOpen(true);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const url = await uploadImage(file, 'banners');
      setFormData((prev) => ({ ...prev, image: url }));
      showToast('Banner image uploaded!', 'success');
    } catch (err: any) {
      showToast('Image upload failed: ' + err.message, 'error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.image.trim()) {
      showToast('Please provide a banner title and image.', 'warning');
      return;
    }

    setIsSaving(true);
    try {
      const payload = {
        title: formData.title.trim(),
        subtitle: formData.subtitle.trim() || undefined,
        buttonText: formData.buttonText.trim() || undefined,
        destinationUrl: formData.destinationUrl.trim() || '/products',
        position: formData.position,
        isActive: formData.isActive,
        startDate: formData.startDate ? new Date(formData.startDate).toISOString() : undefined,
        endDate: formData.endDate ? new Date(formData.endDate).toISOString() : undefined,
        image: formData.image.trim(),
      };

      if (bannerToEdit) {
        await updateBanner(bannerToEdit.id, payload);
        showToast('Banner updated successfully!', 'success');
      } else {
        await createBanner(payload);
        showToast('Banner created and deployed!', 'success');
      }

      setIsModalOpen(false);
      loadBanners();
    } catch (err: any) {
      showToast('Failed to save banner.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this promotional banner?')) return;
    try {
      await deleteBanner(id);
      setBanners((prev) => prev.filter((b) => b.id !== id));
      showToast('Banner removed.', 'info');
    } catch {
      showToast('Failed to delete banner.', 'error');
    }
  };

  const handleToggleActive = async (b: Banner) => {
    try {
      await updateBanner(b.id, { isActive: !b.isActive });
      setBanners((prev) =>
        prev.map((item) => (item.id === b.id ? { ...item, isActive: !item.isActive } : item))
      );
    } catch {
      showToast('Failed to toggle status.', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Banner & Advertisement System
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Control dynamic campaigns, hero sliders, and promotional slot advertisements.
          </p>
        </div>

        <button
          onClick={() => openModal()}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Banner</span>
        </button>
      </div>

      {/* Banners Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {loading ? (
          Array.from({ length: 2 }).map((_, i) => (
            <div key={i} className="h-64 bg-slate-950 rounded-3xl animate-pulse" />
          ))
        ) : banners.length === 0 ? (
          <div className="col-span-2 text-center py-12 text-slate-500 text-xs">
            <ImageIcon className="w-8 h-8 mx-auto text-slate-600 mb-2" />
            <p>No banners configured yet. Click above to create one.</p>
          </div>
        ) : (
          banners.map((ban) => (
            <div
              key={ban.id}
              className="bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-sm flex flex-col justify-between"
            >
              {/* Image banner preview */}
              <div className="relative h-44 w-full bg-slate-900">
                <img
                  src={ban.image}
                  alt={ban.title}
                  className="w-full h-full object-cover brightness-[0.7]"
                />
                <div className="absolute top-3 left-3 flex gap-2">
                  <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold bg-slate-900/80 text-amber-400 backdrop-blur-md border border-slate-700 uppercase tracking-wider">
                    {ban.position.replace('_', ' ')}
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <h4 className="font-bold text-base line-clamp-1">{ban.title}</h4>
                  {ban.subtitle && (
                    <p className="text-xs text-slate-300 line-clamp-1">{ban.subtitle}</p>
                  )}
                </div>
              </div>

              {/* Banner Details & Controls */}
              <div className="p-4 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <div className="flex items-center gap-1.5 truncate max-w-[200px]">
                    <ExternalLink className="w-3 h-3 text-indigo-400 shrink-0" />
                    <span className="truncate">{ban.destinationUrl || '/products'}</span>
                  </div>
                  <button
                    onClick={() => handleToggleActive(ban)}
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      ban.isActive
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {ban.isActive ? 'Active' : 'Disabled'}
                  </button>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <span className="text-[11px] text-slate-500">
                    Button: &ldquo;{ban.buttonText || 'Discover'}&rdquo;
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openModal(ban)}
                      className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-900 rounded-lg transition-colors"
                      title="Edit Banner"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(ban.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-colors"
                      title="Delete Banner"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Banner Create/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 sm:p-8 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">
                {bannerToEdit ? 'Edit Campaign Banner' : 'Create Campaign Banner'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Banner Heading *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Next-Gen Acoustic Clarity"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Subtitle / Subtext
                </label>
                <textarea
                  rows={2}
                  placeholder="Brief promotional teaser..."
                  value={formData.subtitle}
                  onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Placement Position *
                  </label>
                  <select
                    value={formData.position}
                    onChange={(e) =>
                      setFormData({ ...formData, position: e.target.value as BannerPosition })
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                  >
                    <option value="home_hero">Home Hero Carousel</option>
                    <option value="homepage_middle">Homepage Middle Promo</option>
                    <option value="bottom_advertisement">Bottom Advertisement</option>
                    <option value="category_page">Category Header</option>
                    <option value="product_page">Product Page Ad</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Button Text</label>
                  <input
                    type="text"
                    value={formData.buttonText}
                    onChange={(e) => setFormData({ ...formData, buttonText: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Destination URL
                </label>
                <input
                  type="text"
                  placeholder="/products?featured=true"
                  value={formData.destinationUrl}
                  onChange={(e) => setFormData({ ...formData, destinationUrl: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none font-mono"
                />
              </div>

              {/* Image */}
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Banner Image URL or Upload *
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                  />
                  <label className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl cursor-pointer flex items-center gap-1 font-semibold shrink-0">
                    <Upload className="w-3.5 h-3.5 text-amber-400" />
                    <span>Upload</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Start Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    End Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white outline-none"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 pt-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500"
                />
                <span className="font-semibold text-slate-200">Banner is Active</span>
              </label>

              <div className="pt-4 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving || isUploading}
                  className="px-5 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition-all disabled:opacity-50"
                >
                  {isSaving ? 'Saving...' : 'Deploy Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
