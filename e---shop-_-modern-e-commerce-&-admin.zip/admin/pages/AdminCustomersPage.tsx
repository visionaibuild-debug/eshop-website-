import React, { useState, useEffect } from 'react';
import { CustomerSummary, Order } from '../../src/types';
import { getAllCustomers, getAllOrders } from '../../src/firebase/services';
import { useToast } from '../../src/contexts/ToastContext';
import { Search, Users, Mail, Phone, Calendar, ShoppingBag, DollarSign, X, MapPin } from 'lucide-react';

export const AdminCustomersPage: React.FC = () => {
  const [customers, setCustomers] = useState<CustomerSummary[]>([]);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerSummary | null>(null);

  const { showToast } = useToast();

  const loadData = async () => {
    setLoading(true);
    try {
      const [custs, ords] = await Promise.all([getAllCustomers(), getAllOrders()]);
      setCustomers(custs || []);
      setAllOrders(ords || []);
    } catch (err) {
      console.error('Failed to load customers:', err);
      showToast('Could not load customer profiles.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const filtered = customers.filter(
    (c) =>
      c.displayName.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search)
  );

  const customerOrders = selectedCustomer
    ? allOrders.filter(
        (o) =>
          (selectedCustomer.uid && o.userId === selectedCustomer.uid) ||
          o.customerEmail.toLowerCase() === selectedCustomer.email.toLowerCase()
      )
    : [];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Customer Directory
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Browse buyer accounts, purchase histories, and lifetime store spending.
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <input
          type="text"
          placeholder="Search by customer name, email address, or phone..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-amber-500 outline-none"
        />
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
      </div>

      {/* Customers Table */}
      <div className="bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-8 space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-12 bg-slate-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            <Users className="w-8 h-8 mx-auto text-slate-600 mb-2" />
            <p>No customers found matching your search.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/40">
                  <th className="py-3.5 px-4">Customer</th>
                  <th className="py-3.5 px-4">Contact</th>
                  <th className="py-3.5 px-4">Registered Date</th>
                  <th className="py-3.5 px-4">Total Orders</th>
                  <th className="py-3.5 px-4">Total Spent</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filtered.map((cust) => (
                  <tr key={cust.uid} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0 border border-slate-700">
                          {cust.displayName.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-bold text-white">{cust.displayName}</p>
                          <p className="text-[11px] text-slate-400 font-mono">
                            ID: {cust.uid.slice(0, 10)}...
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 space-y-0.5">
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <Mail className="w-3.5 h-3.5 text-slate-500" />
                        <span>{cust.email}</span>
                      </div>
                      {cust.phone && cust.phone !== 'N/A' && (
                        <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                          <Phone className="w-3 h-3 text-slate-500" />
                          <span>{cust.phone}</span>
                        </div>
                      )}
                    </td>

                    <td className="py-3 px-4 text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{new Date(cust.registrationDate).toLocaleDateString()}</span>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-semibold text-slate-300">
                      <div className="flex items-center gap-1.5">
                        <ShoppingBag className="w-3.5 h-3.5 text-indigo-400" />
                        <span>{cust.totalOrders} {cust.totalOrders === 1 ? 'order' : 'orders'}</span>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-bold text-emerald-400 text-sm">
                        ${cust.totalSpent.toFixed(2)}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedCustomer(cust)}
                        className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-amber-400 hover:text-amber-300 text-xs font-semibold border border-slate-800 transition-colors"
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Customer Details Modal */}
      {selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-bold text-lg">
                  {selectedCustomer.displayName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {selectedCustomer.displayName}
                  </h3>
                  <p className="text-xs text-slate-400">{selectedCustomer.email}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedCustomer(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Total Lifetime Spend</span>
                <span className="text-xl font-black text-emerald-400">
                  ${selectedCustomer.totalSpent.toFixed(2)}
                </span>
              </div>
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Completed Orders</span>
                <span className="text-xl font-black text-indigo-400">
                  {selectedCustomer.totalOrders}
                </span>
              </div>
            </div>

            {/* Address & Contact */}
            <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-xs">
              <p className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                Customer Information
              </p>
              <div className="space-y-1 text-slate-300">
                <p><span className="text-slate-500">Phone:</span> {selectedCustomer.phone || 'Not specified'}</p>
                {selectedCustomer.address && (
                  <p><span className="text-slate-500">Address:</span> {selectedCustomer.address}</p>
                )}
                {selectedCustomer.city && (
                  <p><span className="text-slate-500">City / Region:</span> {selectedCustomer.city}</p>
                )}
                <p><span className="text-slate-500">Member Since:</span> {new Date(selectedCustomer.registrationDate).toLocaleDateString()}</p>
              </div>
            </div>

            {/* Order History */}
            <div className="space-y-3 text-xs">
              <h4 className="font-bold text-slate-300">Recent Purchase History ({customerOrders.length})</h4>
              {customerOrders.length === 0 ? (
                <p className="text-slate-500 text-xs italic">No orders found for this customer.</p>
              ) : (
                <div className="divide-y divide-slate-800/80 max-h-48 overflow-y-auto pr-1">
                  {customerOrders.map((ord) => (
                    <div key={ord.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <p className="font-bold text-white font-mono">#{ord.orderNumber}</p>
                        <p className="text-[11px] text-slate-500">
                          {new Date(ord.createdAt).toLocaleDateString()} • {ord.items.length} items
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-emerald-400 block">
                          ${ord.totalAmount.toFixed(2)}
                        </span>
                        <span className="text-[10px] text-amber-400 font-semibold">
                          {ord.orderStatus}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
