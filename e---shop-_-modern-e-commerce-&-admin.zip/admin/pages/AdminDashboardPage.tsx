import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  ShoppingBag,
  Clock,
  CheckCircle2,
  Package,
  Layers,
  AlertTriangle,
  Megaphone,
  ArrowUpRight,
  TrendingUp,
  UserCheck,
  FileCode,
  GitBranch,
} from 'lucide-react';
import {
  getAllOrders,
  getProducts,
  getCategories,
  getActiveBanners,
  getAllCustomers,
} from '../../src/firebase/services';
import {
  getSourceFiles,
  getSourceVersions,
} from '../../src/firebase/sourceManagerServices';
import { Order, Product, Category, Banner, CustomerSummary, SourceFile, SourceVersion } from '../../src/types';

interface AdminDashboardPageProps {
  onNavigateTab: (tab: any) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigateTab }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [customers, setCustomers] = useState<CustomerSummary[]>([]);
  const [sourceFiles, setSourceFiles] = useState<SourceFile[]>([]);
  const [sourceVersions, setSourceVersions] = useState<SourceVersion[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadStats() {
      try {
        const [ordersRes, prodsRes, catsRes, bansRes, custsRes, filesRes, versRes] = await Promise.all([
          getAllOrders().catch(() => []),
          getProducts().catch(() => []),
          getCategories().catch(() => []),
          getActiveBanners().catch(() => []),
          getAllCustomers().catch(() => []),
          getSourceFiles(false).catch(() => []),
          getSourceVersions().catch(() => []),
        ]);
        if (isMounted) {
          setOrders(ordersRes || []);
          setProducts(prodsRes || []);
          setCategories(catsRes || []);
          setBanners(bansRes || []);
          setCustomers(custsRes || []);
          setSourceFiles(filesRes || []);
          setSourceVersions(versRes || []);
        }
      } catch (err) {
        console.error('Error loading dashboard stats:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadStats();
    return () => {
      isMounted = false;
    };
  }, []);

  // Compute metrics
  const totalSales = orders.reduce((acc, order) => {
    return order.orderStatus !== 'Cancelled' ? acc + order.totalAmount : acc;
  }, 0);

  const totalOrdersCount = orders.length;
  const pendingOrdersCount = orders.filter((o) => o.orderStatus === 'Pending').length;
  const completedOrdersCount = orders.filter((o) => o.orderStatus === 'Delivered').length;
  const totalProductsCount = products.length;
  const totalCategoriesCount = categories.length;
  const activeBannersCount = banners.length;

  // Source Manager metrics
  const sourceFilesCount = sourceFiles.length;
  const activeRelease = sourceVersions.find((v) => v.status === 'Active');
  const activeReleaseVersion = activeRelease ? activeRelease.versionNumber : '1.2.0';
  const totalVersionsCount = sourceVersions.length;
  const lastSourceFile = sourceFiles.length > 0
    ? [...sourceFiles].sort((a, b) => new Date(b.lastModified || b.updatedAt || 0).getTime() - new Date(a.lastModified || a.updatedAt || 0).getTime())[0]
    : null;
  const currentVersionStr = lastSourceFile ? lastSourceFile.currentVersion || '1.2.0' : '1.2.0';

  // Low stock products alert (<= 5)
  const lowStockProducts = products.filter((p) => p.stock <= 5);

  const recentOrders = orders.slice(0, 5);
  const recentCustomers = customers.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Dashboard Overview
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time telemetry and order operations synced with Cloud Firestore.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={() => onNavigateTab('products')}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all"
          >
            <span>Add Product</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => onNavigateTab('orders')}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-all border border-slate-700"
          >
            <span>Fulfill Orders</span>
          </button>
        </div>
      </div>

      {/* Metrics Grid (8 Primary Cards as specified) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Total Sales */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Total Sales
            </span>
            <DollarSign className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-white">
            ${totalSales.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <div className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
            <TrendingUp className="w-3 h-3" />
            <span>Net Sales Volume</span>
          </div>
        </div>

        {/* Total Orders */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-indigo-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Total Orders
            </span>
            <ShoppingBag className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-white">{totalOrdersCount}</p>
          <span className="text-[11px] text-slate-400">All customer bookings</span>
        </div>

        {/* Pending Orders */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Pending Orders
            </span>
            <Clock className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-amber-400">{pendingOrdersCount}</p>
          <span className="text-[11px] text-amber-400/80 font-medium">Awaiting fulfillment</span>
        </div>

        {/* Completed Orders */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Completed Orders
            </span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-white">{completedOrdersCount}</p>
          <span className="text-[11px] text-slate-400">Successfully delivered</span>
        </div>

        {/* Total Products */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-violet-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Total Products
            </span>
            <Package className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-white">{totalProductsCount}</p>
          <span className="text-[11px] text-slate-400">Active catalog items</span>
        </div>

        {/* Total Categories */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-blue-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Total Categories
            </span>
            <Layers className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-white">{totalCategoriesCount}</p>
          <span className="text-[11px] text-slate-400">Taxonomy groupings</span>
        </div>

        {/* Low-stock Products */}
        <div
          onClick={() => onNavigateTab('stock_alerts')}
          className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2 cursor-pointer hover:border-amber-500/50 transition-colors"
        >
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Low-Stock Items
            </span>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-rose-400">{lowStockProducts.length}</p>
          <span className="text-[11px] text-rose-400/80 font-medium">Critical inventory alert</span>
        </div>

        {/* Active Banners */}
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Active Banners
            </span>
            <Megaphone className="w-4 h-4" />
          </div>
          <p className="text-2xl font-black text-white">{activeBannersCount}</p>
          <span className="text-[11px] text-slate-400">Promotions running</span>
        </div>
      </div>

      {/* REQUIREMENT 14: SOURCE MANAGER SUMMARY CARD */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 p-6 rounded-3xl border border-cyan-500/30 shadow-lg shadow-cyan-950/20 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="p-3.5 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shrink-0">
            <FileCode className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white tracking-tight">Source Manager & Repository</h3>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 text-[10px] font-mono font-bold border border-cyan-500/30">
                v{activeReleaseVersion}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              System code repository with immutable snapshot releases, diff comparison, and sanitized ZIP export.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Source Files</span>
            <span className="text-base font-black text-white">{sourceFilesCount}</span>
          </div>
          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Current Version</span>
            <span className="text-base font-black text-cyan-400">v{currentVersionStr}</span>
          </div>
          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Active Release</span>
            <span className="text-base font-black text-emerald-400">v{activeReleaseVersion}</span>
          </div>
          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800">
            <span className="text-slate-500 block text-[10px] font-bold uppercase">Total Versions</span>
            <span className="text-base font-black text-indigo-400">{totalVersionsCount}</span>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('source_manager')}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all shrink-0 self-start md:self-auto"
        >
          <span>Open Source Manager</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Inventory Warnings Banner */}
      {lowStockProducts.length > 0 && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <p className="text-sm font-bold text-rose-200">
                Low Inventory Warning ({lowStockProducts.length} items below minimum threshold)
              </p>
              <p className="text-xs text-rose-300/80">
                {lowStockProducts.map((p) => `${p.name} (Stock: ${p.stock})`).slice(0, 3).join(', ')}
                {lowStockProducts.length > 3 ? '...' : ''}
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab('stock_alerts')}
            className="text-xs font-bold text-rose-400 hover:text-rose-300 underline shrink-0"
          >
            Review Stock
          </button>
        </div>
      )}

      {/* Recent Orders & Recent Customers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Orders Table */}
        <div className="lg:col-span-2 bg-slate-950 p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <h3 className="font-bold text-white text-base">Recent Orders</h3>
            <button
              onClick={() => onNavigateTab('orders')}
              className="text-xs font-semibold text-amber-400 hover:text-amber-300"
            >
              View All Orders
            </button>
          </div>

          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-12 bg-slate-900 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : recentOrders.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">No orders placed yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400">
                    <th className="py-2.5 px-3">Order ID</th>
                    <th className="py-2.5 px-3">Customer</th>
                    <th className="py-2.5 px-3">Total</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentOrders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="py-3 px-3 font-mono font-bold text-slate-200">
                        #{ord.orderNumber}
                      </td>
                      <td className="py-3 px-3">
                        <p className="font-semibold text-slate-200">{ord.customerName}</p>
                        <p className="text-[11px] text-slate-500">{ord.customerPhone}</p>
                      </td>
                      <td className="py-3 px-3 font-bold text-white">
                        ${ord.totalAmount.toFixed(2)}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            ord.orderStatus === 'Delivered'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : ord.orderStatus === 'Pending'
                              ? 'bg-amber-500/20 text-amber-400'
                              : ord.orderStatus === 'Cancelled'
                              ? 'bg-rose-500/20 text-rose-400'
                              : 'bg-indigo-500/20 text-indigo-400'
                          }`}
                        >
                          {ord.orderStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Recent Customers List */}
        <div className="bg-slate-950 p-6 rounded-3xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <h3 className="font-bold text-white text-base">Recent Customers</h3>
            <button
              onClick={() => onNavigateTab('customers')}
              className="text-xs font-semibold text-amber-400 hover:text-amber-300"
            >
              All Customers
            </button>
          </div>

          <div className="space-y-3">
            {recentCustomers.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">No customer profiles recorded yet.</p>
            ) : (
              recentCustomers.map((cust) => (
                <div
                  key={cust.uid}
                  className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-900 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 text-xs font-bold shrink-0">
                    <UserCheck className="w-4 h-4 text-amber-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-200 truncate">
                      {cust.displayName}
                    </p>
                    <p className="text-[11px] text-slate-500 truncate">{cust.email}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-emerald-400">
                      ${cust.totalSpent.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-slate-500 block">
                      {cust.totalOrders} {cust.totalOrders === 1 ? 'order' : 'orders'}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
