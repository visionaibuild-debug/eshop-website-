import React, { useState, useEffect } from 'react';
import { Order, OrderStatus } from '../../src/types';
import { getAllOrders, updateOrderStatus } from '../../src/firebase/services';
import { useToast } from '../../src/contexts/ToastContext';
import {
  Search,
  Filter,
  Eye,
  CheckCircle2,
  Clock,
  Truck,
  Package,
  X,
  MapPin,
  CreditCard,
  User,
} from 'lucide-react';

export const AdminOrdersPage: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const { showToast } = useToast();

  const loadOrders = async () => {
    setLoading(true);
    try {
      const res = await getAllOrders();
      setOrders(res || []);
    } catch (err) {
      console.error('Failed to load admin orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const handleStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    try {
      await updateOrderStatus(orderId, newStatus);
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, orderStatus: newStatus } : o))
      );
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder((prev) => (prev ? { ...prev, orderStatus: newStatus } : null));
      }
      showToast(`Order status updated to ${newStatus}.`, 'success');
    } catch (err) {
      showToast('Failed to update order status.', 'error');
    }
  };

  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
      o.customerName.toLowerCase().includes(search.toLowerCase()) ||
      o.customerEmail.toLowerCase().includes(search.toLowerCase()) ||
      o.customerPhone.includes(search);
    const matchesStatus = statusFilter === 'All' || o.orderStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'Delivered':
        return 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      case 'Shipped':
        return 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30';
      case 'Processing':
        return 'bg-blue-500/20 text-blue-400 border border-blue-500/30';
      case 'Confirmed':
        return 'bg-violet-500/20 text-violet-400 border border-violet-500/30';
      case 'Cancelled':
        return 'bg-rose-500/20 text-rose-400 border border-rose-500/30';
      default:
        return 'bg-amber-500/20 text-amber-400 border border-amber-500/30';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Order Fulfillment Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Track customer deliveries, update fulfillment stages, and review transactions.
          </p>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search by order #, customer name, email, phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-amber-500 outline-none"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:border-amber-500 outline-none"
        >
          <option value="All">All Statuses</option>
          <option value="Pending">Pending</option>
          <option value="Confirmed">Confirmed</option>
          <option value="Processing">Processing</option>
          <option value="Shipped">Shipped</option>
          <option value="Delivered">Delivered</option>
          <option value="Cancelled">Cancelled</option>
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-8 space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 bg-slate-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            <Package className="w-8 h-8 mx-auto text-slate-600 mb-2" />
            <p>No customer orders found matching filter criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/40">
                  <th className="py-3.5 px-4">Order Reference</th>
                  <th className="py-3.5 px-4">Customer</th>
                  <th className="py-3.5 px-4">Items</th>
                  <th className="py-3.5 px-4">Total</th>
                  <th className="py-3.5 px-4">Payment</th>
                  <th className="py-3.5 px-4">Status & Update</th>
                  <th className="py-3.5 px-4 text-right">View</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-200">
                      #{order.orderNumber}
                      <span className="block text-[10px] text-slate-500 font-normal">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <p className="font-semibold text-slate-200">{order.customerName}</p>
                      <p className="text-[11px] text-slate-400">{order.customerPhone}</p>
                      <p className="text-[10px] text-slate-500">{order.customerEmail}</p>
                    </td>

                    <td className="py-3 px-4 text-slate-300">
                      {order.items.length} {order.items.length === 1 ? 'item' : 'items'}
                    </td>

                    <td className="py-3 px-4 font-bold text-white">
                      ${order.totalAmount.toFixed(2)}
                    </td>

                    <td className="py-3 px-4">
                      <span className="text-slate-300 font-medium block">
                        {order.paymentMethod}
                      </span>
                      <span
                        className={`text-[10px] font-bold ${
                          order.paymentStatus === 'Paid'
                            ? 'text-emerald-400'
                            : 'text-amber-400'
                        }`}
                      >
                        {order.paymentStatus}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <select
                        value={order.orderStatus}
                        onChange={(e) =>
                          handleStatusChange(order.id, e.target.value as OrderStatus)
                        }
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold outline-none cursor-pointer ${getStatusColor(
                          order.orderStatus
                        )}`}
                      >
                        <option value="Pending" className="bg-slate-900 text-amber-400">
                          Pending
                        </option>
                        <option value="Confirmed" className="bg-slate-900 text-violet-400">
                          Confirmed
                        </option>
                        <option value="Processing" className="bg-slate-900 text-blue-400">
                          Processing
                        </option>
                        <option value="Shipped" className="bg-slate-900 text-indigo-400">
                          Shipped
                        </option>
                        <option value="Delivered" className="bg-slate-900 text-emerald-400">
                          Delivered
                        </option>
                        <option value="Cancelled" className="bg-slate-900 text-rose-400">
                          Cancelled
                        </option>
                      </select>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => setSelectedOrder(order)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors"
                        title="View Full Order Details"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl p-6 sm:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <span className="text-xs text-amber-400 font-mono font-bold">
                  #{selectedOrder.orderNumber}
                </span>
                <h3 className="text-lg font-bold text-white">Order Details & Tracking</h3>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Status Bar */}
            <div className="flex items-center justify-between p-4 bg-slate-950 rounded-2xl border border-slate-800">
              <span className="text-xs text-slate-400 font-semibold">Change Order Status:</span>
              <select
                value={selectedOrder.orderStatus}
                onChange={(e) =>
                  handleStatusChange(selectedOrder.id, e.target.value as OrderStatus)
                }
                className={`px-3 py-1.5 rounded-xl text-xs font-bold ${getStatusColor(
                  selectedOrder.orderStatus
                )}`}
              >
                <option value="Pending" className="bg-slate-900 text-amber-400">Pending</option>
                <option value="Confirmed" className="bg-slate-900 text-violet-400">Confirmed</option>
                <option value="Processing" className="bg-slate-900 text-blue-400">Processing</option>
                <option value="Shipped" className="bg-slate-900 text-indigo-400">Shipped</option>
                <option value="Delivered" className="bg-slate-900 text-emerald-400">Delivered</option>
                <option value="Cancelled" className="bg-slate-900 text-rose-400">Cancelled</option>
              </select>
            </div>

            {/* Customer & Address */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-slate-300 font-bold mb-2">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  <span>Customer Contact</span>
                </div>
                <p className="font-semibold text-white">{selectedOrder.customerName}</p>
                <p className="text-slate-400">{selectedOrder.customerEmail}</p>
                <p className="text-slate-400">{selectedOrder.customerPhone}</p>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-1.5">
                <div className="flex items-center gap-1.5 text-slate-300 font-bold mb-2">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>Delivery Address</span>
                </div>
                <p className="text-slate-300">{selectedOrder.shippingAddress}</p>
                <p className="text-slate-400">{selectedOrder.area}, {selectedOrder.city}</p>
                {selectedOrder.deliveryNotes && (
                  <p className="text-slate-500 italic mt-1">&ldquo;{selectedOrder.deliveryNotes}&rdquo;</p>
                )}
              </div>
            </div>

            {/* Line Items */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Order Items ({selectedOrder.items.length})
              </h4>
              <div className="divide-y divide-slate-800/80 max-h-48 overflow-y-auto pr-1">
                {selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-10 h-10 rounded-lg object-cover border border-slate-800"
                      />
                      <div>
                        <p className="font-semibold text-white truncate max-w-xs">{item.name}</p>
                        <p className="text-[11px] text-slate-400 font-mono">
                          SKU: {item.sku} • Qty: {item.quantity}
                        </p>
                      </div>
                    </div>
                    <span className="font-bold text-white">
                      ${((item.discountPrice ?? item.price) * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Summary */}
            <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs">
              <div className="text-slate-400">
                Payment: <span className="text-white font-medium">{selectedOrder.paymentMethod}</span> ({selectedOrder.paymentStatus})
              </div>
              <div className="text-right">
                <span className="text-slate-400 block text-[11px]">Total Paid</span>
                <span className="text-lg font-black text-amber-400">
                  ${selectedOrder.totalAmount.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
