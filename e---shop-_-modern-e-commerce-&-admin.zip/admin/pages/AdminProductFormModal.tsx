import React, { useState, useEffect } from 'react';
import { Product, Category } from '../../src/types';
import { uploadImage, createProduct, updateProduct } from '../../src/firebase/services';
import { useToast } from '../../src/contexts/ToastContext';
import { X, Upload, Plus, Trash2 } from 'lucide-react';

interface AdminProductFormModalProps {
  productToEdit: Product | null;
  categories: Category[];
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminProductFormModal: React.FC<AdminProductFormModalProps> = ({
  productToEdit,
  categories,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    shortDescription: '',
    price: 0,
    discountPrice: 0,
    stock: 10,
    sku: '',
    category: '',
    subcategory: '',
    brand: '',
    mainImage: '',
    images: [] as string[],
    tags: [] as string[],
    isPublished: true,
    isFeatured: false,
    isPopular: false,
  });

  const [tagInput, setTagInput] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (productToEdit) {
      setFormData({
        name: productToEdit.name || '',
        slug: productToEdit.slug || '',
        description: productToEdit.description || '',
        shortDescription: productToEdit.shortDescription || '',
        price: productToEdit.price || 0,
        discountPrice: productToEdit.discountPrice || 0,
        stock: productToEdit.stock || 0,
        sku: productToEdit.sku || '',
        category: productToEdit.category || (categories[0]?.name ?? 'General'),
        subcategory: productToEdit.subcategory || '',
        brand: productToEdit.brand || '',
        mainImage: productToEdit.mainImage || '',
        images: productToEdit.images || [],
        tags: productToEdit.tags || [],
        isPublished: productToEdit.isPublished ?? true,
        isFeatured: productToEdit.isFeatured ?? false,
        isPopular: productToEdit.isPopular ?? false,
      });
    } else {
      setFormData({
        name: '',
        slug: '',
        description: '',
        shortDescription: '',
        price: 99,
        discountPrice: 0,
        stock: 20,
        sku: `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
        category: categories[0]?.name || 'Premium Audio',
        subcategory: '',
        brand: '',
        mainImage: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
        images: [],
        tags: [],
        isPublished: true,
        isFeatured: false,
        isPopular: false,
      });
    }
  }, [productToEdit, categories]);

  if (!isOpen) return null;

  // Auto slug generation on name change
  const handleNameChange = (name: string) => {
    const slug = name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
    setFormData((prev) => ({
      ...prev,
      name,
      slug: productToEdit ? prev.slug : slug,
    }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, isGallery: boolean = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const url = await uploadImage(file, 'products');
      if (isGallery) {
        setFormData((prev) => ({ ...prev, images: [...prev.images, url] }));
      } else {
        setFormData((prev) => ({ ...prev, mainImage: url }));
      }
      showToast('Image uploaded successfully!', 'success');
    } catch (err: any) {
      showToast('Failed to upload image: ' + err.message, 'error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim().toLowerCase())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...prev.tags, tagInput.trim().toLowerCase()],
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((t) => t !== tag),
    }));
  };

  const handleRemoveGalleryImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, idx) => idx !== index),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name.trim() || !formData.slug.trim() || !formData.mainImage.trim()) {
      showToast('Please provide product name, slug, and main image.', 'warning');
      return;
    }

    setIsSaving(true);
    try {
      const payload = {
        name: formData.name.trim(),
        slug: formData.slug.trim(),
        description: formData.description.trim(),
        shortDescription: formData.shortDescription.trim(),
        price: Number(formData.price),
        discountPrice: formData.discountPrice ? Number(formData.discountPrice) : undefined,
        stock: Number(formData.stock),
        sku: formData.sku.trim() || `SKU-${Date.now().toString().slice(-4)}`,
        category: formData.category || 'General',
        subcategory: formData.subcategory.trim() || undefined,
        brand: formData.brand.trim() || 'Generic',
        mainImage: formData.mainImage.trim(),
        images: formData.images,
        tags: formData.tags,
        isPublished: formData.isPublished,
        isFeatured: formData.isFeatured,
        isPopular: formData.isPopular,
      };

      if (productToEdit) {
        await updateProduct(productToEdit.id, payload);
        showToast('Product updated successfully!', 'success');
      } else {
        await createProduct(payload);
        showToast('New product created successfully!', 'success');
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Failed to save product:', err);
      showToast('Failed to save product. Check permissions.', 'error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl animate-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 shrink-0">
          <div>
            <h2 className="text-xl font-bold text-white">
              {productToEdit ? 'Edit Product' : 'Add New Product'}
            </h2>
            <p className="text-xs text-slate-400">
              Create or modify product specifications in Cloud Firestore.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Basic Info */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider">
              1. Basic Information
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Product Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Wireless Audio Headphones"
                  value={formData.name}
                  onChange={(e) => handleNameChange(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">URL Slug *</label>
                <input
                  type="text"
                  required
                  placeholder="wireless-audio-headphones"
                  value={formData.slug}
                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Category *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                  {categories.length === 0 && <option value="General">General</option>}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Subcategory</label>
                <input
                  type="text"
                  placeholder="e.g. Over-Ear"
                  value={formData.subcategory}
                  onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Brand *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sony, Apple, Aura"
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Pricing & Inventory */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider">
              2. Pricing & Inventory
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Base Price ($) *</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Discount Price ($)</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="Leave 0 if none"
                  value={formData.discountPrice}
                  onChange={(e) =>
                    setFormData({ ...formData, discountPrice: Number(e.target.value) })
                  }
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Stock Quantity *</label>
                <input
                  type="number"
                  required
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: Number(e.target.value) })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">SKU Number</label>
                <input
                  type="text"
                  placeholder="AUR-001"
                  value={formData.sku}
                  onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none font-mono"
                />
              </div>
            </div>
          </div>

          {/* Descriptions */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider">
              3. Descriptions & Details
            </h3>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Short Description (Card preview)
              </label>
              <input
                type="text"
                placeholder="Brief one-line summary..."
                value={formData.shortDescription}
                onChange={(e) => setFormData({ ...formData, shortDescription: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Full Description (Markdown / Detailed specs) *
              </label>
              <textarea
                rows={4}
                required
                placeholder="Full product overview, features, and specs..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
              />
            </div>

            {/* Tags */}
            <div>
              <label className="text-slate-300 font-semibold block mb-1">Product Tags</label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  placeholder="Add tag (e.g. bluetooth, wireless)"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddTag();
                    }
                  }}
                  className="flex-1 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />
                <button
                  type="button"
                  onClick={handleAddTag}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl"
                >
                  Add
                </button>
              </div>

              <div className="flex flex-wrap gap-1.5">
                {formData.tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300"
                  >
                    #{tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="text-slate-500 hover:text-rose-400"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Images Section */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider">
              4. Media & Product Photos
            </h3>

            {/* Main Image */}
            <div>
              <label className="text-slate-300 font-semibold block mb-1">
                Main Image URL or Upload *
              </label>
              <div className="flex gap-3 items-center">
                <input
                  type="text"
                  required
                  placeholder="https://..."
                  value={formData.mainImage}
                  onChange={(e) => setFormData({ ...formData, mainImage: e.target.value })}
                  className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-amber-500 outline-none"
                />

                <label className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl cursor-pointer inline-flex items-center gap-1.5 shrink-0 font-semibold">
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>Upload File</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, false)}
                    className="hidden"
                  />
                </label>
              </div>

              {formData.mainImage && (
                <div className="mt-3 w-20 h-20 rounded-xl overflow-hidden border border-slate-800">
                  <img
                    src={formData.mainImage}
                    alt="Main preview"
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
            </div>

            {/* Gallery Images */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-slate-300 font-semibold">Additional Gallery Images</label>
                <label className="text-xs text-amber-400 hover:text-amber-300 cursor-pointer flex items-center gap-1">
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Gallery Image</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload(e, true)}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="flex flex-wrap gap-2">
                {formData.images.map((img, idx) => (
                  <div key={idx} className="relative w-16 h-16 rounded-xl overflow-hidden border border-slate-800 group">
                    <img src={img} alt={`Gallery ${idx}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => handleRemoveGalleryImage(idx)}
                      className="absolute inset-0 bg-slate-950/70 text-rose-400 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Visibility and Status Toggles */}
          <div className="space-y-3 pt-4 border-t border-slate-800">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider mb-2">
              5. Publishing State
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.isPublished}
                  onChange={(e) => setFormData({ ...formData, isPublished: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                />
                <span className="font-semibold text-slate-200">Published to Store</span>
              </label>

              <label className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.isFeatured}
                  onChange={(e) => setFormData({ ...formData, isFeatured: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                />
                <span className="font-semibold text-slate-200">Featured Badge</span>
              </label>

              <label className="flex items-center gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.isPopular}
                  onChange={(e) => setFormData({ ...formData, isPopular: e.target.checked })}
                  className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                />
                <span className="font-semibold text-slate-200">Popular / Trending</span>
              </label>
            </div>
          </div>

          {/* Modal Actions */}
          <div className="pt-6 border-t border-slate-800 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-semibold hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving || isUploading}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all disabled:opacity-50"
            >
              {isSaving ? 'Saving...' : productToEdit ? 'Save Changes' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
