import React, { useState, useEffect } from 'react';
import { Product, Category } from '../../src/types';
import {
  getProducts,
  getCategories,
  deleteProduct,
  updateProduct,
} from '../../src/firebase/services';
import { AdminProductFormModal } from './AdminProductFormModal';
import { useToast } from '../../src/contexts/ToastContext';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Sparkles,
  TrendingUp,
  AlertCircle,
} from 'lucide-react';

export const AdminProductsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);

  // Delete confirmation
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const { showToast } = useToast();

  const loadData = async () => {
    setLoading(true);
    try {
      const [prodRes, catRes] = await Promise.all([getProducts(), getCategories()]);
      setProducts(prodRes || []);
      setCategories(catRes || []);
    } catch (err) {
      console.error('Error fetching admin products:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleTogglePublish = async (prod: Product) => {
    try {
      await updateProduct(prod.id, { isPublished: !prod.isPublished });
      setProducts((prev) =>
        prev.map((p) => (p.id === prod.id ? { ...p, isPublished: !p.isPublished } : p))
      );
      showToast(
        `Product ${!prod.isPublished ? 'published to store' : 'hidden from store'}.`,
        'success'
      );
    } catch {
      showToast('Failed to update status.', 'error');
    }
  };

  const handleToggleFeatured = async (prod: Product) => {
    try {
      await updateProduct(prod.id, { isFeatured: !prod.isFeatured });
      setProducts((prev) =>
        prev.map((p) => (p.id === prod.id ? { ...p, isFeatured: !p.isFeatured } : p))
      );
    } catch {
      showToast('Failed to toggle featured.', 'error');
    }
  };

  const handleTogglePopular = async (prod: Product) => {
    try {
      await updateProduct(prod.id, { isPopular: !prod.isPopular });
      setProducts((prev) =>
        prev.map((p) => (p.id === prod.id ? { ...p, isPopular: !p.isPopular } : p))
      );
    } catch {
      showToast('Failed to toggle popular.', 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteProduct(id);
      setProducts((prev) => prev.filter((p) => p.id !== id));
      setDeleteConfirmId(null);
      showToast('Product deleted from Firestore.', 'info');
    } catch {
      showToast('Failed to delete product.', 'error');
    }
  };

  const filtered = products.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku?.toLowerCase().includes(search.toLowerCase()) ||
      p.brand?.toLowerCase().includes(search.toLowerCase());
    const matchesCat =
      selectedCategory === 'All' ||
      p.category?.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Product Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Manage your store inventory, pricing, images, and live visibility.
          </p>
        </div>

        <button
          onClick={() => {
            setProductToEdit(null);
            setIsModalOpen(true);
          }}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search by title, SKU, brand..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-amber-500 outline-none"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:border-amber-500 outline-none"
        >
          <option value="All">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.name}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      {/* Products Table */}
      <div className="bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-8 space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 bg-slate-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs space-y-2">
            <AlertCircle className="w-6 h-6 mx-auto text-slate-600" />
            <p>No products found matching criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/40">
                  <th className="py-3.5 px-4">Item</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Price</th>
                  <th className="py-3.5 px-4">Stock</th>
                  <th className="py-3.5 px-4">Attributes</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filtered.map((prod) => (
                  <tr key={prod.id} className="hover:bg-slate-900/60 transition-colors">
                    {/* Item Image & Title */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={prod.mainImage}
                          alt={prod.name}
                          className="w-11 h-11 rounded-xl object-cover border border-slate-800 shrink-0"
                        />
                        <div className="max-w-xs">
                          <p className="font-bold text-slate-200 line-clamp-1">{prod.name}</p>
                          <p className="text-[11px] text-slate-400 font-mono">
                            {prod.sku} • {prod.brand}
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-3 px-4 text-slate-300 font-medium">
                      {prod.category}
                    </td>

                    {/* Price */}
                    <td className="py-3 px-4">
                      <span className="font-bold text-white">
                        ${(prod.discountPrice ?? prod.price).toFixed(2)}
                      </span>
                      {prod.discountPrice && (
                        <span className="block text-[10px] text-slate-500 line-through">
                          ${prod.price.toFixed(2)}
                        </span>
                      )}
                    </td>

                    {/* Stock */}
                    <td className="py-3 px-4">
                      <span
                        className={`font-semibold ${
                          prod.stock <= 0
                            ? 'text-rose-400'
                            : prod.stock <= 5
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {prod.stock} units
                      </span>
                    </td>

                    {/* Attributes Toggles */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleToggleFeatured(prod)}
                          title="Toggle Featured"
                          className={`p-1.5 rounded-lg transition-colors ${
                            prod.isFeatured
                              ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                              : 'text-slate-600 hover:text-slate-400'
                          }`}
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleTogglePopular(prod)}
                          title="Toggle Popular"
                          className={`p-1.5 rounded-lg transition-colors ${
                            prod.isPopular
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'text-slate-600 hover:text-slate-400'
                          }`}
                        >
                          <TrendingUp className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      <button
                        onClick={() => handleTogglePublish(prod)}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          prod.isPublished
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {prod.isPublished ? (
                          <>
                            <Eye className="w-3 h-3" />
                            <span>Live</span>
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3 h-3" />
                            <span>Draft</span>
                          </>
                        )}
                      </button>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setProductToEdit(prod);
                            setIsModalOpen(true);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition-colors"
                          title="Edit Product"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => setDeleteConfirmId(prod.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                          title="Delete Product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl max-w-sm w-full space-y-4 shadow-2xl">
            <h3 className="font-bold text-white text-base">Delete Product?</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Are you sure you want to permanently delete this product from Cloud Firestore? This action cannot be undone.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="flex-1 py-2 rounded-xl border border-slate-700 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmId)}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Form Modal */}
      <AdminProductFormModal
        isOpen={isModalOpen}
        productToEdit={productToEdit}
        categories={categories}
        onClose={() => setIsModalOpen(false)}
        onSuccess={loadData}
      />
    </div>
  );
};
