import React, { useState, useEffect } from 'react';
import {
  History,
  Search,
  Filter,
  PlusCircle,
  Edit2,
  Trash2,
  RotateCcw,
  Calendar,
  User,
  FileCode,
  X,
  Code2,
} from 'lucide-react';
import { SourceChangeLogEntry } from '../../src/types';
import { getSourceChangeLogs } from '../../src/firebase/sourceManagerServices';

export const AdminSourceChangeLogPage: React.FC = () => {
  const [logs, setLogs] = useState<SourceChangeLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('all');

  // Diff inspection modal
  const [selectedLog, setSelectedLog] = useState<SourceChangeLogEntry | null>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const data = await getSourceChangeLogs();
        setLogs(data || []);
      } catch (err) {
        console.error('Failed to load changelog:', err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filteredLogs = logs.filter((log) => {
    const s = search.toLowerCase();
    const matchesSearch =
      (log.file || '').toLowerCase().includes(s) ||
      (log.description || '').toLowerCase().includes(s) ||
      (log.changedBy || '').toLowerCase().includes(s) ||
      (log.version || '').toLowerCase().includes(s);
    const matchesAction = actionFilter === 'all' || log.action === actionFilter;
    return matchesSearch && matchesAction;
  });

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'Added':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <PlusCircle className="w-3 h-3" />
            <span>Added</span>
          </span>
        );
      case 'Updated':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Edit2 className="w-3 h-3" />
            <span>Updated</span>
          </span>
        );
      case 'Deleted':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
            <Trash2 className="w-3 h-3" />
            <span>Deleted</span>
          </span>
        );
      case 'Restored':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <RotateCcw className="w-3 h-3" />
            <span>Restored</span>
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400">
            {action}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Source Audit Trail & Change Log
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Immutable audit records tracking every file addition, code modification, version snapshot, and restoration.
          </p>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search change log by file path, description, administrator email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-cyan-500 outline-none font-mono"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-300 focus:border-cyan-500 outline-none"
        >
          <option value="all">All Actions ({logs.length})</option>
          <option value="Added">Added</option>
          <option value="Updated">Updated</option>
          <option value="Deleted">Deleted / Archived</option>
          <option value="Restored">Restored</option>
        </select>
      </div>

      {/* Change Log Table */}
      <div className="bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-sm">
        {loading ? (
          <div className="p-8 space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-12 bg-slate-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="text-center py-14 text-slate-500 text-xs space-y-2">
            <History className="w-8 h-8 mx-auto text-slate-600 mb-1" />
            <p>No audit trail records match criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/40">
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Action</th>
                  <th className="py-3.5 px-4">Version</th>
                  <th className="py-3.5 px-4">File / Target</th>
                  <th className="py-3.5 px-4">Modified By</th>
                  <th className="py-3.5 px-4">Change Description</th>
                  <th className="py-3.5 px-4 text-right">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {filteredLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3.5 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                      {new Date(log.date).toLocaleString()}
                    </td>

                    <td className="py-3.5 px-4">
                      {getActionBadge(log.action)}
                    </td>

                    <td className="py-3.5 px-4 text-cyan-400 font-bold">
                      v{log.version}
                    </td>

                    <td className="py-3.5 px-4 font-semibold text-white max-w-xs truncate">
                      {log.file}
                    </td>

                    <td className="py-3.5 px-4 text-slate-400 text-[11px] truncate max-w-xs font-sans">
                      {log.changedBy}
                    </td>

                    <td className="py-3.5 px-4 text-slate-300 font-sans max-w-sm">
                      <p className="line-clamp-2 leading-relaxed">{log.description}</p>
                    </td>

                    <td className="py-3.5 px-4 text-right font-sans">
                      {(log.previousCode || log.newCode) ? (
                        <button
                          onClick={() => setSelectedLog(log)}
                          className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-cyan-400 text-xs font-semibold border border-slate-800 transition-colors"
                        >
                          View Diff
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-600">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Audit Diff Modal */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl p-6 sm:p-8 space-y-5 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-white text-base">
                  Audit Snapshot: {selectedLog.file} (v{selectedLog.version})
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Logged on {new Date(selectedLog.date).toLocaleString()} by {selectedLog.changedBy}
                </p>
              </div>
              <button
                onClick={() => setSelectedLog(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl text-xs text-slate-300">
              <span className="text-slate-500 font-bold block mb-1">Description:</span>
              <p>{selectedLog.description}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              <div className="space-y-1">
                <span className="text-slate-400 font-bold">Previous Code:</span>
                <pre className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-400 max-h-80 overflow-auto whitespace-pre leading-5">
                  {selectedLog.previousCode || '// No previous code recorded'}
                </pre>
              </div>

              <div className="space-y-1">
                <span className="text-cyan-400 font-bold">Updated Code:</span>
                <pre className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 text-cyan-200 max-h-80 overflow-auto whitespace-pre leading-5">
                  {selectedLog.newCode || '// No new code recorded'}
                </pre>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedLog(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
