import React, { useState, useEffect } from 'react';
import {
  Download,
  Upload,
  FileArchive,
  CheckCircle2,
  AlertTriangle,
  FolderTree,
  FileCode,
  ShieldCheck,
  X,
  FileText,
  Info,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../../src/contexts/AuthContext';
import { useToast } from '../../src/contexts/ToastContext';
import { SourceFile, SourceVersion, SourceManifest } from '../../src/types';
import {
  getSourceFiles,
  getSourceVersions,
  exportSourceZip,
  parseImportZip,
  commitSourceImportBatch,
} from '../../src/firebase/sourceManagerServices';

export const AdminSourceExportPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [files, setFiles] = useState<SourceFile[]>([]);
  const [versions, setVersions] = useState<SourceVersion[]>([]);
  const [loading, setLoading] = useState(true);

  // Export State
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccessBlob, setExportSuccessBlob] = useState<{
    blob: Blob;
    filename: string;
    version: string;
    manifest: SourceManifest;
  } | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);

  // Import State
  const [importFile, setImportFile] = useState<File | null>(null);
  const [isParsingImport, setIsParsingImport] = useState(false);
  const [importResult, setImportResult] = useState<{
    valid: boolean;
    error?: string;
    files: Array<{ fileName: string; filePath: string; fileType: string; sourceCode: string }>;
    dangerousFilesDetected: string[];
  } | null>(null);
  const [isCommittingImport, setIsCommittingImport] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [fileList, verList] = await Promise.all([getSourceFiles(false), getSourceVersions()]);
      setFiles(fileList || []);
      setVersions(verList || []);
    } catch (err) {
      console.error('Failed to load export files:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const activeRelease = versions.find((v) => v.status === 'Active')?.versionNumber || '1.2.0';

  const handleRunExport = async () => {
    if (files.length === 0) {
      showToast('No active source files available to export.', 'warning');
      return;
    }

    setIsExporting(true);
    try {
      const filename = `E-SHOP-source-v${activeRelease}.zip`;
      const blob = await exportSourceZip(files, activeRelease);

      const manifest: SourceManifest = {
        projectName: 'E-SHOP Modern E-Commerce',
        exportVersion: activeRelease,
        exportDate: new Date().toISOString(),
        applicationVersion: '2.0.0',
        includedFiles: files.map((f) => f.filePath),
        excludedFiles: ['.env', 'firebase-applet-config.json', 'serviceAccountKey.json'],
        sourceManagerVersion: '1.2.0',
      };

      setExportSuccessBlob({
        blob,
        filename,
        version: activeRelease,
        manifest,
      });

      setShowExportModal(true);
      showToast('Source archive generated successfully!', 'success');
    } catch (err: any) {
      showToast('ZIP export failed: ' + err.message, 'error');
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadZip = () => {
    if (!exportSuccessBlob) return;
    const url = URL.createObjectURL(exportSuccessBlob.blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = exportSuccessBlob.filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(`Downloaded ${exportSuccessBlob.filename}`, 'success');
  };

  // ZIP Import handler
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportFile(file);
    setIsParsingImport(true);
    try {
      const parsed = await parseImportZip(file);
      setImportResult(parsed);
      if (!parsed.valid) {
        showToast('Invalid archive: ' + (parsed.error || 'Parsing failed'), 'error');
      } else if (parsed.dangerousFilesDetected.length > 0) {
        showToast('Warning: Potentially dangerous files were filtered out.', 'warning');
      } else {
        showToast(`Parsed ${parsed.files.length} source files ready for review.`, 'info');
      }
    } catch (err: any) {
      showToast('Could not process ZIP: ' + err.message, 'error');
    } finally {
      setIsParsingImport(false);
    }
  };

  const handleConfirmImport = async () => {
    if (!importResult || importResult.files.length === 0) return;
    setIsCommittingImport(true);
    try {
      const res = await commitSourceImportBatch(importResult.files, user?.email || 'admin');
      showToast(`Successfully imported ${res.importedCount} source files into repository!`, 'success');
      setImportFile(null);
      setImportResult(null);
      loadData();
    } catch (err: any) {
      showToast('Import commitment failed: ' + err.message, 'error');
    } finally {
      setIsCommittingImport(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight">
          Source Repository Export & Import
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Package sanitized application source trees into standard ZIP archives or import external project modules.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* EXPORT SOURCE CARD */}
        <div className="bg-slate-950 rounded-3xl border border-slate-800 p-6 sm:p-8 space-y-6 flex flex-col justify-between shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <FileArchive className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Export Source Package</h2>
                <p className="text-xs text-slate-400">
                  Bundles all repository files into an archive preserving folder hierarchy.
                </p>
              </div>
            </div>

            {/* Export Summary Box */}
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span>Active Release Version:</span>
                <span className="font-mono font-bold text-cyan-400">v{activeRelease}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Files Included in Archive:</span>
                <span className="font-mono font-bold text-white">{files.length} modules</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Sanitization Policy:</span>
                <span className="font-semibold text-emerald-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Credentials Excluded
                </span>
              </div>
            </div>

            {/* Folder Structure Preview */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800/80 font-mono text-[11px] text-slate-400 space-y-1">
              <p className="text-slate-200 font-bold">E-SHOP-SOURCE/</p>
              <p className="pl-4">├── src/ (components, pages, services, types)</p>
              <p className="pl-4">├── package.json</p>
              <p className="pl-4">├── README.md</p>
              <p className="pl-4">└── source-manifest.json</p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={handleRunExport}
              disabled={isExporting || files.length === 0}
              className="w-full py-3 px-6 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Generating ZIP...' : `Export Source (v${activeRelease})`}</span>
            </button>
          </div>
        </div>

        {/* IMPORT SOURCE CARD */}
        <div className="bg-slate-950 rounded-3xl border border-slate-800 p-6 sm:p-8 space-y-6 flex flex-col justify-between shadow-sm">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Upload className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Import Source Package</h2>
                <p className="text-xs text-slate-400">
                  Upload a ZIP archive to register or update source files in batch.
                </p>
              </div>
            </div>

            {/* File Dropzone */}
            <label className="border-2 border-dashed border-slate-800 hover:border-amber-500/50 rounded-2xl p-6 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors bg-slate-900/30">
              <FileArchive className="w-8 h-8 text-slate-500" />
              <div className="text-center text-xs">
                <span className="font-semibold text-amber-400">Click to upload ZIP</span>
                <span className="text-slate-400 block mt-0.5">Maximum archive size: 25MB</span>
              </div>
              <input
                type="file"
                accept=".zip"
                onChange={handleFileSelect}
                className="hidden"
              />
            </label>

            {/* Parsed Preview if available */}
            {isParsingImport ? (
              <div className="p-4 bg-slate-900 rounded-xl text-center text-xs text-slate-400 animate-pulse">
                Parsing and inspecting ZIP entries...
              </div>
            ) : importResult && importResult.valid ? (
              <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-300 font-bold">Valid Modules Found:</span>
                  <span className="font-mono text-cyan-400 font-bold">
                    {importResult.files.length} files
                  </span>
                </div>

                {importResult.dangerousFilesDetected.length > 0 && (
                  <div className="p-2.5 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-[11px] space-y-1">
                    <p className="font-bold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Blocked Unsafe Files ({importResult.dangerousFilesDetected.length}):
                    </p>
                    <p className="font-mono truncate">{importResult.dangerousFilesDetected.join(', ')}</p>
                  </div>
                )}

                <div className="max-h-32 overflow-y-auto divide-y divide-slate-800 font-mono text-[11px] text-slate-400">
                  {importResult.files.slice(0, 10).map((f, i) => (
                    <div key={i} className="py-1 truncate">
                      {f.filePath}
                    </div>
                  ))}
                  {importResult.files.length > 10 && (
                    <div className="py-1 text-slate-500 italic">
                      + {importResult.files.length - 10} more files...
                    </div>
                  )}
                </div>
              </div>
            ) : null}
          </div>

          <div className="pt-4 border-t border-slate-800">
            <button
              onClick={handleConfirmImport}
              disabled={isCommittingImport || !importResult || !importResult.valid}
              className="w-full py-3 px-6 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md shadow-amber-500/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              <Upload className="w-4 h-4" />
              <span>
                {isCommittingImport ? 'Importing Modules...' : 'Confirm & Commit Import'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* EXPORT SUCCESS MODAL */}
      {showExportModal && exportSuccessBlob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-bold text-white">Source export completed successfully.</h3>
              <p className="text-xs text-slate-400 font-mono">
                {exportSuccessBlob.filename} ({(exportSuccessBlob.blob.size / 1024).toFixed(1)} KB)
              </p>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-2xl border border-slate-800">
              The archive includes all active repository modules and <code className="text-cyan-400">source-manifest.json</code>. Sensitive credentials and private keys are omitted by design.
            </p>

            <div className="flex flex-col gap-2 pt-2 text-xs">
              <button
                onClick={handleDownloadZip}
                className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20 transition-all flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Download ZIP</span>
              </button>

              <button
                onClick={() => setShowDetailsModal(true)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-colors"
              >
                View Export Details
              </button>

              <button
                onClick={() => setShowExportModal(false)}
                className="w-full py-2 rounded-xl text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MANIFEST DETAILS MODAL */}
      {showDetailsModal && exportSuccessBlob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-4 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 font-mono">
                <FileCode className="w-4 h-4 text-cyan-400" />
                <h3 className="font-bold text-white text-base">source-manifest.json</h3>
              </div>
              <button
                onClick={() => setShowDetailsModal(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <pre className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-mono text-cyan-200 overflow-auto max-h-96 whitespace-pre leading-relaxed">
              {JSON.stringify(exportSuccessBlob.manifest, null, 2)}
            </pre>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowDetailsModal(false)}
                className="px-5 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-semibold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
