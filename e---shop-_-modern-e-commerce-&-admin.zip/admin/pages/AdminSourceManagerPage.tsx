import React, { useState, useEffect, useRef } from 'react';
import {
  FileCode,
  Plus,
  Search,
  Edit3,
  Archive,
  RotateCcw,
  Trash2,
  Copy,
  Check,
  Eye,
  Filter,
  Code2,
  Calendar,
  User,
  GitBranch,
  X,
  FileText,
  AlertTriangle,
  RefreshCw,
  Sparkles,
  Undo2,
  Redo2,
  Replace,
} from 'lucide-react';
import { useAuth } from '../../src/contexts/AuthContext';
import { useToast } from '../../src/contexts/ToastContext';
import { SourceFile } from '../../src/types';
import {
  getSourceFiles,
  addSourceFile,
  updateSourceFile,
  archiveSourceFile,
  restoreSourceFile,
  permanentlyDeleteSourceFile,
  seedInitialSourceFilesIfEmpty,
} from '../../src/firebase/sourceManagerServices';

export const AdminSourceManagerPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [files, setFiles] = useState<SourceFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [showArchived, setShowArchived] = useState(false);

  // Active / Selected File for viewing or editing
  const [selectedFile, setSelectedFile] = useState<SourceFile | null>(null);

  // Modal State for Add / Edit
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingFile, setEditingFile] = useState<SourceFile | null>(null);

  // Form Fields
  const [fileName, setFileName] = useState('');
  const [filePath, setFilePath] = useState('');
  const [fileType, setFileType] = useState('tsx');
  const [version, setVersion] = useState('1.0.0');
  const [description, setDescription] = useState('');
  const [changeNotes, setChangeNotes] = useState('');
  const [sourceCode, setSourceCode] = useState('');
  const [isDraft, setIsDraft] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Version snapshot prompt on Edit
  const [showSnapshotDialog, setShowSnapshotDialog] = useState(false);
  const [newSnapshotVersion, setNewSnapshotVersion] = useState('');

  // Code editor search & replace in modal
  const [editorSearch, setEditorSearch] = useState('');
  const [editorReplace, setEditorReplace] = useState('');
  const [showReplaceBar, setShowReplaceBar] = useState(false);

  // History stack for undo/redo
  const [historyStack, setHistoryStack] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);

  // Copy indicator
  const [copied, setCopied] = useState(false);

  // Delete / Archive confirmation modal
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const codeTextareaRef = useRef<HTMLTextAreaElement>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      if (user?.email) {
        await seedInitialSourceFilesIfEmpty(user.email);
      }
      const data = await getSourceFiles(showArchived);
      setFiles(data || []);
      if (!selectedFile && data && data.length > 0) {
        setSelectedFile(data[0]);
      } else if (selectedFile && data) {
        const found = data.find((f) => f.id === selectedFile.id);
        setSelectedFile(found || data[0] || null);
      }
    } catch (err) {
      console.error('Failed to load source files:', err);
      showToast('Could not fetch source files from Firestore.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [showArchived]);

  // Code History Undo/Redo helper
  const handleCodeChange = (newVal: string) => {
    setSourceCode(newVal);
    const newStack = historyStack.slice(0, historyIndex + 1);
    newStack.push(newVal);
    setHistoryStack(newStack);
    setHistoryIndex(newStack.length - 1);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prev = historyIndex - 1;
      setHistoryIndex(prev);
      setSourceCode(historyStack[prev]);
    }
  };

  const handleRedo = () => {
    if (historyIndex < historyStack.length - 1) {
      const next = historyIndex + 1;
      setHistoryIndex(next);
      setSourceCode(historyStack[next]);
    }
  };

  const handleCopyCode = () => {
    const textToCopy = isFormModalOpen ? sourceCode : selectedFile?.sourceCode || '';
    if (textToCopy) {
      navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      showToast('Source code copied to clipboard!', 'success');
    }
  };

  const handleFormatCode = () => {
    try {
      if (fileType === 'json') {
        const parsed = JSON.parse(sourceCode);
        handleCodeChange(JSON.stringify(parsed, null, 2));
        showToast('JSON code formatted cleanly.', 'success');
      } else {
        // Normalize basic indentation
        const lines = sourceCode.split('\n').map((l) => l.trimEnd());
        handleCodeChange(lines.join('\n'));
        showToast('Code whitespace formatted.', 'info');
      }
    } catch (e: any) {
      showToast('Cannot format: ' + e.message, 'warning');
    }
  };

  const handleReplaceAll = () => {
    if (!editorSearch) return;
    const replaced = sourceCode.replaceAll(editorSearch, editorReplace);
    handleCodeChange(replaced);
    showToast(`Replaced all occurrences of "${editorSearch}".`, 'info');
  };

  const openAddModal = () => {
    setEditingFile(null);
    setFileName('');
    setFilePath('src/');
    setFileType('tsx');
    setVersion('1.0.0');
    setDescription('');
    setChangeNotes('Initial source creation');
    setSourceCode('// Write or paste your source code here...\n');
    setIsDraft(false);
    setHistoryStack(['// Write or paste your source code here...\n']);
    setHistoryIndex(0);
    setIsFormModalOpen(true);
  };

  const openEditModal = (file: SourceFile) => {
    setEditingFile(file);
    setFileName(file.fileName);
    setFilePath(file.filePath);
    setFileType(file.fileType);
    setVersion(file.currentVersion);
    setDescription(file.description || '');
    setChangeNotes('');
    setSourceCode(file.sourceCode || '');
    setIsDraft(!file.isActive);
    setHistoryStack([file.sourceCode || '']);
    setHistoryIndex(0);
    setIsFormModalOpen(true);
  };

  const handleSaveClick = (asDraft: boolean = false) => {
    if (!fileName.trim() || !filePath.trim() || !sourceCode.trim()) {
      showToast('File Name, Path, and Source Code are required.', 'warning');
      return;
    }

    if (editingFile) {
      // Prompt user whether to create snapshot or overwrite current version
      const parts = editingFile.currentVersion.split('.');
      if (parts.length === 3 && !isNaN(Number(parts[2]))) {
        setNewSnapshotVersion(`${parts[0]}.${parts[1]}.${Number(parts[2]) + 1}`);
      } else {
        setNewSnapshotVersion('1.2.1');
      }
      setIsDraft(asDraft);
      setShowSnapshotDialog(true);
    } else {
      executeSaveNew(asDraft);
    }
  };

  const executeSaveNew = async (asDraft: boolean) => {
    setIsSaving(true);
    try {
      await addSourceFile(
        {
          fileName: fileName.trim(),
          filePath: filePath.trim(),
          fileType: fileType.trim().toLowerCase(),
          sourceCode,
          currentVersion: version.trim() || '1.0.0',
          description: description.trim(),
          changeNotes: changeNotes.trim(),
          lastModified: new Date().toISOString(),
          modifiedBy: user?.email || 'admin',
          isActive: !asDraft,
        },
        user?.email || 'admin'
      );

      showToast(`Source file "${fileName}" saved successfully!`, 'success');
      setIsFormModalOpen(false);
      loadData();
    } catch (err: any) {
      showToast('Failed to save file: ' + err.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const executeSaveEdit = async (createSnapshot: boolean) => {
    if (!editingFile) return;
    setIsSaving(true);
    try {
      await updateSourceFile(
        editingFile.id,
        {
          fileName: fileName.trim(),
          filePath: filePath.trim(),
          fileType: fileType.trim().toLowerCase(),
          sourceCode,
          description: description.trim(),
          isActive: !isDraft,
        },
        createSnapshot,
        createSnapshot ? newSnapshotVersion.trim() : undefined,
        user?.email || 'admin',
        changeNotes.trim() || undefined
      );

      showToast(
        createSnapshot
          ? `Saved as new snapshot version ${newSnapshotVersion}!`
          : `Updated current version ${editingFile.currentVersion}!`,
        'success'
      );

      setShowSnapshotDialog(false);
      setIsFormModalOpen(false);
      loadData();
    } catch (err: any) {
      showToast('Failed to update source file: ' + err.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleArchive = async (file: SourceFile) => {
    try {
      await archiveSourceFile(file.id, user?.email || 'admin');
      showToast(`Source file ${file.fileName} moved to archive.`, 'info');
      loadData();
    } catch {
      showToast('Failed to archive file.', 'error');
    }
  };

  const handleRestore = async (file: SourceFile) => {
    try {
      await restoreSourceFile(file.id, user?.email || 'admin');
      showToast(`Restored ${file.fileName} to active source repository!`, 'success');
      loadData();
    } catch {
      showToast('Failed to restore file.', 'error');
    }
  };

  const handlePermanentDelete = async (id: string) => {
    try {
      await permanentlyDeleteSourceFile(id, user?.email || 'admin');
      showToast('Permanently deleted from repository.', 'info');
      setConfirmDeleteId(null);
      loadData();
    } catch {
      showToast('Delete operation failed.', 'error');
    }
  };

  // Filter files
  const filteredFiles = files.filter((f) => {
    const matchesSearch =
      f.fileName.toLowerCase().includes(search.toLowerCase()) ||
      f.filePath.toLowerCase().includes(search.toLowerCase()) ||
      (f.description && f.description.toLowerCase().includes(search.toLowerCase()));
    const matchesType = selectedType === 'all' || f.fileType.toLowerCase() === selectedType.toLowerCase();
    return matchesSearch && matchesType;
  });

  const uniqueTypes = Array.from(new Set(files.map((f) => f.fileType.toLowerCase()))).filter(Boolean);

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              Source Manager
            </h1>
            <span className="px-2 py-0.5 rounded-md bg-cyan-500/20 text-cyan-400 text-[10px] font-mono font-bold border border-cyan-500/30">
              v1.2.0
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Store, audit, edit, and version application source code files synced with Cloud Firestore.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={loadData}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors"
            title="Refresh repository"
          >
            <RefreshCw className="w-4 h-4 text-cyan-400" />
          </button>
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add to Source</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Search source files by path, filename, description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-cyan-500 outline-none font-mono"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-300 focus:border-cyan-500 outline-none"
          >
            <option value="all">All File Types ({files.length})</option>
            {uniqueTypes.map((t) => (
              <option key={t} value={t}>
                .{t} ({files.filter((f) => f.fileType === t).length})
              </option>
            ))}
          </select>

          <label className="flex items-center gap-2 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showArchived}
              onChange={(e) => setShowArchived(e.target.checked)}
              className="w-3.5 h-3.5 rounded text-cyan-500"
            />
            <span>Archived</span>
          </label>
        </div>
      </div>

      {/* Main Two-Column Workbench Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[600px]">
        {/* Left Column: File Explorer Tree / List */}
        <div className="lg:col-span-4 bg-slate-950 rounded-3xl border border-slate-800 p-4 flex flex-col justify-between overflow-hidden shadow-sm">
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Repository Files ({filteredFiles.length})
              </span>
              <span className="text-[11px] text-cyan-400 font-mono">
                {files.filter((f) => !f.isArchived).length} Active
              </span>
            </div>

            {loading ? (
              <div className="space-y-2 py-4">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-10 bg-slate-900 rounded-xl animate-pulse" />
                ))}
              </div>
            ) : filteredFiles.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs space-y-2">
                <FileCode className="w-8 h-8 mx-auto text-slate-600 mb-1" />
                <p>No source files matching criteria.</p>
              </div>
            ) : (
              <div className="space-y-1.5 max-h-[540px] overflow-y-auto pr-1">
                {filteredFiles.map((file) => {
                  const isSelected = selectedFile?.id === file.id;
                  return (
                    <div
                      key={file.id}
                      onClick={() => setSelectedFile(file)}
                      className={`group p-3 rounded-2xl cursor-pointer transition-all flex items-start justify-between gap-3 border ${
                        isSelected
                          ? 'bg-slate-900 border-cyan-500/50 shadow-sm'
                          : 'bg-slate-950/60 border-slate-800/60 hover:bg-slate-900/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start gap-2.5 min-w-0 flex-1">
                        <FileCode
                          className={`w-4 h-4 shrink-0 mt-0.5 ${
                            isSelected ? 'text-cyan-400' : 'text-slate-500 group-hover:text-slate-300'
                          }`}
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-white truncate font-mono">
                            {file.fileName}
                          </p>
                          <p className="text-[11px] text-slate-500 truncate font-mono">
                            {file.filePath}
                          </p>
                          <div className="flex items-center gap-2 mt-1 text-[10px]">
                            <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 font-mono">
                              v{file.currentVersion}
                            </span>
                            {file.isArchived && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-semibold">
                                Archived
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openEditModal(file);
                          }}
                          className="p-1 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800"
                          title="Edit Code"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Code Viewer / Workbench */}
        <div className="lg:col-span-8 bg-slate-950 rounded-3xl border border-slate-800 flex flex-col justify-between overflow-hidden shadow-sm">
          {selectedFile ? (
            <div className="flex flex-col h-full">
              {/* File Detail Bar */}
              <div className="p-4 sm:p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/40">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-white font-mono truncate">
                      {selectedFile.fileName}
                    </h2>
                    <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-400 text-[10px] font-mono font-bold border border-cyan-500/30">
                      v{selectedFile.currentVersion}
                    </span>
                    {!selectedFile.isActive && (
                      <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px] font-bold">
                        Draft
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 font-mono truncate">
                    {selectedFile.filePath}
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <button
                    onClick={handleCopyCode}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                    title="Copy full source"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy Code'}</span>
                  </button>

                  <button
                    onClick={() => openEditModal(selectedFile)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-sm transition-all"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Source</span>
                  </button>

                  {selectedFile.isArchived ? (
                    <button
                      onClick={() => handleRestore(selectedFile)}
                      className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors"
                      title="Restore File"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => handleArchive(selectedFile)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-amber-500/20 text-slate-400 hover:text-amber-400 transition-colors"
                      title="Archive File"
                    >
                      <Archive className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => setConfirmDeleteId(selectedFile.id)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition-colors"
                    title="Delete permanently"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Metadata Badges */}
              <div className="px-5 py-2.5 bg-slate-950/80 border-b border-slate-800/60 flex flex-wrap items-center gap-4 text-[11px] text-slate-400 font-mono">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-500" />
                  <span>Modified: {new Date(selectedFile.lastModified).toLocaleString()}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  <span>By: {selectedFile.modifiedBy}</span>
                </div>
                {selectedFile.description && (
                  <div className="text-slate-300 italic truncate max-w-md">
                    &ldquo;{selectedFile.description}&rdquo;
                  </div>
                )}
              </div>

              {/* Code Viewer with Line Numbers */}
              <div className="flex-1 bg-slate-950 p-4 font-mono text-xs overflow-auto max-h-[500px]">
                <div className="flex gap-4">
                  {/* Line numbers */}
                  <div className="select-none text-slate-600 text-right pr-3 border-r border-slate-800/80 space-y-1">
                    {(selectedFile.sourceCode || '').split('\n').map((_, idx) => (
                      <div key={idx} className="leading-5">
                        {idx + 1}
                      </div>
                    ))}
                  </div>

                  {/* Code body */}
                  <pre className="text-cyan-100 flex-1 overflow-x-auto leading-5 whitespace-pre">
                    {selectedFile.sourceCode}
                  </pre>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-12 text-slate-500 text-xs space-y-2">
              <Code2 className="w-12 h-12 text-slate-700" />
              <p className="font-semibold text-slate-400">Select a source file to inspect its contents</p>
              <p>Or click &ldquo;Add to Source&rdquo; to register new project modules.</p>
            </div>
          )}
        </div>
      </div>

      {/* ADD / EDIT SOURCE MODAL */}
      {isFormModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-4xl p-6 sm:p-8 space-y-6 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <FileCode className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {editingFile ? `Edit Source: ${editingFile.fileName}` : 'Add to Source Repository'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Register and version application code files in Cloud Firestore.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsFormModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form Fields Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  File Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. ProductCard.tsx"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  File Path *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. src/components/ProductCard.tsx"
                  value={filePath}
                  onChange={(e) => setFilePath(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:border-cyan-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    File Type
                  </label>
                  <select
                    value={fileType}
                    onChange={(e) => setFileType(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:border-cyan-500 outline-none"
                  >
                    <option value="tsx">tsx</option>
                    <option value="ts">ts</option>
                    <option value="json">json</option>
                    <option value="css">css</option>
                    <option value="html">html</option>
                    <option value="md">md</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Version
                  </label>
                  <input
                    type="text"
                    value={version}
                    onChange={(e) => setVersion(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:border-cyan-500 outline-none"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="text-slate-300 font-semibold block mb-1">
                  Description
                </label>
                <input
                  type="text"
                  placeholder="Summary of module purpose..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 outline-none"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Change Notes
                </label>
                <input
                  type="text"
                  placeholder="Notes for changelog..."
                  value={changeNotes}
                  onChange={(e) => setChangeNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 outline-none"
                />
              </div>
            </div>

            {/* Code Editor Toolbar */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2 p-2 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleUndo}
                    disabled={historyIndex <= 0}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white disabled:opacity-30"
                    title="Undo"
                  >
                    <Undo2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleRedo}
                    disabled={historyIndex >= historyStack.length - 1}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white disabled:opacity-30"
                    title="Redo"
                  >
                    <Redo2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setShowReplaceBar(!showReplaceBar)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      showReplaceBar ? 'bg-cyan-500/20 text-cyan-400' : 'text-slate-400 hover:text-white'
                    }`}
                    title="Search and Replace"
                  >
                    <Replace className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleFormatCode}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400"
                    title="Format Code"
                  >
                    <Sparkles className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white"
                    title="Copy Code"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {sourceCode.split('\n').length} lines • {sourceCode.length} chars
                  </span>
                </div>
              </div>

              {/* Search & Replace Bar */}
              {showReplaceBar && (
                <div className="flex flex-wrap items-center gap-2 p-2.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs">
                  <input
                    type="text"
                    placeholder="Search text..."
                    value={editorSearch}
                    onChange={(e) => setEditorSearch(e.target.value)}
                    className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono outline-none"
                  />
                  <input
                    type="text"
                    placeholder="Replace with..."
                    value={editorReplace}
                    onChange={(e) => setEditorReplace(e.target.value)}
                    className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono outline-none"
                  />
                  <button
                    onClick={handleReplaceAll}
                    className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold"
                  >
                    Replace All
                  </button>
                </div>
              )}

              {/* Code Textarea with line numbers */}
              <div className="relative flex bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden font-mono text-xs">
                {/* Line number gutter */}
                <div className="select-none bg-slate-900/80 text-slate-600 text-right py-4 px-3 border-r border-slate-800/80 leading-5">
                  {sourceCode.split('\n').map((_, i) => (
                    <div key={i}>{i + 1}</div>
                  ))}
                </div>

                <textarea
                  ref={codeTextareaRef}
                  value={sourceCode}
                  onChange={(e) => handleCodeChange(e.target.value)}
                  rows={18}
                  placeholder="// Paste or write source code..."
                  className="flex-1 p-4 bg-transparent text-cyan-200 leading-5 outline-none resize-none font-mono whitespace-pre"
                  spellCheck={false}
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setIsFormModalOpen(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-semibold text-xs"
              >
                Cancel
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveClick(true)}
                  disabled={isSaving}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-colors"
                >
                  Save Draft
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveClick(false)}
                  disabled={isSaving}
                  className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all disabled:opacity-50"
                >
                  {isSaving ? 'Saving...' : 'Save to Source'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VERSION SNAPSHOT PROMPT DIALOG */}
      {showSnapshotDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                <GitBranch className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">Create Version Snapshot?</h3>
                <p className="text-xs text-slate-400">
                  Protect history by creating a new version release snapshot.
                </p>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <label className="text-slate-300 font-semibold block">
                Target Version Number:
              </label>
              <input
                type="text"
                value={newSnapshotVersion}
                onChange={(e) => setNewSnapshotVersion(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-cyan-400 font-mono font-bold outline-none"
              />
              <p className="text-[11px] text-slate-500">
                Current version is {editingFile?.currentVersion}.
              </p>
            </div>

            <div className="flex flex-col gap-2 pt-2 text-xs">
              <button
                onClick={() => executeSaveEdit(true)}
                disabled={isSaving}
                className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold shadow-md shadow-cyan-500/20 transition-all"
              >
                Yes, Save as New Version ({newSnapshotVersion})
              </button>
              <button
                onClick={() => executeSaveEdit(false)}
                disabled={isSaving}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold transition-colors"
              >
                No, Update Current Version ({editingFile?.currentVersion})
              </button>
              <button
                onClick={() => setShowSnapshotDialog(false)}
                className="w-full py-2 rounded-xl text-slate-400 hover:text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PERMANENT DELETE CONFIRMATION */}
      {confirmDeleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-white text-base">Permanently Delete File?</h3>
            <p className="text-xs text-slate-400">
              Are you sure? We recommend moving to archive instead so it can be restored anytime.
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setConfirmDeleteId(null)}
                className="flex-1 py-2 rounded-xl border border-slate-700 text-slate-300 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={() => handlePermanentDelete(confirmDeleteId)}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
