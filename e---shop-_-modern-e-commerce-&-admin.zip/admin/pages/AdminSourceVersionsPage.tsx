import React, { useState, useEffect } from 'react';
import {
  GitBranch,
  Plus,
  RotateCcw,
  Archive,
  CheckCircle2,
  FileCode,
  Calendar,
  User,
  X,
  Eye,
  SlidersHorizontal,
  ArrowRight,
  GitCommit,
  AlertTriangle,
  Split,
} from 'lucide-react';
import { useAuth } from '../../src/contexts/AuthContext';
import { useToast } from '../../src/contexts/ToastContext';
import { SourceVersion, SourceFile } from '../../src/types';
import {
  getSourceVersions,
  createSourceVersion,
  updateSourceVersionStatus,
  restoreVersionSnapshot,
  getSourceFiles,
} from '../../src/firebase/sourceManagerServices';

export const AdminSourceVersionsPage: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();

  const [versions, setVersions] = useState<SourceVersion[]>([]);
  const [sourceFiles, setSourceFiles] = useState<SourceFile[]>([]);
  const [loading, setLoading] = useState(true);

  // Selected Version for detail view
  const [selectedVersion, setSelectedVersion] = useState<SourceVersion | null>(null);

  // Create Release Modal
  const [isReleaseModalOpen, setIsReleaseModalOpen] = useState(false);
  const [versionNumber, setVersionNumber] = useState('');
  const [releaseTitle, setReleaseTitle] = useState('');
  const [releaseNotes, setReleaseNotes] = useState('');
  const [selectedFileIds, setSelectedFileIds] = useState<string[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  // Restore Confirmation Modal
  const [versionToRestore, setVersionToRestore] = useState<SourceVersion | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  // Diff / Compare Modal
  const [isDiffModalOpen, setIsDiffModalOpen] = useState(false);
  const [diffVersionA, setDiffVersionA] = useState<string>('');
  const [diffVersionB, setDiffVersionB] = useState<string>('');
  const [selectedDiffFile, setSelectedDiffFile] = useState<string>('');

  const loadData = async () => {
    setLoading(true);
    try {
      const [verList, fileList] = await Promise.all([getSourceVersions(), getSourceFiles(false)]);
      setVersions(verList || []);
      setSourceFiles(fileList || []);
      if (!selectedVersion && verList && verList.length > 0) {
        setSelectedVersion(verList[0]);
      } else if (selectedVersion && verList) {
        const found = verList.find((v) => v.id === selectedVersion.id);
        setSelectedVersion(found || verList[0] || null);
      }
    } catch (err) {
      console.error('Failed to load version snapshots:', err);
      showToast('Could not load version history from Firestore.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const openCreateReleaseModal = () => {
    // Determine next suggestion
    const active = versions.find((v) => v.status === 'Active');
    if (active) {
      const p = active.versionNumber.split('.');
      if (p.length === 3 && !isNaN(Number(p[2]))) {
        setVersionNumber(`${p[0]}.${Number(p[1]) + 1}.0`);
      } else {
        setVersionNumber('1.3.0');
      }
    } else {
      setVersionNumber('1.0.0');
    }

    setReleaseTitle('');
    setReleaseNotes('');
    // By default, select all active files
    setSelectedFileIds(sourceFiles.map((f) => f.id));
    setIsReleaseModalOpen(true);
  };

  const handleCreateRelease = async (status: 'Active' | 'Draft') => {
    if (!versionNumber.trim() || !releaseTitle.trim()) {
      showToast('Version Number and Release Title are required.', 'warning');
      return;
    }

    setIsSaving(true);
    try {
      const included = sourceFiles.filter((f) => selectedFileIds.includes(f.id));
      const changedFiles = included.map((f) => ({
        fileId: f.id,
        fileName: f.fileName,
        filePath: f.filePath,
        fileType: f.fileType,
        version: f.currentVersion,
        sourceCode: f.sourceCode,
      }));

      await createSourceVersion({
        versionNumber: versionNumber.trim(),
        releaseTitle: releaseTitle.trim(),
        releaseNotes: releaseNotes.trim(),
        changedFiles,
        createdDate: new Date().toISOString(),
        createdBy: user?.email || 'admin',
        status,
      });

      showToast(`Release ${versionNumber} ${status === 'Active' ? 'published' : 'saved as draft'}!`, 'success');
      setIsReleaseModalOpen(false);
      loadData();
    } catch (err: any) {
      showToast('Failed to create release: ' + err.message, 'error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleStatusChange = async (version: SourceVersion, newStatus: 'Active' | 'Archived') => {
    try {
      await updateSourceVersionStatus(version.id, newStatus);
      showToast(`Version ${version.versionNumber} marked as ${newStatus}.`, 'success');
      loadData();
    } catch {
      showToast('Status update failed.', 'error');
    }
  };

  const handleExecuteRestore = async () => {
    if (!versionToRestore) return;
    setIsRestoring(true);
    try {
      const res = await restoreVersionSnapshot(versionToRestore.id, user?.email || 'admin');
      showToast(`System restored to ${versionToRestore.versionNumber} (${res.restoredCount} files).`, 'success');
      setVersionToRestore(null);
      loadData();
    } catch (err: any) {
      showToast('Restore failed: ' + err.message, 'error');
    } finally {
      setIsRestoring(false);
    }
  };

  const openDiffModal = (ver: SourceVersion) => {
    setDiffVersionA(ver.id);
    const other = versions.find((v) => v.id !== ver.id);
    setDiffVersionB(other ? other.id : ver.id);
    if (ver.changedFiles && ver.changedFiles.length > 0) {
      setSelectedDiffFile(ver.changedFiles[0].filePath);
    }
    setIsDiffModalOpen(true);
  };

  // Diff Calculations
  const versionAObj = versions.find((v) => v.id === diffVersionA);
  const versionBObj = versions.find((v) => v.id === diffVersionB);

  const fileA = versionAObj?.changedFiles?.find((f) => f.filePath === selectedDiffFile);
  const fileB = versionBObj?.changedFiles?.find((f) => f.filePath === selectedDiffFile);

  const renderDiffLines = () => {
    const linesA = (fileA?.sourceCode || '').split('\n');
    const linesB = (fileB?.sourceCode || '').split('\n');
    const max = Math.max(linesA.length, linesB.length);

    const diffRows: React.ReactNode[] = [];
    for (let i = 0; i < max; i++) {
      const lineA = linesA[i];
      const lineB = linesB[i];

      const isAdded = lineA === undefined && lineB !== undefined;
      const isRemoved = lineA !== undefined && lineB === undefined;
      const isModified = lineA !== undefined && lineB !== undefined && lineA !== lineB;
      const isSame = lineA === lineB;

      diffRows.push(
        <div
          key={i}
          className={`flex text-xs font-mono leading-5 ${
            isModified
              ? 'bg-amber-500/10 text-amber-200'
              : isAdded
              ? 'bg-emerald-500/15 text-emerald-300'
              : isRemoved
              ? 'bg-rose-500/15 text-rose-300'
              : 'text-slate-400'
          }`}
        >
          <span className="w-12 text-slate-600 text-right pr-2 select-none border-r border-slate-800 shrink-0">
            {i + 1}
          </span>
          <span className="w-6 text-center select-none font-bold shrink-0">
            {isModified ? '~' : isAdded ? '+' : isRemoved ? '-' : ' '}
          </span>
          <span className="flex-1 px-2 whitespace-pre overflow-x-auto">
            {lineB !== undefined ? lineB : lineA}
          </span>
        </div>
      );
    }

    return diffRows;
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Version Control & Release History
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Maintain immutable release snapshots, compare file changes, and restore previous states.
          </p>
        </div>

        <button
          onClick={openCreateReleaseModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Release</span>
        </button>
      </div>

      {/* Main Grid: Versions List & Details */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[560px]">
        {/* Versions List */}
        <div className="lg:col-span-5 bg-slate-950 rounded-3xl border border-slate-800 p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Release Versions ({versions.length})
            </span>
          </div>

          {loading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-16 bg-slate-900 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : versions.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-xs">
              <GitBranch className="w-8 h-8 mx-auto text-slate-600 mb-2" />
              <p>No release versions created yet.</p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {versions.map((ver) => {
                const isSelected = selectedVersion?.id === ver.id;
                return (
                  <div
                    key={ver.id}
                    onClick={() => setSelectedVersion(ver)}
                    className={`p-4 rounded-2xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-slate-900 border-cyan-500/50 shadow-md'
                        : 'bg-slate-950/60 border-slate-800/60 hover:bg-slate-900/60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-white text-sm">
                          v{ver.versionNumber}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            ver.status === 'Active'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : ver.status === 'Archived'
                              ? 'bg-slate-800 text-slate-500'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {ver.status}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {new Date(ver.createdDate).toLocaleDateString()}
                      </span>
                    </div>

                    <h4 className="text-xs font-semibold text-slate-200 line-clamp-1">
                      {ver.releaseTitle}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {ver.changedFiles?.length || 0} snapshot files preserved
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Selected Version Detail Pane */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl border border-slate-800 p-6 flex flex-col justify-between">
          {selectedVersion ? (
            <div className="space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-black text-white font-mono">
                      Version {selectedVersion.versionNumber}
                    </h2>
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        selectedVersion.status === 'Active'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {selectedVersion.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{selectedVersion.releaseTitle}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openDiffModal(selectedVersion)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 text-xs font-semibold transition-colors"
                  >
                    <Split className="w-3.5 h-3.5" />
                    <span>Compare Diff</span>
                  </button>

                  {selectedVersion.status !== 'Active' && (
                    <button
                      onClick={() => handleStatusChange(selectedVersion, 'Active')}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 text-xs font-semibold transition-colors"
                      title="Mark as Current Active Release"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Make Active</span>
                    </button>
                  )}

                  <button
                    onClick={() => setVersionToRestore(selectedVersion)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors"
                    title="Restore all files from this version"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restore Release</span>
                  </button>
                </div>
              </div>

              {/* Release Metadata */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-900 rounded-xl space-y-1">
                  <span className="text-slate-500 block text-[10px] font-bold uppercase">
                    Released By
                  </span>
                  <p className="text-slate-200 font-mono">{selectedVersion.createdBy}</p>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl space-y-1">
                  <span className="text-slate-500 block text-[10px] font-bold uppercase">
                    Release Timestamp
                  </span>
                  <p className="text-slate-200 font-mono">
                    {new Date(selectedVersion.createdDate).toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Release Notes */}
              <div className="space-y-2 text-xs">
                <h4 className="font-bold text-slate-300">Release Notes</h4>
                <div className="p-4 bg-slate-900 rounded-2xl text-slate-300 whitespace-pre-wrap leading-relaxed">
                  {selectedVersion.releaseNotes || 'No specific release notes specified.'}
                </div>
              </div>

              {/* Included Snapshot Files */}
              <div className="space-y-2 text-xs">
                <h4 className="font-bold text-slate-300">
                  Snapshot Files ({selectedVersion.changedFiles?.length || 0})
                </h4>
                <div className="divide-y divide-slate-800 bg-slate-900 rounded-2xl overflow-hidden max-h-48 overflow-y-auto">
                  {(selectedVersion.changedFiles || []).map((file, idx) => (
                    <div key={idx} className="p-3 flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2">
                        <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="text-white">{file.filePath}</span>
                      </div>
                      <span className="text-slate-500 text-[11px]">
                        {file.sourceCode.length} chars
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-16 text-slate-500 text-xs">
              Select a release version on the left to inspect its contents.
            </div>
          )}
        </div>
      </div>

      {/* CREATE RELEASE MODAL */}
      {isReleaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl p-6 sm:p-8 space-y-5 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="font-bold text-white text-base">Create Version Release</h3>
              <button
                onClick={() => setIsReleaseModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleCreateRelease('Active');
              }}
              className="space-y-4 text-xs"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Version Number *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 1.3.0"
                    value={versionNumber}
                    onChange={(e) => setVersionNumber(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-cyan-400 font-mono font-bold focus:border-cyan-500 outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">
                    Release Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Performance & UI Update"
                    value={releaseTitle}
                    onChange={(e) => setReleaseTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Release Notes
                </label>
                <textarea
                  rows={3}
                  placeholder="Key additions, fixes, architectural notes..."
                  value={releaseNotes}
                  onChange={(e) => setReleaseNotes(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:border-cyan-500 outline-none"
                />
              </div>

              {/* Source File Selection */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-slate-300 font-semibold block">
                    Include Source Files ({selectedFileIds.length}/{sourceFiles.length})
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setSelectedFileIds(
                        selectedFileIds.length === sourceFiles.length
                          ? []
                          : sourceFiles.map((f) => f.id)
                      )
                    }
                    className="text-[11px] text-cyan-400 font-semibold hover:underline"
                  >
                    {selectedFileIds.length === sourceFiles.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="max-h-44 overflow-y-auto bg-slate-950 rounded-xl p-2 border border-slate-800 space-y-1">
                  {sourceFiles.map((file) => {
                    const isChecked = selectedFileIds.includes(file.id);
                    return (
                      <label
                        key={file.id}
                        className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-900 cursor-pointer text-[11px] font-mono"
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedFileIds([...selectedFileIds, file.id]);
                            } else {
                              setSelectedFileIds(selectedFileIds.filter((id) => id !== file.id));
                            }
                          }}
                          className="w-3.5 h-3.5 rounded text-cyan-500"
                        />
                        <span className="text-white flex-1 truncate">{file.filePath}</span>
                        <span className="text-slate-500">v{file.currentVersion}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setIsReleaseModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-700 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleCreateRelease('Draft')}
                    disabled={isSaving}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold"
                  >
                    Save Draft
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-all disabled:opacity-50"
                  >
                    {isSaving ? 'Publishing...' : 'Publish Version'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RESTORE CONFIRMATION DIALOG */}
      {versionToRestore && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-white text-base">
                  Restore Release {versionToRestore.versionNumber}?
                </h3>
                <p className="text-xs text-slate-400">
                  This will roll back all source files to their snapshot state.
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              {versionToRestore.changedFiles?.length || 0} source files will be synchronized. A backup record will be logged in the Change Log.
            </p>

            <div className="flex gap-2 pt-2 text-xs">
              <button
                onClick={() => setVersionToRestore(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteRestore}
                disabled={isRestoring}
                className="flex-1 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all disabled:opacity-50"
              >
                {isRestoring ? 'Restoring...' : 'Confirm Restore'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DIFF / COMPARE MODAL */}
      {isDiffModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-5xl p-6 sm:p-8 space-y-5 shadow-2xl my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Split className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">Compare Version Snapshots</h3>
              </div>
              <button
                onClick={() => setIsDiffModalOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Selector Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="text-slate-400 font-semibold block mb-1">Version A (Base)</label>
                <select
                  value={diffVersionA}
                  onChange={(e) => setDiffVersionA(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white outline-none"
                >
                  {versions.map((v) => (
                    <option key={v.id} value={v.id}>
                      v{v.versionNumber} ({v.releaseTitle})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Version B (Compare)</label>
                <select
                  value={diffVersionB}
                  onChange={(e) => setDiffVersionB(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white outline-none"
                >
                  {versions.map((v) => (
                    <option key={v.id} value={v.id}>
                      v{v.versionNumber} ({v.releaseTitle})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-semibold block mb-1">Target File</label>
                <select
                  value={selectedDiffFile}
                  onChange={(e) => setSelectedDiffFile(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-white outline-none font-mono"
                >
                  {sourceFiles.map((f) => (
                    <option key={f.id} value={f.filePath}>
                      {f.filePath}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Visual Diff Output */}
            <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden max-h-[500px] overflow-y-auto">
              <div className="p-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>{selectedDiffFile}</span>
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1 text-emerald-400">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" /> Added (+)
                  </span>
                  <span className="flex items-center gap-1 text-rose-400">
                    <span className="w-2 h-2 rounded-full bg-rose-500" /> Removed (-)
                  </span>
                  <span className="flex items-center gap-1 text-amber-400">
                    <span className="w-2 h-2 rounded-full bg-amber-500" /> Modified (~)
                  </span>
                </div>
              </div>

              <div className="p-3 overflow-x-auto">{renderDiffLines()}</div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setIsDiffModalOpen(false)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Close Comparison
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
