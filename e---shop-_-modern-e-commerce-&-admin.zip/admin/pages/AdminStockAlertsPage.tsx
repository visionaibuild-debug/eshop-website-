import React, { useState, useEffect } from 'react';
import { Product } from '../../src/types';
import { getProducts, updateProductStock, getWebsiteSettings } from '../../src/firebase/services';
import { useToast } from '../../src/contexts/ToastContext';
import { AlertTriangle, AlertOctagon, CheckCircle2, Save, Search, RefreshCw, Package } from 'lucide-react';

export const AdminStockAlertsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [threshold, setThreshold] = useState<number>(5);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [editingStocks, setEditingStocks] = useState<Record<string, number>>({});
  const [savingId, setSavingId] = useState<string | null>(null);

  const { showToast } = useToast();

  const loadData = async () => {
    setLoading(true);
    try {
      const [prods, settings] = await Promise.all([getProducts(), getWebsiteSettings()]);
      setProducts(prods || []);
      if (settings?.lowStockThreshold) {
        setThreshold(settings.lowStockThreshold);
      }
      // Populate edit states
      const stockMap: Record<string, number> = {};
      (prods || []).forEach((p) => {
        stockMap[p.id] = p.stock;
      });
      setEditingStocks(stockMap);
    } catch (err) {
      console.error('Failed to load stock inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleStockChange = (id: string, val: string) => {
    const num = parseInt(val, 10);
    setEditingStocks((prev) => ({
      ...prev,
      [id]: isNaN(num) ? 0 : Math.max(0, num),
    }));
  };

  const handleSaveStock = async (prod: Product) => {
    const newStock = editingStocks[prod.id] ?? prod.stock;
    setSavingId(prod.id);
    try {
      await updateProductStock(prod.id, newStock);
      setProducts((prev) =>
        prev.map((p) => (p.id === prod.id ? { ...p, stock: newStock } : p))
      );
      showToast(`Stock updated for ${prod.name} (${newStock} units).`, 'success');
    } catch (err) {
      showToast('Failed to update stock.', 'error');
    } finally {
      setSavingId(null);
    }
  };

  // Filter products by threshold or search
  const alertProducts = products.filter(
    (p) =>
      p.stock <= threshold &&
      (p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.sku?.toLowerCase().includes(search.toLowerCase()))
  );

  const outOfStock = products.filter((p) => p.stock <= 0);
  const lowStock = products.filter((p) => p.stock > 0 && p.stock <= threshold);
  const healthyStock = products.filter((p) => p.stock > threshold);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight">
            Inventory & Stock Alerts
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time warehouse threshold monitoring and instant quantity updates.
          </p>
        </div>

        <button
          onClick={loadData}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition-colors self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5 text-amber-400" />
          <span>Refresh Stock</span>
        </button>
      </div>

      {/* Threshold & Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Out of Stock
            </span>
            <AlertOctagon className="w-4 h-4" />
          </div>
          <p className="text-3xl font-black text-rose-500">{outOfStock.length}</p>
          <span className="text-[11px] text-rose-400/80">Immediate restocking required</span>
        </div>

        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Low Stock (&le; {threshold})
            </span>
            <AlertTriangle className="w-4 h-4" />
          </div>
          <p className="text-3xl font-black text-amber-400">{lowStock.length}</p>
          <span className="text-[11px] text-amber-400/80">Approaching depletion</span>
        </div>

        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Healthy Stock
            </span>
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <p className="text-3xl font-black text-white">{healthyStock.length}</p>
          <span className="text-[11px] text-slate-400">Optimal levels</span>
        </div>

        <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
            Alert Threshold
          </span>
          <div className="flex items-center gap-2">
            <input
              type="number"
              min={1}
              max={100}
              value={threshold}
              onChange={(e) => setThreshold(Math.max(1, parseInt(e.target.value, 10) || 1))}
              className="w-20 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold text-base outline-none focus:border-amber-500"
            />
            <span className="text-xs text-slate-400">units</span>
          </div>
          <span className="text-[10px] text-slate-500 block">Change threshold level</span>
        </div>
      </div>

      {/* Filter / Search */}
      <div className="relative">
        <input
          type="text"
          placeholder="Filter critical stock products by name, SKU..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder:text-slate-500 focus:border-amber-500 outline-none"
        />
        <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
      </div>

      {/* Table of Critical Items */}
      <div className="bg-slate-950 rounded-3xl border border-slate-800 overflow-hidden shadow-sm">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-white text-sm">
            Critical Inventory List ({alertProducts.length} items &le; {threshold} units)
          </h3>
        </div>

        {loading ? (
          <div className="p-8 space-y-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-12 bg-slate-900 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : alertProducts.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs space-y-1">
            <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2" />
            <p className="font-semibold text-slate-300">All inventory levels are healthy!</p>
            <p>No products are currently under the {threshold}-unit threshold.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/40">
                  <th className="py-3 px-4">Product</th>
                  <th className="py-3 px-4">SKU</th>
                  <th className="py-3 px-4">Price</th>
                  <th className="py-3 px-4">Current Status</th>
                  <th className="py-3 px-4">Quick Restock Quantity</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {alertProducts.map((prod) => (
                  <tr key={prod.id} className="hover:bg-slate-900/60 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={prod.mainImage}
                          alt={prod.name}
                          className="w-10 h-10 rounded-xl object-cover border border-slate-800 shrink-0"
                        />
                        <div>
                          <p className="font-bold text-white line-clamp-1">{prod.name}</p>
                          <p className="text-[11px] text-slate-400">{prod.category}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-300">
                      {prod.sku}
                    </td>

                    <td className="py-3 px-4 font-bold text-white">
                      ${(prod.discountPrice ?? prod.price).toFixed(2)}
                    </td>

                    <td className="py-3 px-4">
                      {prod.stock <= 0 ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                          Out of Stock
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                          Low Stock ({prod.stock})
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min={0}
                          value={editingStocks[prod.id] ?? prod.stock}
                          onChange={(e) => handleStockChange(prod.id, e.target.value)}
                          className="w-24 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-bold outline-none focus:border-amber-500"
                        />
                        <span className="text-[11px] text-slate-500">units</span>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleSaveStock(prod)}
                        disabled={savingId === prod.id}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-all disabled:opacity-50"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{savingId === prod.id ? 'Saving...' : 'Save'}</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
