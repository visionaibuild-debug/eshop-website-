import React, { useState, useEffect } from 'react';
import { ToastProvider } from './contexts/ToastContext';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { WishlistProvider } from './contexts/WishlistContext';
import { Navbar } from './components/Navbar';
import { MobileNav } from './components/MobileNav';
import { Footer } from './components/Footer';

// Customer Pages
import { HomePage } from './pages/HomePage';
import { ProductsPage } from './pages/ProductsPage';
import { ProductDetailsPage } from './pages/ProductDetailsPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { SearchResultsPage } from './pages/SearchResultsPage';
import { WishlistPage } from './pages/WishlistPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { UserProfilePage } from './pages/UserProfilePage';
import { MyOrdersPage } from './pages/MyOrdersPage';
import { OrderDetailsPage } from './pages/OrderDetailsPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { PrivacyPolicyPage } from './pages/PrivacyPolicyPage';
import { TermsPage } from './pages/TermsPage';

// Admin Package
import { AdminRoot } from '../admin/index';

function MainRouter() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname + window.location.search || '/';
  });

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname + window.location.search || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    if (path !== currentPath) {
      window.history.pushState(null, '', path);
      setCurrentPath(path);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Parse path & search params
  const pathname = currentPath.split('?')[0] || '/';
  const searchParams = new URLSearchParams(currentPath.includes('?') ? currentPath.split('?')[1] : '');

  // 1. Check if Admin route
  if (pathname.startsWith('/admin')) {
    return <AdminRoot onNavigateHome={() => navigate('/')} />;
  }

  // 2. Render Customer Website
  const renderCustomerPage = () => {
    if (pathname === '/') {
      return <HomePage onNavigate={navigate} />;
    }

    if (pathname === '/products') {
      const categoryParam = searchParams.get('category') || undefined;
      const searchParam = searchParams.get('search') || undefined;
      const featuredParam = searchParams.get('featured') === 'true';
      const popularParam = searchParams.get('popular') === 'true';

      return (
        <ProductsPage
          initialCategory={categoryParam}
          initialSearch={searchParam}
          initialFeatured={featuredParam}
          initialPopular={popularParam}
          onNavigate={navigate}
        />
      );
    }

    if (pathname.startsWith('/product/')) {
      const slug = pathname.replace('/product/', '');
      return <ProductDetailsPage slug={slug} onNavigate={navigate} />;
    }

    if (pathname === '/categories') {
      return <CategoriesPage onNavigate={navigate} />;
    }

    if (pathname === '/search') {
      const q = searchParams.get('q') || '';
      const cat = searchParams.get('category') || undefined;
      return <SearchResultsPage query={q} initialCategory={cat} onNavigate={navigate} />;
    }

    if (pathname === '/wishlist') {
      return <WishlistPage onNavigate={navigate} />;
    }

    if (pathname === '/cart') {
      return <CartPage onNavigate={navigate} />;
    }

    if (pathname === '/checkout') {
      return <CheckoutPage onNavigate={navigate} />;
    }

    if (pathname === '/login') {
      return <LoginPage onNavigate={navigate} />;
    }

    if (pathname === '/register') {
      return <RegisterPage onNavigate={navigate} />;
    }

    if (pathname === '/profile') {
      return <UserProfilePage onNavigate={navigate} />;
    }

    if (pathname === '/orders') {
      return <MyOrdersPage onNavigate={navigate} />;
    }

    if (pathname.startsWith('/order/')) {
      const orderId = pathname.replace('/order/', '');
      return <OrderDetailsPage orderId={orderId} onNavigate={navigate} />;
    }

    if (pathname === '/about') {
      return <AboutPage onNavigate={navigate} />;
    }

    if (pathname === '/contact') {
      return <ContactPage />;
    }

    if (pathname === '/privacy-policy') {
      return <PrivacyPolicyPage />;
    }

    if (pathname === '/terms-conditions') {
      return <TermsPage />;
    }

    // Default Fallback
    return <HomePage onNavigate={navigate} />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      <Navbar currentPath={currentPath} onNavigate={navigate} />
      <main className="flex-1 pb-16 lg:pb-0">{renderCustomerPage()}</main>
      <Footer onNavigate={navigate} />
      <MobileNav currentPath={currentPath} onNavigate={navigate} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <WishlistProvider>
          <CartProvider>
            <MainRouter />
          </CartProvider>
        </WishlistProvider>
      </AuthProvider>
    </ToastProvider>
  );
}
