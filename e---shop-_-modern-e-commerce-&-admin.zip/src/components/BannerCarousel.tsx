import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight } from 'lucide-react';
import { Banner } from '../types';

interface BannerCarouselProps {
  banners: Banner[];
  onNavigate: (url: string) => void;
}

export const BannerCarousel: React.FC<BannerCarouselProps> = ({ banners, onNavigate }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % banners.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [banners.length]);

  if (!banners || banners.length === 0) return null;

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % banners.length);
  };

  const current = banners[currentIndex] || banners[0];
  if (!current) return null;

  return (
    <div className="relative w-full rounded-3xl overflow-hidden bg-slate-900 shadow-xl group">
      {/* Background Banner Image */}
      <div className="relative h-96 sm:h-[450px] md:h-[500px] w-full">
        <img
          src={current.image}
          alt={current.title}
          className="w-full h-full object-cover object-center brightness-[0.6] transition-all duration-700 ease-out"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/40 to-transparent" />
      </div>

      {/* Content */}
      <div className="absolute inset-0 flex flex-col justify-end p-6 sm:p-10 md:p-14 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-semibold uppercase tracking-wider mb-4 w-fit">
          <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
          Featured Collection
        </div>

        <h1 className="text-2xl sm:text-4xl md:text-5xl font-extrabold text-white leading-tight mb-3 tracking-tight">
          {current.title}
        </h1>

        {current.subtitle && (
          <p className="text-sm sm:text-base md:text-lg text-slate-200 line-clamp-2 sm:line-clamp-3 mb-6 max-w-xl font-normal leading-relaxed">
            {current.subtitle}
          </p>
        )}

        <div className="flex items-center gap-4">
          <button
            onClick={() => onNavigate(current.destinationUrl || '/products')}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm sm:text-base transition-all duration-200 shadow-lg shadow-indigo-600/30 active:scale-95"
          >
            {current.buttonText || 'Discover Now'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Arrows */}
      {banners.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            aria-label="Previous slide"
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white backdrop-blur-md flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            aria-label="Next slide"
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 hover:bg-white/40 text-white backdrop-blur-md flex items-center justify-center transition-all opacity-0 group-hover:opacity-100"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Dots */}
          <div className="absolute bottom-6 right-6 sm:right-10 flex items-center gap-2 z-10">
            {banners.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentIndex(idx)}
                aria-label={`Go to slide ${idx + 1}`}
                className={`h-2 transition-all duration-300 rounded-full ${
                  currentIndex === idx ? 'w-8 bg-indigo-500' : 'w-2 bg-white/50 hover:bg-white/80'
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};
