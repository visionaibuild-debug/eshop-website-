import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ShoppingBag,
  Search,
  User as UserIcon,
  Shield,
  Menu,
  X,
  LogOut,
  Package,
  Heart,
  ChevronDown,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';
import { getProducts, getCategories } from '../firebase/services';
import { Product, Category } from '../types';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate }) => {
  const { user, isAdmin, logout } = useAuth();
  const { totalItemCount } = useCart();
  const { totalWishlistCount } = useWishlist();

  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isSuggestionsOpen, setIsSuggestionsOpen] = useState(false);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  // Dropdown states
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Load catalog for instant live search
  useEffect(() => {
    let isMounted = true;
    Promise.all([getProducts().catch(() => []), getCategories().catch(() => [])]).then(
      ([prods, cats]) => {
        if (isMounted) {
          setAllProducts(prods || []);
          setCategories(cats || []);
        }
      }
    );
    return () => {
      isMounted = false;
    };
  }, []);

  // Close search suggestions & user dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setIsSuggestionsOpen(false);
      }
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsUserDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Compute live search suggestions
  const searchSuggestions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return allProducts
      .filter((p) => {
        const prodCategory = (p.category || '').toLowerCase();
        const prodName = (p.name || '').toLowerCase();
        const prodBrand = (p.brand || '').toLowerCase();

        const matchesCategory =
          selectedCategory === 'All' ||
          prodCategory === selectedCategory.toLowerCase();
        const matchesQuery =
          prodName.includes(q) ||
          prodCategory.includes(q) ||
          prodBrand.includes(q) ||
          (Array.isArray(p.tags) && p.tags.some((t) => (t || '').toLowerCase().includes(q)));
        return matchesCategory && matchesQuery && Boolean(p.isPublished);
      })
      .slice(0, 5);
  }, [allProducts, searchQuery, selectedCategory]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setIsSuggestionsOpen(false);
      setIsMobileMenuOpen(false);
      const catParam = selectedCategory !== 'All' ? `&category=${encodeURIComponent(selectedCategory)}` : '';
      onNavigate(`/search?q=${encodeURIComponent(searchQuery.trim())}${catParam}`);
    }
  };

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Products', path: '/products' },
    { label: 'Categories', path: '/categories' },
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 backdrop-blur-md border-b border-slate-100 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-3 sm:gap-4">
          {/* Brand Logo */}
          <div
            onClick={() => onNavigate('/')}
            className="flex items-center gap-2 cursor-pointer select-none group shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-700 via-indigo-600 to-violet-500 flex items-center justify-center text-white font-extrabold text-xl shadow-md shadow-indigo-200 group-hover:scale-105 transition-transform duration-200">
              E
            </div>
            <div className="flex flex-col">
              <span className="font-extrabold text-xl tracking-wider text-slate-900 font-sans">
                E<span className="text-indigo-600 font-black"> - </span>SHOP
              </span>
              <span className="text-[9px] uppercase tracking-widest text-slate-400 font-semibold -mt-1">
                Modern Commerce
              </span>
            </div>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-1">
            {navLinks.map((link) => {
              const isActive =
                link.path === '/'
                  ? currentPath === '/'
                  : currentPath.startsWith(link.path);
              return (
                <button
                  key={link.path}
                  onClick={() => onNavigate(link.path)}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'text-indigo-600 bg-indigo-50/70 font-semibold'
                      : 'text-slate-600 hover:text-slate-950 hover:bg-slate-50'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Product Search Bar with Real-Time Filtering */}
          <div
            ref={searchContainerRef}
            className="hidden md:flex flex-1 max-w-sm lg:max-w-md xl:max-w-lg relative"
          >
            <form
              onSubmit={handleSearchSubmit}
              className="w-full flex items-center bg-slate-100/90 rounded-2xl border border-transparent focus-within:border-indigo-400 focus-within:bg-white transition-all overflow-hidden shadow-xs"
            >
              {/* Category selector */}
              <div className="relative border-r border-slate-200/80 bg-slate-50/70">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="h-10 pl-2.5 pr-6 bg-transparent text-xs font-semibold text-slate-700 outline-none cursor-pointer appearance-none"
                >
                  <option value="All">All Categories</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-[10px]">
                  ▼
                </div>
              </div>

              {/* Search text input */}
              <div className="relative flex-1 flex items-center">
                <input
                  type="text"
                  placeholder="Search products, brands..."
                  value={searchQuery}
                  onFocus={() => {
                    if (searchQuery.trim().length > 0) setIsSuggestionsOpen(true);
                  }}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setIsSuggestionsOpen(true);
                  }}
                  className="w-full pl-9 pr-8 py-2 bg-transparent text-xs text-slate-900 placeholder:text-slate-400 outline-none"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />

                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setIsSuggestionsOpen(false);
                    }}
                    className="p-1 text-slate-400 hover:text-slate-600 absolute right-2"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </form>

            {/* Live Search Suggestions Dropdown */}
            {isSuggestionsOpen && searchQuery.trim().length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl border border-slate-200/90 shadow-2xl py-2 z-50 animate-in fade-in-50 zoom-in-95 duration-150">
                <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-semibold">
                  <span>
                    Suggestions in {selectedCategory !== 'All' ? selectedCategory : 'all catalog'}
                  </span>
                  <span>{searchSuggestions.length} found</span>
                </div>

                {searchSuggestions.length === 0 ? (
                  <div className="p-4 text-center text-xs text-slate-500">
                    No products found matching &ldquo;{searchQuery}&rdquo;.
                  </div>
                ) : (
                  <div className="divide-y divide-slate-50 max-h-80 overflow-y-auto">
                    {searchSuggestions.map((prod) => (
                      <div
                        key={prod.id}
                        onClick={() => {
                          setIsSuggestionsOpen(false);
                          setSearchQuery('');
                          onNavigate(`/product/${prod.slug}`);
                        }}
                        className="p-3 hover:bg-slate-50/90 flex items-center gap-3 cursor-pointer transition-colors"
                      >
                        <img
                          src={prod.mainImage}
                          alt={prod.name}
                          className="w-10 h-10 rounded-lg object-cover bg-slate-100 shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold text-slate-900 truncate">
                            {prod.name}
                          </p>
                          <span className="text-[10px] text-indigo-600 font-medium uppercase">
                            {prod.category}
                          </span>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-xs font-bold text-slate-900">
                            ${(prod.discountPrice ?? prod.price).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <div className="p-2 border-t border-slate-100 bg-slate-50/50">
                  <button
                    onClick={handleSearchSubmit}
                    className="w-full py-2 px-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <span>View all matching results</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right Action Icons: Admin, Wishlist, Cart, Profile */}
          <div className="flex items-center gap-1.5 sm:gap-2.5">
            {/* Admin Quick Jump */}
            {isAdmin && (
              <button
                onClick={() => onNavigate('/admin')}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-700 text-xs font-semibold hover:bg-amber-500/20 transition-all"
                title="Admin Control Panel"
              >
                <Shield className="w-3.5 h-3.5 text-amber-600" />
                <span className="hidden lg:inline">Admin Panel</span>
              </button>
            )}

            {/* Wishlist Button */}
            <button
              onClick={() => onNavigate('/wishlist')}
              className="relative p-2.5 rounded-xl hover:bg-rose-50 text-slate-700 hover:text-rose-600 transition-colors"
              aria-label="View Wishlist"
              title="View Wishlist"
            >
              <Heart className={`w-5 h-5 ${totalWishlistCount > 0 ? 'fill-rose-500 text-rose-500' : ''}`} />
              {totalWishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1.5 rounded-full bg-rose-600 text-white text-[11px] font-bold flex items-center justify-center shadow-md shadow-rose-200 animate-in zoom-in-50 duration-200">
                  {totalWishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Cart Button */}
            <button
              onClick={() => onNavigate('/cart')}
              className="relative p-2.5 rounded-xl hover:bg-indigo-50 text-slate-700 hover:text-indigo-600 transition-colors"
              aria-label="View Shopping Cart"
              title="View Shopping Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {totalItemCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1.5 rounded-full bg-indigo-600 text-white text-[11px] font-bold flex items-center justify-center shadow-md shadow-indigo-200 animate-in zoom-in-50 duration-200">
                  {totalItemCount}
                </span>
              )}
            </button>

            {/* User Account Menu */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                className="flex items-center gap-2 p-1.5 sm:px-2.5 sm:py-2 rounded-xl hover:bg-slate-100 text-slate-700 text-sm font-medium transition-all"
              >
                <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-xs">
                  {user?.displayName ? (
                    user.displayName[0].toUpperCase()
                  ) : user ? (
                    <UserIcon className="w-4 h-4" />
                  ) : (
                    <UserIcon className="w-4 h-4 text-slate-500" />
                  )}
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
              </button>

              {/* User Dropdown */}
              {isUserDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white border border-slate-100 shadow-xl py-2 z-50 animate-in fade-in-50 zoom-in-95 duration-150">
                  {user ? (
                    <>
                      <div className="px-4 py-2 border-b border-slate-100">
                        <p className="text-xs text-slate-400 font-medium">Signed in as</p>
                        <p className="text-sm font-semibold text-slate-900 truncate">
                          {user.displayName || user.email}
                        </p>
                      </div>

                      {isAdmin && (
                        <button
                          onClick={() => {
                            setIsUserDropdownOpen(false);
                            onNavigate('/admin');
                          }}
                          className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-amber-700 hover:bg-amber-50 text-left font-medium transition-colors"
                        >
                          <Shield className="w-4 h-4 text-amber-600" />
                          Admin Dashboard
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          onNavigate('/profile');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left transition-colors"
                      >
                        <UserIcon className="w-4 h-4 text-slate-400" />
                        My Profile
                      </button>

                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          onNavigate('/wishlist');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left transition-colors"
                      >
                        <Heart className="w-4 h-4 text-rose-500" />
                        My Wishlist
                        {totalWishlistCount > 0 && (
                          <span className="ml-auto px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold">
                            {totalWishlistCount}
                          </span>
                        )}
                      </button>

                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          onNavigate('/orders');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left transition-colors"
                      >
                        <Package className="w-4 h-4 text-slate-400" />
                        My Orders
                      </button>

                      <div className="border-t border-slate-100 my-1" />

                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          logout();
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-rose-600 hover:bg-rose-50 text-left transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          onNavigate('/wishlist');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left transition-colors"
                      >
                        <Heart className="w-4 h-4 text-rose-500" />
                        Wishlist
                        {totalWishlistCount > 0 && (
                          <span className="ml-auto px-1.5 py-0.5 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold">
                            {totalWishlistCount}
                          </span>
                        )}
                      </button>

                      <div className="border-t border-slate-100 my-1" />

                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          onNavigate('/login');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 text-left transition-colors"
                      >
                        Sign In
                      </button>
                      <button
                        onClick={() => {
                          setIsUserDropdownOpen(false);
                          onNavigate('/register');
                        }}
                        className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left transition-colors"
                      >
                        Create Account
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-slate-100 animate-in slide-in-from-top-4 duration-200 space-y-4">
            {/* Mobile Search with Category */}
            <form onSubmit={handleSearchSubmit} className="space-y-2">
              <div className="flex gap-2">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-2.5 py-2 rounded-xl bg-slate-100 text-xs font-semibold text-slate-700 outline-none"
                >
                  <option value="All">All</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-100 text-xs outline-none"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>
            </form>

            <nav className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <button
                  key={link.path}
                  onClick={() => {
                    onNavigate(link.path);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-left text-sm font-medium ${
                    currentPath === link.path
                      ? 'text-indigo-600 bg-indigo-50 font-semibold'
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {link.label}
                </button>
              ))}

              <button
                onClick={() => {
                  onNavigate('/wishlist');
                  setIsMobileMenuOpen(false);
                }}
                className="px-4 py-2.5 rounded-xl text-left text-sm font-medium text-slate-700 hover:bg-slate-50 flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-rose-500" />
                  Wishlist
                </span>
                {totalWishlistCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-rose-100 text-rose-700 text-xs font-bold">
                    {totalWishlistCount}
                  </span>
                )}
              </button>

              {isAdmin && (
                <button
                  onClick={() => {
                    onNavigate('/admin');
                    setIsMobileMenuOpen(false);
                  }}
                  className="px-4 py-2.5 rounded-xl text-left text-sm font-semibold text-amber-700 bg-amber-50 flex items-center gap-2"
                >
                  <Shield className="w-4 h-4 text-amber-600" />
                  Admin Control Panel
                </button>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};
