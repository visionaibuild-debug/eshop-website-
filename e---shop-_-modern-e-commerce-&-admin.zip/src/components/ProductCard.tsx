import React from 'react';
import { ShoppingCart, Star, Heart, Check } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';
import { useWishlist } from '../contexts/WishlistContext';

interface ProductCardProps {
  product: Product;
  onNavigate: (slug: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onNavigate }) => {
  const { addToCart, items } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const [isAddedRecently, setIsAddedRecently] = React.useState(false);

  const isFavorited = isInWishlist(product.id);

  const cartItem = items.find((i) => i.product.id === product.id);
  const inCartQty = cartItem ? cartItem.quantity : 0;
  const isOutOfStock = product.stock <= 0;
  const isMaxInCart = inCartQty >= product.stock;

  const discountPercentage = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isOutOfStock || isMaxInCart) return;

    const success = addToCart(product, 1);
    if (success) {
      setIsAddedRecently(true);
      setTimeout(() => setIsAddedRecently(false), 1500);
    }
  };

  return (
    <div
      onClick={() => onNavigate(product.slug)}
      className="group relative bg-white rounded-2xl border border-slate-100 p-3 sm:p-4 shadow-sm hover:shadow-xl hover:border-indigo-100 transition-all duration-300 flex flex-col justify-between cursor-pointer"
    >
      <div>
        {/* Image Container with Badges */}
        <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-50 mb-3 sm:mb-4">
          <img
            src={product.mainImage}
            alt={product.name}
            loading="lazy"
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
          />

          {/* Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1.5 z-10">
            {discountPercentage > 0 && (
              <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-rose-500 text-white shadow-sm">
                -{discountPercentage}%
              </span>
            )}
            {product.isFeatured && (
              <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-indigo-600 text-white shadow-sm">
                Featured
              </span>
            )}
            {product.isPopular && !product.isFeatured && (
              <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold bg-amber-500 text-white shadow-sm">
                Popular
              </span>
            )}
          </div>

          {/* Wishlist Button */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleWishlist(product);
            }}
            title={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
            aria-label={isFavorited ? 'Remove from wishlist' : 'Add to wishlist'}
            className={`absolute top-2 right-2 z-20 p-2 rounded-full transition-all duration-200 backdrop-blur-md shadow-xs active:scale-90 ${
              isFavorited
                ? 'bg-rose-50 text-rose-600 border border-rose-200 shadow-sm'
                : 'bg-white/90 text-slate-400 hover:text-rose-500 hover:bg-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorited ? 'fill-rose-500' : ''}`} />
          </button>

          {/* Out of stock overlay */}
          {isOutOfStock && (
            <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center">
              <span className="px-3 py-1 rounded-xl text-xs font-bold bg-rose-600 text-white tracking-wider uppercase">
                Sold Out
              </span>
            </div>
          )}

          {/* Brand Tag */}
          <div className="absolute bottom-2 left-2">
            <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-white/90 text-slate-700 backdrop-blur-md shadow-xs">
              {product.brand}
            </span>
          </div>
        </div>

        {/* Category & Title */}
        <div className="mb-2">
          <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider mb-1">
            {product.category}
          </p>
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base leading-snug line-clamp-2 group-hover:text-indigo-600 transition-colors">
            {product.name}
          </h3>
        </div>

        {/* Short description */}
        {product.shortDescription && (
          <p className="text-xs text-slate-500 line-clamp-1 mb-3">
            {product.shortDescription}
          </p>
        )}
      </div>

      {/* Price & Action Section */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between mt-auto">
        <div className="flex flex-col">
          <div className="flex items-baseline gap-1.5">
            <span className="text-base sm:text-lg font-bold text-slate-900">
              ${((product.discountPrice ?? product.price) || 0).toFixed(2)}
            </span>
            {product.discountPrice && (
              <span className="text-xs text-slate-400 line-through">
                ${(product.price || 0).toFixed(2)}
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-400 font-medium">
            {product.stock > 0 ? (
              product.stock <= 5 ? (
                <span className="text-amber-600 font-semibold">Only {product.stock} left!</span>
              ) : (
                'In Stock'
              )
            ) : (
              <span className="text-rose-500">Out of Stock</span>
            )}
          </span>
        </div>

        {/* Add to Cart button */}
        <button
          onClick={handleAddToCart}
          disabled={isOutOfStock || isMaxInCart}
          title={
            isOutOfStock
              ? 'Out of stock'
              : isMaxInCart
              ? 'Maximum stock in cart'
              : 'Add to cart'
          }
          className={`h-9 w-9 sm:h-10 sm:w-10 rounded-xl flex items-center justify-center transition-all duration-200 active:scale-90 ${
            isOutOfStock || isMaxInCart
              ? 'bg-slate-100 text-slate-300 cursor-not-allowed'
              : isAddedRecently
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200'
              : inCartQty > 0
              ? 'bg-indigo-50 text-indigo-700 hover:bg-indigo-600 hover:text-white border border-indigo-200'
              : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md shadow-indigo-100'
          }`}
        >
          {isAddedRecently ? (
            <Check className="w-4 h-4" />
          ) : (
            <ShoppingCart className="w-4 h-4" />
          )}
        </button>
      </div>
    </div>
  );
};
