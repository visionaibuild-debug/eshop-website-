import React from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Banner } from '../types';

interface PromoBannerProps {
  banner: Banner;
  onNavigate: (url: string) => void;
}

export const PromoBanner: React.FC<PromoBannerProps> = ({ banner, onNavigate }) => {
  return (
    <div
      onClick={() => onNavigate(banner.destinationUrl || '/products')}
      className="relative w-full rounded-3xl overflow-hidden shadow-lg group cursor-pointer border border-slate-100 bg-slate-900 transition-all duration-300 hover:shadow-2xl"
    >
      <div className="relative h-64 sm:h-72 md:h-80 w-full overflow-hidden">
        <img
          src={banner.image}
          alt={banner.title}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out brightness-[0.55]"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/60 to-transparent" />
      </div>

      <div className="absolute inset-0 flex flex-col justify-center px-6 sm:px-12 md:px-16 max-w-2xl">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold uppercase tracking-wider mb-3 w-fit backdrop-blur-md border border-indigo-500/30">
          <Sparkles className="w-3.5 h-3.5" />
          Special Promotion
        </div>

        <h3 className="text-xl sm:text-3xl font-extrabold text-white leading-tight mb-2 tracking-tight">
          {banner.title}
        </h3>

        {banner.subtitle && (
          <p className="text-xs sm:text-sm md:text-base text-slate-300 line-clamp-2 mb-6 font-normal">
            {banner.subtitle}
          </p>
        )}

        <div>
          <button className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-slate-900 font-semibold text-xs sm:text-sm hover:bg-slate-100 transition-all shadow-md group-hover:translate-x-1 duration-200">
            {banner.buttonText || 'Shop Now'}
            <ArrowRight className="w-4 h-4 text-indigo-600" />
          </button>
        </div>
      </div>
    </div>
  );
};
