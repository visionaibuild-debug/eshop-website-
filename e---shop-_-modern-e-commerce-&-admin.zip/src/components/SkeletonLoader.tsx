import React from 'react';

export const ProductCardSkeleton: React.FC = () => {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm animate-pulse flex flex-col justify-between">
      <div>
        <div className="w-full aspect-square bg-slate-200 rounded-xl mb-4" />
        <div className="h-4 bg-slate-200 rounded-md w-1/3 mb-2" />
        <div className="h-5 bg-slate-200 rounded-md w-3/4 mb-3" />
        <div className="h-4 bg-slate-200 rounded-md w-1/2 mb-4" />
      </div>
      <div className="flex items-center justify-between pt-3 border-t border-slate-100">
        <div className="h-6 bg-slate-200 rounded-md w-20" />
        <div className="h-9 w-9 bg-slate-200 rounded-xl" />
      </div>
    </div>
  );
};

export const BannerSkeleton: React.FC = () => {
  return (
    <div className="w-full h-80 sm:h-96 md:h-[480px] bg-slate-200 rounded-3xl animate-pulse flex items-center justify-center">
      <div className="space-y-4 max-w-lg px-6 text-center">
        <div className="h-8 bg-slate-300 rounded-xl w-3/4 mx-auto" />
        <div className="h-4 bg-slate-300 rounded-lg w-full mx-auto" />
        <div className="h-10 bg-slate-300 rounded-xl w-36 mx-auto mt-4" />
      </div>
    </div>
  );
};

export const TableRowSkeleton: React.FC<{ cols?: number }> = ({ cols = 5 }) => {
  return (
    <tr className="animate-pulse border-b border-slate-100">
      {Array.from({ length: cols }).map((_, i) => (
        <td key={i} className="py-4 px-4">
          <div className="h-4 bg-slate-200 rounded w-full" />
        </td>
      ))}
    </tr>
  );
};
