import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem } from '../types';
import { useAuth } from './AuthContext';
import { getUserCart, saveUserCart } from '../firebase/services';
import { useToast } from './ToastContext';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity?: number) => boolean;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => boolean;
  clearCart: () => void;
  subtotal: number;
  discount: number;
  shippingFee: number;
  totalAmount: number;
  totalItemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'eshop_cart_guest_v1';
const FREE_SHIPPING_THRESHOLD = 150;
const STANDARD_SHIPPING_FEE = 15;

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const { user } = useAuth();
  const { showToast } = useToast();

  // Load initial cart (Guest from localStorage, User from Firestore)
  useEffect(() => {
    let isMounted = true;

    async function loadCart() {
      if (user) {
        try {
          const cloudItems = await getUserCart(user.uid);
          if (isMounted) {
            // If user had local items before login, merge them
            const localSaved = localStorage.getItem(LOCAL_STORAGE_KEY);
            let merged = cloudItems || [];
            if (localSaved) {
              try {
                const guestItems: CartItem[] = JSON.parse(localSaved);
                guestItems.forEach((gItem) => {
                  const existing = merged.find((m) => m.product.id === gItem.product.id);
                  if (existing) {
                    existing.quantity = Math.min(
                      existing.quantity + gItem.quantity,
                      existing.product.stock
                    );
                  } else {
                    merged.push(gItem);
                  }
                });
                localStorage.removeItem(LOCAL_STORAGE_KEY);
                await saveUserCart(user.uid, merged);
              } catch (e) {
                console.error('Error merging local cart:', e);
              }
            }
            setItems(merged);
          }
        } catch {
          if (isMounted) setItems([]);
        }
      } else {
        const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (saved && isMounted) {
          try {
            setItems(JSON.parse(saved));
          } catch {
            setItems([]);
          }
        }
      }
      if (isMounted) setIsInitialized(true);
    }

    loadCart();

    return () => {
      isMounted = false;
    };
  }, [user]);

  // Persist cart changes
  useEffect(() => {
    if (!isInitialized) return;

    if (user) {
      saveUserCart(user.uid, items).catch((err) =>
        console.error('Failed to sync cart with Firestore:', err)
      );
    } else {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(items));
    }
  }, [items, user, isInitialized]);

  const addToCart = (product: Product, quantity: number = 1): boolean => {
    if (product.stock <= 0) {
      showToast(`${product.name} is currently out of stock.`, 'warning');
      return false;
    }

    let success = true;
    setItems((prev) => {
      const existingIndex = prev.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const currentQty = prev[existingIndex].quantity;
        const newQty = currentQty + quantity;
        if (newQty > product.stock) {
          showToast(`Only ${product.stock} items available in stock.`, 'warning');
          success = false;
          return prev;
        }
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: newQty,
          product, // refresh product details
        };
        showToast(`Updated ${product.name} quantity in cart.`, 'success');
        return updated;
      } else {
        if (quantity > product.stock) {
          showToast(`Only ${product.stock} items available in stock.`, 'warning');
          success = false;
          return prev;
        }
        showToast(`Added ${product.name} to cart.`, 'success');
        return [...prev, { product, quantity }];
      }
    });

    return success;
  };

  const removeFromCart = (productId: string) => {
    setItems((prev) => {
      const found = prev.find((i) => i.product.id === productId);
      if (found) {
        showToast(`Removed ${found.product.name} from cart.`, 'info');
      }
      return prev.filter((item) => item.product.id !== productId);
    });
  };

  const updateQuantity = (productId: string, quantity: number): boolean => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return true;
    }

    let success = true;
    setItems((prev) => {
      const index = prev.findIndex((item) => item.product.id === productId);
      if (index === -1) return prev;

      const product = prev[index].product;
      if (quantity > product.stock) {
        showToast(`Only ${product.stock} units available in stock.`, 'warning');
        success = false;
        return prev;
      }

      const updated = [...prev];
      updated[index] = { ...updated[index], quantity };
      return updated;
    });

    return success;
  };

  const clearCart = () => {
    setItems([]);
    if (!user) {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  };

  // Calculations
  const subtotal = items.reduce((acc, item) => {
    if (!item?.product) return acc;
    const itemPrice = item.product.discountPrice || item.product.price || 0;
    return acc + itemPrice * (item.quantity || 1);
  }, 0);

  const regularTotal = items.reduce((acc, item) => {
    if (!item?.product) return acc;
    return acc + (item.product.price || 0) * (item.quantity || 1);
  }, 0);

  const discount = Math.max(0, regularTotal - subtotal);
  const shippingFee = items.length === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING_FEE;
  const totalAmount = subtotal + shippingFee;
  const totalItemCount = items.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <CartContext.Provider
      value={{
        items,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        subtotal,
        discount,
        shippingFee,
        totalAmount,
        totalItemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export function useCart() {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
