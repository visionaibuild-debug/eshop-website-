import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';
import { db } from '../firebase/config';
import { doc, getDoc, setDoc } from 'firebase/firestore';

interface WishlistContextType {
  wishlist: Product[];
  isInWishlist: (productId: string) => boolean;
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  toggleWishlist: (product: Product) => void;
  clearWishlist: () => void;
  totalWishlistCount: number;
}

const WishlistContext = createContext<WishlistContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'eshop_wishlist_items';

export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);
  const { user } = useAuth();
  const { showToast } = useToast();

  // Load wishlist on startup
  useEffect(() => {
    let isMounted = true;

    async function loadWishlist() {
      // 1. First load from localStorage
      let localItems: Product[] = [];
      try {
        const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (saved) {
          localItems = JSON.parse(saved);
        }
      } catch {
        localItems = [];
      }

      // 2. If user is signed in, check Firestore cloud sync
      if (user) {
        try {
          const docRef = doc(db, 'wishlists', user.uid);
          const snap = await getDoc(docRef);
          if (snap.exists() && isMounted) {
            const cloudItems = (snap.data()?.items as Product[]) || [];
            // Merge local and cloud items by product id
            const mergedMap = new Map<string, Product>();
            [...cloudItems, ...localItems].forEach((item) => {
              if (item?.id) mergedMap.set(item.id, item);
            });
            const merged = Array.from(mergedMap.values());
            setWishlist(merged);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
            setIsLoaded(true);
            return;
          }
        } catch (err) {
          console.warn('Could not sync cloud wishlist:', err);
        }
      }

      if (isMounted) {
        setWishlist(localItems);
        setIsLoaded(true);
      }
    }

    loadWishlist();

    return () => {
      isMounted = false;
    };
  }, [user]);

  // Sync state changes to storage
  const persistWishlist = async (items: Product[]) => {
    setWishlist(items);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(items));
    } catch (err) {
      console.warn('LocalStorage save failed:', err);
    }

    if (user) {
      try {
        await setDoc(doc(db, 'wishlists', user.uid), {
          userId: user.uid,
          items,
          updatedAt: new Date().toISOString(),
        }, { merge: true });
      } catch (err) {
        console.warn('Firestore wishlist sync failed:', err);
      }
    }
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some((item) => item.id === productId);
  };

  const addToWishlist = (product: Product) => {
    if (isInWishlist(product.id)) return;
    const updated = [product, ...wishlist];
    persistWishlist(updated);
    showToast(`Added "${product.name}" to your wishlist!`, 'success');
  };

  const removeFromWishlist = (productId: string) => {
    const itemToRemove = wishlist.find((i) => i.id === productId);
    const updated = wishlist.filter((item) => item.id !== productId);
    persistWishlist(updated);
    if (itemToRemove) {
      showToast(`Removed "${itemToRemove.name}" from wishlist.`, 'info');
    }
  };

  const toggleWishlist = (product: Product) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  const clearWishlist = () => {
    persistWishlist([]);
    showToast('Your wishlist has been cleared.', 'info');
  };

  return (
    <WishlistContext.Provider
      value={{
        wishlist,
        isInWishlist,
        addToWishlist,
        removeFromWishlist,
        toggleWishlist,
        clearWishlist,
        totalWishlistCount: wishlist.length,
      }}
    >
      {children}
    </WishlistContext.Provider>
  );
};

export const useWishlist = () => {
  const context = useContext(WishlistContext);
  if (!context) {
    throw new Error('useWishlist must be used within a WishlistProvider');
  }
  return context;
};
