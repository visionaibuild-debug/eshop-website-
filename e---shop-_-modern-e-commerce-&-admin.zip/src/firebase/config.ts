import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import appletConfig from '@/firebase-applet-config.json';

// Safely access environment variables in both Vite and Node environments
const getEnvVar = (key: string): string | undefined => {
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
    return import.meta.env[key];
  }
  if (typeof process !== 'undefined' && process.env && process.env[key]) {
    return process.env[key];
  }
  return undefined;
};

// Configure Firebase with VITE_FIREBASE_* environment variables and appletConfig fallback
const firebaseConfig = {
  apiKey: getEnvVar('VITE_FIREBASE_API_KEY') || appletConfig.apiKey,
  authDomain: getEnvVar('VITE_FIREBASE_AUTH_DOMAIN') || appletConfig.authDomain,
  projectId: getEnvVar('VITE_FIREBASE_PROJECT_ID') || appletConfig.projectId,
  storageBucket: getEnvVar('VITE_FIREBASE_STORAGE_BUCKET') || appletConfig.storageBucket,
  messagingSenderId: getEnvVar('VITE_FIREBASE_MESSAGING_SENDER_ID') || appletConfig.messagingSenderId,
  appId: getEnvVar('VITE_FIREBASE_APP_ID') || appletConfig.appId,
  measurementId: getEnvVar('VITE_FIREBASE_MEASUREMENT_ID') || appletConfig.measurementId || '',
};

// Target Cloud Firestore database instance ID
// Always prioritize the verified database ID from firebase-applet-config.json
const VERIFIED_FIRESTORE_DATABASE_ID =
  appletConfig.firestoreDatabaseId || 'ai-studio-eshopmodernecomm-2a74940a-155c-4ef0-9702-2966ff0d0103';

const rawDbId =
  getEnvVar('VITE_FIREBASE_FIRESTORE_DATABASE_ID') ||
  VERIFIED_FIRESTORE_DATABASE_ID;

const sanitizedDbId = (rawDbId === '(default)' ? VERIFIED_FIRESTORE_DATABASE_ID : rawDbId)
  .replace('eshopmoderncomm', 'eshopmodernecomm');

const firestoreDatabaseId = sanitizedDbId || VERIFIED_FIRESTORE_DATABASE_ID;

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

// CRITICAL: Initialize Firestore with firestoreDatabaseId as required by Firebase skill
export const db = getFirestore(app, firestoreDatabaseId);
export const auth = getAuth(app);
export const storage = getStorage(app);

// Validate Connection to Firestore on startup as mandated by Firebase Skill
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is connecting...');
    }
  }
}

testConnection();

export default app;
