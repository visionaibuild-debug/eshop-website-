import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from './config';
import { handleFirestoreError, OperationType } from './errors';
import {
  Product,
  Category,
  Banner,
  Order,
  UserProfile,
  CartItem,
  BannerPosition,
  OrderStatus,
  Coupon,
  Review,
  WebsiteSettings,
  CustomerSummary,
} from '../types';
import { INITIAL_CATEGORIES, INITIAL_PRODUCTS, INITIAL_BANNERS } from './seedData';

// ---------------- PRODUCTS ----------------

export async function getProducts(options?: {
  category?: string;
  brand?: string;
  isFeatured?: boolean;
  isPopular?: boolean;
  search?: string;
  sort?: 'newest' | 'price-asc' | 'price-desc' | 'popular';
  limitCount?: number;
}): Promise<Product[]> {
  const path = 'products';
  try {
    const colRef = collection(db, path);
    const snap = await getDocs(colRef);
    let items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Product));

    // Client-side filtering & sorting for flexible multi-facet queries without indexing explosions
    if (options?.category && options.category !== 'All') {
      items = items.filter(
        (p) => p.category?.toLowerCase() === options.category?.toLowerCase()
      );
    }
    if (options?.brand && options.brand !== 'All') {
      items = items.filter(
        (p) => p.brand?.toLowerCase() === options.brand?.toLowerCase()
      );
    }
    if (options?.isFeatured) {
      items = items.filter((p) => p.isFeatured);
    }
    if (options?.isPopular) {
      items = items.filter((p) => p.isPopular);
    }
    if (options?.search && options.search.trim()) {
      const q = options.search.toLowerCase().trim();
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.sku?.toLowerCase().includes(q) ||
          p.category?.toLowerCase().includes(q) ||
          p.brand?.toLowerCase().includes(q) ||
          p.tags?.some((t) => t.toLowerCase().includes(q))
      );
    }

    if (options?.sort) {
      if (options.sort === 'newest') {
        items.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      } else if (options.sort === 'price-asc') {
        items.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
      } else if (options.sort === 'price-desc') {
        items.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
      } else if (options.sort === 'popular') {
        items.sort((a, b) => (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0));
      }
    }

    if (options?.limitCount) {
      items = items.slice(0, options.limitCount);
    }

    return items;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const path = 'products';
  try {
    const colRef = collection(db, path);
    const q = query(colRef, where('slug', '==', slug), limit(1));
    const snap = await getDocs(q);
    if (snap.empty) {
      return null;
    }
    const d = snap.docs[0];
    return { id: d.id, ...d.data() } as Product;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getProductById(id: string): Promise<Product | null> {
  const path = `products/${id}`;
  try {
    const snap = await getDoc(doc(db, 'products', id));
    if (!snap.exists()) return null;
    return { id: snap.id, ...snap.data() } as Product;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createProduct(
  productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const path = 'products';
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, path), {
      ...productData,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateProduct(
  id: string,
  productData: Partial<Product>
): Promise<void> {
  const path = `products/${id}`;
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'products', id), {
      ...productData,
      updatedAt: now,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteProduct(id: string): Promise<void> {
  const path = `products/${id}`;
  try {
    await deleteDoc(doc(db, 'products', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeToProducts(
  callback: (products: Product[]) => void,
  options?: { category?: string; limitCount?: number }
) {
  const path = 'products';
  const colRef = collection(db, path);
  return onSnapshot(
    colRef,
    (snap) => {
      let items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Product));
      if (options?.category && options.category !== 'All') {
        items = items.filter((p) => p.category === options.category);
      }
      if (options?.limitCount) {
        items = items.slice(0, options.limitCount);
      }
      callback(items);
    },
    (err) => {
      handleFirestoreError(err, OperationType.GET, path);
    }
  );
}

// ---------------- CATEGORIES ----------------

export async function getCategories(): Promise<Category[]> {
  const path = 'categories';
  try {
    const snap = await getDocs(collection(db, path));
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Category));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createCategory(
  categoryData: Omit<Category, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const path = 'categories';
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, path), {
      ...categoryData,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateCategory(
  id: string,
  categoryData: Partial<Category>
): Promise<void> {
  const path = `categories/${id}`;
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'categories', id), {
      ...categoryData,
      updatedAt: now,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteCategory(id: string): Promise<void> {
  const path = `categories/${id}`;
  try {
    await deleteDoc(doc(db, 'categories', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ---------------- BANNERS ----------------

export async function getBanners(): Promise<Banner[]> {
  const path = 'banners';
  try {
    const snap = await getDocs(collection(db, path));
    return snap.docs.map((d) => ({ id: d.id, ...d.data() } as Banner));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getActiveBanners(position?: BannerPosition): Promise<Banner[]> {
  const path = 'banners';
  try {
    const snap = await getDocs(collection(db, path));
    const now = new Date().toISOString();
    let banners = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Banner));

    banners = banners.filter((b) => {
      if (!b.isActive) return false;
      if (position && b.position !== position) return false;
      if (b.startDate && b.startDate > now) return false;
      if (b.endDate && b.endDate < now) return false;
      return true;
    });

    return banners;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createBanner(
  bannerData: Omit<Banner, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const path = 'banners';
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, path), {
      ...bannerData,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateBanner(
  id: string,
  bannerData: Partial<Banner>
): Promise<void> {
  const path = `banners/${id}`;
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'banners', id), {
      ...bannerData,
      updatedAt: now,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteBanner(id: string): Promise<void> {
  const path = `banners/${id}`;
  try {
    await deleteDoc(doc(db, 'banners', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ---------------- ORDERS ----------------

export async function createOrder(
  orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const path = 'orders';
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, path), {
      ...orderData,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function getUserOrders(userId: string): Promise<Order[]> {
  const path = 'orders';
  try {
    const q = query(collection(db, path), where('userId', '==', userId));
    const snap = await getDocs(q);
    const orders = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Order));
    orders.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return orders;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getAllOrders(): Promise<Order[]> {
  const path = 'orders';
  try {
    const snap = await getDocs(collection(db, path));
    const orders = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Order));
    orders.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    return orders;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getOrderById(id: string): Promise<Order | null> {
  const path = `orders/${id}`;
  try {
    const snap = await getDoc(doc(db, 'orders', id));
    if (!snap.exists()) return null;
    return { id: snap.id, ...snap.data() } as Order;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function updateOrderStatus(
  id: string,
  orderStatus: OrderStatus
): Promise<void> {
  const path = `orders/${id}`;
  try {
    const now = new Date().toISOString();
    await updateDoc(doc(db, 'orders', id), {
      orderStatus,
      updatedAt: now,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ---------------- USER PROFILES ----------------

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return null;
    return { uid: snap.id, ...snap.data() } as UserProfile;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  const path = `users/${profile.uid}`;
  try {
    const now = new Date().toISOString();
    await setDoc(
      doc(db, 'users', profile.uid),
      {
        ...profile,
        updatedAt: now,
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// ---------------- CARTS ----------------

export async function getUserCart(userId: string): Promise<CartItem[]> {
  const path = `carts/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'carts', userId));
    if (!snap.exists()) return [];
    return (snap.data().items as CartItem[]) || [];
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function saveUserCart(userId: string, items: CartItem[]): Promise<void> {
  const path = `carts/${userId}`;
  try {
    const now = new Date().toISOString();
    await setDoc(doc(db, 'carts', userId), {
      userId,
      items,
      updatedAt: now,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// ---------------- STORAGE & IMAGE UPLOADS ----------------

export async function uploadImage(file: File, folder: string = 'general'): Promise<string> {
  try {
    const filename = `${folder}/${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
    const storageRef = ref(storage, filename);
    const snapshot = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (err) {
    console.warn('Firebase Storage upload direct failed, falling back to data URL encoding:', err);
    // Bulletproof fallback to Base64 image reader for local resilience
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
}

// ---------------- COUPONS ----------------

export async function getCoupons(): Promise<Coupon[]> {
  const path = 'coupons';
  try {
    const snap = await getDocs(collection(db, path));
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Coupon));
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getActiveCoupons(): Promise<Coupon[]> {
  const path = 'coupons';
  try {
    const all = await getCoupons();
    const now = new Date();
    return all.filter((c) => c.isActive && new Date(c.expiryDate) >= now);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getCouponByCode(code: string): Promise<Coupon | null> {
  const path = 'coupons';
  try {
    const all = await getCoupons();
    const found = all.find((c) => c.code.trim().toUpperCase() === code.trim().toUpperCase());
    if (!found) return null;
    return found;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createCoupon(
  couponData: Omit<Coupon, 'id' | 'createdAt' | 'updatedAt' | 'usageCount'>
): Promise<string> {
  const path = 'coupons';
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, path), {
      ...couponData,
      code: couponData.code.trim().toUpperCase(),
      usageCount: 0,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateCoupon(id: string, couponData: Partial<Coupon>): Promise<void> {
  const path = `coupons/${id}`;
  try {
    const refDoc = doc(db, 'coupons', id);
    await updateDoc(refDoc, {
      ...couponData,
      ...(couponData.code ? { code: couponData.code.trim().toUpperCase() } : {}),
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteCoupon(id: string): Promise<void> {
  const path = `coupons/${id}`;
  try {
    await deleteDoc(doc(db, 'coupons', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function incrementCouponUsage(id: string): Promise<void> {
  const path = `coupons/${id}`;
  try {
    const refDoc = doc(db, 'coupons', id);
    const snap = await getDoc(refDoc);
    if (snap.exists()) {
      const current = snap.data()?.usageCount || 0;
      await updateDoc(refDoc, { usageCount: current + 1 });
    }
  } catch (error) {
    console.warn('Could not increment coupon usage:', error);
  }
}

// ---------------- REVIEWS ----------------

export async function getAllReviews(): Promise<Review[]> {
  const path = 'reviews';
  try {
    const snap = await getDocs(collection(db, path));
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Review));
    list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function getProductReviews(productId: string): Promise<Review[]> {
  const path = 'reviews';
  try {
    const all = await getAllReviews();
    return all.filter((r) => r.productId === productId && r.status === 'approved');
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createReview(
  reviewData: Omit<Review, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const path = 'reviews';
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, path), {
      ...reviewData,
      createdAt: now,
      updatedAt: now,
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateReviewStatus(
  id: string,
  status: 'approved' | 'rejected'
): Promise<void> {
  const path = `reviews/${id}`;
  try {
    const refDoc = doc(db, 'reviews', id);
    await updateDoc(refDoc, {
      status,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteReview(id: string): Promise<void> {
  const path = `reviews/${id}`;
  try {
    await deleteDoc(doc(db, 'reviews', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ---------------- WEBSITE SETTINGS ----------------

export const DEFAULT_SETTINGS: WebsiteSettings = {
  storeName: 'E - SHOP',
  logoUrl: '',
  storePhone: '+1 (800) 555-0199',
  storeEmail: 'support@eshop-modern.com',
  address: '742 Evergreen Terrace, Suite 100, San Francisco, CA 94107',
  currency: 'USD',
  currencySymbol: '$',
  shippingCharge: 9.99,
  freeShippingThreshold: 150,
  lowStockThreshold: 10,
  socialLinks: {
    facebook: 'https://facebook.com',
    twitter: 'https://twitter.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
    linkedin: 'https://linkedin.com',
  },
  updatedAt: new Date().toISOString(),
};

export async function getWebsiteSettings(): Promise<WebsiteSettings> {
  const path = 'settings/general';
  try {
    const snap = await getDoc(doc(db, 'settings', 'general'));
    if (!snap.exists()) {
      return DEFAULT_SETTINGS;
    }
    return { ...DEFAULT_SETTINGS, ...snap.data() } as WebsiteSettings;
  } catch (error) {
    console.warn('Could not read settings from Firestore, returning defaults:', error);
    return DEFAULT_SETTINGS;
  }
}

export async function updateWebsiteSettings(
  settings: Partial<WebsiteSettings>
): Promise<void> {
  const path = 'settings/general';
  try {
    const refDoc = doc(db, 'settings', 'general');
    await setDoc(
      refDoc,
      {
        ...settings,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// ---------------- CUSTOMERS ----------------

export async function getAllCustomers(): Promise<CustomerSummary[]> {
  const path = 'users';
  try {
    // 1. Fetch registered users
    const userSnap = await getDocs(collection(db, path));
    const registeredUsers = userSnap.docs.map((d) => ({
      uid: d.id,
      ...d.data(),
    })) as UserProfile[];

    // 2. Fetch all orders to compute spend, order count, etc.
    const orderSnap = await getDocs(collection(db, 'orders'));
    const orders = orderSnap.docs.map((d) => ({ id: d.id, ...d.data() } as Order));

    const customerMap = new Map<string, CustomerSummary>();

    // Map registered users first
    registeredUsers.forEach((u) => {
      customerMap.set(u.uid, {
        uid: u.uid,
        displayName: u.displayName || (u.email ? u.email.split('@')[0] : 'Customer'),
        email: u.email || 'N/A',
        phone: u.phone || 'N/A',
        registrationDate: u.createdAt || new Date().toISOString(),
        totalOrders: 0,
        totalSpent: 0,
        city: u.city,
        address: u.address,
      });
    });

    // Aggregate orders
    orders.forEach((ord) => {
      const key = ord.userId !== 'guest' ? ord.userId : `guest_${ord.customerEmail || ord.id}`;
      if (!customerMap.has(key)) {
        customerMap.set(key, {
          uid: key,
          displayName: ord.customerName || (ord.customerEmail ? ord.customerEmail.split('@')[0] : 'Guest Customer'),
          email: ord.customerEmail || 'N/A',
          phone: ord.customerPhone,
          registrationDate: ord.createdAt,
          totalOrders: 0,
          totalSpent: 0,
          city: ord.city,
          address: ord.shippingAddress,
        });
      }

      const entry = customerMap.get(key)!;
      entry.totalOrders += 1;
      entry.totalSpent += ord.totalAmount || 0;
      if (!entry.lastOrderDate || new Date(ord.createdAt) > new Date(entry.lastOrderDate)) {
        entry.lastOrderDate = ord.createdAt;
      }
    });

    const result = Array.from(customerMap.values());
    result.sort((a, b) => b.totalSpent - a.totalSpent);
    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

// ---------------- QUICK STOCK UPDATE ----------------

export async function updateProductStock(productId: string, stock: number): Promise<void> {
  const path = `products/${productId}`;
  try {
    const refDoc = doc(db, 'products', productId);
    await updateDoc(refDoc, {
      stock: Math.max(0, Math.floor(stock)),
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ---------------- INITIAL SEEDING ----------------

export async function seedInitialDataIfEmpty(): Promise<boolean> {
  try {
    const prodSnap = await getDocs(collection(db, 'products'));
    if (!prodSnap.empty) {
      return false; // Database already populated
    }

    console.log('Seeding initial categories, products, and banners into Firestore...');

    // 1. Seed Categories
    for (const cat of INITIAL_CATEGORIES) {
      await addDoc(collection(db, 'categories'), cat);
    }

    // 2. Seed Products
    for (const prod of INITIAL_PRODUCTS) {
      await addDoc(collection(db, 'products'), prod);
    }

    // 3. Seed Banners
    for (const ban of INITIAL_BANNERS) {
      await addDoc(collection(db, 'banners'), ban);
    }

    // 4. Ensure admin doc exists for mrokan753@gmail.com
    await setDoc(doc(db, 'admins', 'mrokan753_admin'), {
      email: 'mrokan753@gmail.com',
      role: 'super_admin',
      createdAt: new Date().toISOString(),
    });

    console.log('Database seeding successfully finished!');
    return true;
  } catch (error) {
    console.error('Failed to seed initial data:', error);
    return false;
  }
}
