import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import JSZip from 'jszip';
import { db } from './config';
import { handleFirestoreError, OperationType } from './errors';
import {
  SourceFile,
  SourceVersion,
  SourceChangeLogEntry,
  SourceImportRecord,
  SourceManifest,
  SourceAction,
} from '../types';

// Collections
const FILES_COL = 'source_files';
const VERSIONS_COL = 'source_versions';
const CHANGELOG_COL = 'source_changelog';
const IMPORTS_COL = 'source_imports';

// ---------------- SOURCE FILES CRUD ----------------

export async function getSourceFiles(includeArchived: boolean = false): Promise<SourceFile[]> {
  try {
    const snap = await getDocs(collection(db, FILES_COL));
    let files = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SourceFile));
    if (!includeArchived) {
      files = files.filter((f) => !f.isArchived);
    }
    files.sort((a, b) => a.filePath.localeCompare(b.filePath));
    return files;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, FILES_COL);
  }
}

export async function getSourceFileById(id: string): Promise<SourceFile | null> {
  const path = `${FILES_COL}/${id}`;
  try {
    const snap = await getDoc(doc(db, FILES_COL, id));
    if (!snap.exists()) return null;
    return { id: snap.id, ...snap.data() } as SourceFile;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function addSourceFile(
  fileData: Omit<SourceFile, 'id' | 'createdAt' | 'updatedAt'>,
  userEmail: string
): Promise<string> {
  try {
    const now = new Date().toISOString();
    const docRef = await addDoc(collection(db, FILES_COL), {
      ...fileData,
      isArchived: false,
      lastModified: now,
      modifiedBy: userEmail,
      createdAt: now,
      updatedAt: now,
    });

    // Write change log
    await addSourceChangeLog({
      date: now,
      version: fileData.currentVersion || '1.0.0',
      file: fileData.filePath,
      action: 'Added',
      changedBy: userEmail,
      description: fileData.description || `Added file ${fileData.fileName}`,
      newCode: fileData.sourceCode,
    });

    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, FILES_COL);
  }
}

export async function updateSourceFile(
  id: string,
  updates: Partial<SourceFile>,
  createSnapshot: boolean,
  newVersionNumber: string | undefined,
  userEmail: string,
  changeNote?: string
): Promise<void> {
  const path = `${FILES_COL}/${id}`;
  try {
    const existing = await getSourceFileById(id);
    if (!existing) throw new Error('Source file not found');

    const now = new Date().toISOString();
    const versionToSet = createSnapshot && newVersionNumber ? newVersionNumber : existing.currentVersion;

    await updateDoc(doc(db, FILES_COL, id), {
      ...updates,
      currentVersion: versionToSet,
      changeNotes: changeNote || updates.changeNotes || existing.changeNotes,
      lastModified: now,
      modifiedBy: userEmail,
      updatedAt: now,
    });

    // Audit change log
    await addSourceChangeLog({
      date: now,
      version: versionToSet,
      file: existing.filePath,
      action: 'Updated',
      changedBy: userEmail,
      description: changeNote || updates.description || `Updated ${existing.fileName} ${createSnapshot ? `(Snapshot v${versionToSet})` : ''}`,
      previousCode: existing.sourceCode,
      newCode: updates.sourceCode || existing.sourceCode,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function archiveSourceFile(id: string, userEmail: string): Promise<void> {
  const path = `${FILES_COL}/${id}`;
  try {
    const existing = await getSourceFileById(id);
    if (!existing) return;

    const now = new Date().toISOString();
    await updateDoc(doc(db, FILES_COL, id), {
      isArchived: true,
      isActive: false,
      lastModified: now,
      modifiedBy: userEmail,
      updatedAt: now,
    });

    await addSourceChangeLog({
      date: now,
      version: existing.currentVersion,
      file: existing.filePath,
      action: 'Deleted',
      changedBy: userEmail,
      description: `Archived source file ${existing.fileName}`,
      previousCode: existing.sourceCode,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function restoreSourceFile(id: string, userEmail: string): Promise<void> {
  const path = `${FILES_COL}/${id}`;
  try {
    const existing = await getSourceFileById(id);
    if (!existing) return;

    const now = new Date().toISOString();
    await updateDoc(doc(db, FILES_COL, id), {
      isArchived: false,
      isActive: true,
      lastModified: now,
      modifiedBy: userEmail,
      updatedAt: now,
    });

    await addSourceChangeLog({
      date: now,
      version: existing.currentVersion,
      file: existing.filePath,
      action: 'Restored',
      changedBy: userEmail,
      description: `Restored archived source file ${existing.fileName}`,
      newCode: existing.sourceCode,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function permanentlyDeleteSourceFile(id: string, userEmail: string): Promise<void> {
  const path = `${FILES_COL}/${id}`;
  try {
    const existing = await getSourceFileById(id);
    if (existing) {
      await addSourceChangeLog({
        date: new Date().toISOString(),
        version: existing.currentVersion,
        file: existing.filePath,
        action: 'Deleted',
        changedBy: userEmail,
        description: `Permanently removed ${existing.fileName}`,
        previousCode: existing.sourceCode,
      });
    }
    await deleteDoc(doc(db, FILES_COL, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ---------------- VERSIONS & RELEASES ----------------

export async function getSourceVersions(): Promise<SourceVersion[]> {
  try {
    const snap = await getDocs(collection(db, VERSIONS_COL));
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SourceVersion));
    list.sort((a, b) => new Date(b.createdDate || b.createdAt).getTime() - new Date(a.createdDate || a.createdAt).getTime());
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, VERSIONS_COL);
  }
}

export async function createSourceVersion(
  versionData: Omit<SourceVersion, 'id' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  try {
    const now = new Date().toISOString();

    // If marked active, set other active versions to archived
    if (versionData.status === 'Active') {
      const all = await getSourceVersions();
      for (const v of all) {
        if (v.status === 'Active') {
          await updateDoc(doc(db, VERSIONS_COL, v.id), { status: 'Archived', updatedAt: now });
        }
      }
    }

    const docRef = await addDoc(collection(db, VERSIONS_COL), {
      ...versionData,
      createdDate: versionData.createdDate || now,
      createdAt: now,
      updatedAt: now,
    });

    await addSourceChangeLog({
      date: now,
      version: versionData.versionNumber,
      file: 'Release Snapshot',
      action: 'Added',
      changedBy: versionData.createdBy,
      description: `Created version release: ${versionData.versionNumber} - ${versionData.releaseTitle}`,
    });

    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, VERSIONS_COL);
  }
}

export async function updateSourceVersionStatus(
  id: string,
  status: 'Draft' | 'Active' | 'Archived'
): Promise<void> {
  const path = `${VERSIONS_COL}/${id}`;
  try {
    const now = new Date().toISOString();
    if (status === 'Active') {
      const all = await getSourceVersions();
      for (const v of all) {
        if (v.id !== id && v.status === 'Active') {
          await updateDoc(doc(db, VERSIONS_COL, v.id), { status: 'Archived', updatedAt: now });
        }
      }
    }
    await updateDoc(doc(db, VERSIONS_COL, id), { status, updatedAt: now });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function restoreVersionSnapshot(
  versionId: string,
  userEmail: string
): Promise<{ restoredCount: number }> {
  try {
    const snap = await getDoc(doc(db, VERSIONS_COL, versionId));
    if (!snap.exists()) throw new Error('Version snapshot not found');
    const version = snap.data() as SourceVersion;

    let restoredCount = 0;
    const now = new Date().toISOString();

    // For each snapshot file, either update existing or recreate
    const currentFiles = await getSourceFiles(true);

    for (const snapFile of version.changedFiles || []) {
      const existing = currentFiles.find((f) => f.filePath === snapFile.filePath);
      if (existing) {
        await updateDoc(doc(db, FILES_COL, existing.id), {
          sourceCode: snapFile.sourceCode,
          currentVersion: snapFile.version || version.versionNumber,
          isArchived: false,
          isActive: true,
          lastModified: now,
          modifiedBy: userEmail,
          updatedAt: now,
        });
      } else {
        await addDoc(collection(db, FILES_COL), {
          fileName: snapFile.fileName,
          filePath: snapFile.filePath,
          fileType: snapFile.fileType,
          sourceCode: snapFile.sourceCode,
          currentVersion: snapFile.version || version.versionNumber,
          description: `Restored from version ${version.versionNumber}`,
          isActive: true,
          isArchived: false,
          lastModified: now,
          modifiedBy: userEmail,
          createdAt: now,
          updatedAt: now,
        });
      }
      restoredCount++;
    }

    await addSourceChangeLog({
      date: now,
      version: version.versionNumber,
      file: 'All Version Files',
      action: 'Restored',
      changedBy: userEmail,
      description: `Restored full system snapshot to version ${version.versionNumber} (${restoredCount} files)`,
    });

    return { restoredCount };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, VERSIONS_COL);
  }
}

// ---------------- CHANGE LOG ----------------

export async function getSourceChangeLogs(): Promise<SourceChangeLogEntry[]> {
  try {
    const snap = await getDocs(collection(db, CHANGELOG_COL));
    const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SourceChangeLogEntry));
    list.sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, CHANGELOG_COL);
  }
}

export async function addSourceChangeLog(
  entry: Omit<SourceChangeLogEntry, 'id' | 'createdAt'>
): Promise<string> {
  try {
    const docRef = await addDoc(collection(db, CHANGELOG_COL), {
      ...entry,
      createdAt: new Date().toISOString(),
    });
    return docRef.id;
  } catch (error) {
    console.warn('Failed to record source changelog:', error);
    return '';
  }
}

// ---------------- IMPORT / EXPORT SYSTEM ----------------

export async function exportSourceZip(
  files: SourceFile[],
  version: string = '1.0.0'
): Promise<Blob> {
  const zip = new JSZip();
  const root = zip.folder('E-SHOP-SOURCE');

  const includedFiles: string[] = [];
  const excludedFiles: string[] = [
    '.env',
    '.env.local',
    'firebase-applet-config.json',
    'serviceAccountKey.json',
    'secrets.json',
  ];

  files.forEach((file) => {
    if (file.isArchived) return;
    const cleanPath = file.filePath.replace(/^\/+/, '');
    root?.file(cleanPath, file.sourceCode);
    includedFiles.push(cleanPath);
  });

  // Include Manifest
  const manifest: SourceManifest = {
    projectName: 'E-SHOP Modern E-Commerce',
    exportVersion: version,
    exportDate: new Date().toISOString(),
    applicationVersion: '2.0.0',
    includedFiles,
    excludedFiles,
    sourceManagerVersion: '1.2.0',
  };

  root?.file('source-manifest.json', JSON.stringify(manifest, null, 2));
  root?.file(
    'README.md',
    `# E-SHOP Modern E-Commerce Source Export\n\n` +
      `Exported from E-SHOP Source Manager on ${new Date().toUTCString()}.\n` +
      `Total Files: ${includedFiles.length}\n` +
      `Active Release: ${version}\n\n` +
      `Note: Security credentials and private environment secrets are excluded by design.\n`
  );

  const content = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  return content;
}

export async function parseImportZip(file: File): Promise<{
  valid: boolean;
  error?: string;
  files: Array<{ fileName: string; filePath: string; fileType: string; sourceCode: string }>;
  dangerousFilesDetected: string[];
}> {
  try {
    const zip = await JSZip.loadAsync(file);
    const parsedFiles: Array<{ fileName: string; filePath: string; fileType: string; sourceCode: string }> = [];
    const dangerous: string[] = [];

    const dangerousExtensions = ['.exe', '.bat', '.cmd', '.sh', '.dll', '.so', '.bin', '.vbs', '.ps1'];

    for (const relativePath of Object.keys(zip.files)) {
      const zipEntry = zip.files[relativePath];
      if (zipEntry.dir) continue;

      const lower = relativePath.toLowerCase();

      // Check dangerous files
      if (dangerousExtensions.some((ext) => lower.endsWith(ext))) {
        dangerous.push(relativePath);
        continue;
      }

      // Ignore metadata or hidden mac files
      if (lower.includes('__macosx') || lower.endsWith('.ds_store')) {
        continue;
      }

      const content = await zipEntry.async('string');
      // Normalize path (strip initial E-SHOP-SOURCE/ if present)
      const cleanPath = relativePath.replace(/^E-SHOP-SOURCE\//i, '');
      const parts = cleanPath.split('/');
      const fileName = parts[parts.length - 1];
      const ext = fileName.includes('.') ? fileName.split('.').pop() || 'txt' : 'txt';

      parsedFiles.push({
        fileName,
        filePath: cleanPath,
        fileType: ext.toLowerCase(),
        sourceCode: content,
      });
    }

    return {
      valid: true,
      files: parsedFiles,
      dangerousFilesDetected: dangerous,
    };
  } catch (err: any) {
    return {
      valid: false,
      error: err.message || 'Unable to parse ZIP file.',
      files: [],
      dangerousFilesDetected: [],
    };
  }
}

export async function commitSourceImportBatch(
  files: Array<{ fileName: string; filePath: string; fileType: string; sourceCode: string; version?: string }>,
  userEmail: string
): Promise<{ importedCount: number }> {
  try {
    const existingFiles = await getSourceFiles(true);
    let importedCount = 0;
    const now = new Date().toISOString();

    for (const item of files) {
      const match = existingFiles.find((f) => f.filePath === item.filePath);
      if (match) {
        await updateDoc(doc(db, FILES_COL, match.id), {
          sourceCode: item.sourceCode,
          fileType: item.fileType,
          currentVersion: item.version || '1.1.0',
          lastModified: now,
          modifiedBy: userEmail,
          isArchived: false,
          isActive: true,
          updatedAt: now,
        });
      } else {
        await addDoc(collection(db, FILES_COL), {
          fileName: item.fileName,
          filePath: item.filePath,
          fileType: item.fileType,
          sourceCode: item.sourceCode,
          currentVersion: item.version || '1.0.0',
          description: 'Imported via Source Archive',
          lastModified: now,
          modifiedBy: userEmail,
          isActive: true,
          isArchived: false,
          createdAt: now,
          updatedAt: now,
        });
      }
      importedCount++;
    }

    await addSourceChangeLog({
      date: now,
      version: '1.2.0',
      file: 'Source Archive Batch',
      action: 'Added',
      changedBy: userEmail,
      description: `Imported and synchronized ${importedCount} files from ZIP archive`,
    });

    return { importedCount };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, FILES_COL);
  }
}

// ---------------- INITIAL STARTER SOURCE SEEDING ----------------

export async function seedInitialSourceFilesIfEmpty(userEmail: string): Promise<boolean> {
  try {
    const existing = await getDocs(collection(db, FILES_COL));
    if (!existing.empty) return false;

    console.log('Seeding initial Source Manager repository files into Firestore...');
    const now = new Date().toISOString();

    const starterFiles: Omit<SourceFile, 'id' | 'createdAt' | 'updatedAt'>[] = [
      {
        fileName: 'ProductCard.tsx',
        filePath: 'src/components/ProductCard.tsx',
        fileType: 'tsx',
        currentVersion: '1.2.0',
        description: 'Modern customer-facing product card with hover quick-view and pricing badges',
        changeNotes: 'Added sale discount chip and inventory status',
        lastModified: now,
        modifiedBy: userEmail || 'system_admin',
        isActive: true,
        isArchived: false,
        sourceCode: `import React from 'react';
import { ShoppingBag, Eye, Star, Sparkles } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onViewDetails: (slug: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onViewDetails,
}) => {
  const hasDiscount = product.discountPrice && product.discountPrice < product.price;

  return (
    <div className="group relative bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
      <div className="relative aspect-square overflow-hidden bg-slate-50 cursor-pointer" onClick={() => onViewDetails(product.slug)}>
        <img
          src={product.mainImage}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        {hasDiscount && (
          <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-rose-600 text-white font-bold text-[10px] tracking-wide shadow-sm">
            SALE
          </span>
        )}
      </div>
      <div className="p-5 space-y-3">
        <h3 className="font-bold text-sm text-slate-800 line-clamp-1">{product.name}</h3>
        <div className="flex items-center justify-between">
          <span className="font-extrabold text-slate-900">\${(product.discountPrice ?? product.price).toFixed(2)}</span>
          <button onClick={() => onAddToCart(product)} className="p-2.5 rounded-xl bg-slate-900 text-white hover:bg-amber-500 hover:text-slate-950 transition-colors">
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};`,
      },
      {
        fileName: 'Navbar.tsx',
        filePath: 'src/components/Navbar.tsx',
        fileType: 'tsx',
        currentVersion: '1.2.0',
        description: 'Global responsive application header with search, cart badge, and auth state',
        changeNotes: 'Added mobile hamburger menu and cart counter badge',
        lastModified: now,
        modifiedBy: userEmail || 'system_admin',
        isActive: true,
        isArchived: false,
        sourceCode: `import React, { useState } from 'react';
import { ShoppingBag, Search, Menu, X, ShieldCheck } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';

export const Navbar: React.FC<{ onNavigate: (path: string) => void }> = ({ onNavigate }) => {
  const { totalItemCount } = useCart();
  const { isAdmin } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <div className="font-black text-xl tracking-tight text-slate-950 cursor-pointer" onClick={() => onNavigate('/')}>
          E - SHOP
        </div>
        <nav className="flex items-center gap-4">
          <button onClick={() => onNavigate('/products')} className="text-xs font-semibold text-slate-600 hover:text-slate-950">Catalog</button>
          <button onClick={() => onNavigate('/cart')} className="relative p-2 text-slate-800">
            <ShoppingBag className="w-5 h-5" />
            {totalItemCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black flex items-center justify-center">
                {totalItemCount}
              </span>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
};`,
      },
      {
        fileName: 'types.ts',
        filePath: 'src/types/index.ts',
        fileType: 'ts',
        currentVersion: '1.2.0',
        description: 'Complete TypeScript data models for Products, Orders, Categories, and Source Manager',
        changeNotes: 'Added Source Manager entity definitions',
        lastModified: now,
        modifiedBy: userEmail || 'system_admin',
        isActive: true,
        isArchived: false,
        sourceCode: `export type OrderStatus = 'Pending' | 'Confirmed' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';\nexport interface Product { id: string; name: string; slug: string; price: number; stock: number; category: string; mainImage: string; }\nexport interface Category { id: string; name: string; slug: string; isActive: boolean; }\nexport interface Order { id: string; orderNumber: string; totalAmount: number; orderStatus: OrderStatus; }`,
      },
      {
        fileName: 'package.json',
        filePath: 'package.json',
        fileType: 'json',
        currentVersion: '1.2.0',
        description: 'Core project manifest, scripts, and runtime package dependencies',
        changeNotes: 'Added JSZip support for offline export',
        lastModified: now,
        modifiedBy: userEmail || 'system_admin',
        isActive: true,
        isArchived: false,
        sourceCode: `{\n  "name": "eshop-modern",\n  "version": "1.2.0",\n  "private": true,\n  "dependencies": {\n    "react": "^19.0.0",\n    "firebase": "^12.0.0",\n    "jszip": "^3.10.1",\n    "lucide-react": "^0.546.0"\n  }\n}`,
      },
      {
        fileName: 'config.ts',
        filePath: 'src/firebase/config.ts',
        fileType: 'ts',
        currentVersion: '1.2.0',
        description: 'Firebase application initialization with secure Firestore and Auth instances',
        changeNotes: 'Configured Firestore database ID and Auth',
        lastModified: now,
        modifiedBy: userEmail || 'system_admin',
        isActive: true,
        isArchived: false,
        sourceCode: `import { initializeApp, getApps, getApp } from 'firebase/app';\nimport { getFirestore } from 'firebase/firestore';\nimport { getAuth } from 'firebase/auth';\n// Firebase initialized with environment config`,
      },
    ];

    const seededIds: string[] = [];
    for (const f of starterFiles) {
      const docRef = await addDoc(collection(db, FILES_COL), {
        ...f,
        createdAt: now,
        updatedAt: now,
      });
      seededIds.push(docRef.id);
    }

    // Seed initial release version
    await addDoc(collection(db, VERSIONS_COL), {
      versionNumber: '1.2.0',
      releaseTitle: 'Admin Source Manager & Storefront Suite',
      releaseNotes: 'Complete upgrade introducing Source Manager, Version History, Change Log, and ZIP Source Export.',
      changedFiles: starterFiles.map((f, i) => ({
        fileId: seededIds[i],
        fileName: f.fileName,
        filePath: f.filePath,
        fileType: f.fileType,
        version: f.currentVersion,
        sourceCode: f.sourceCode,
      })),
      createdDate: now,
      createdBy: userEmail || 'mrokan753@gmail.com',
      status: 'Active',
      createdAt: now,
      updatedAt: now,
    });

    // Seed changelog
    await addDoc(collection(db, CHANGELOG_COL), {
      date: now,
      version: '1.2.0',
      file: 'System Initialization',
      action: 'Added',
      changedBy: userEmail || 'mrokan753@gmail.com',
      description: 'Initial repository seeding with core UI components and TypeScript types.',
      createdAt: now,
    });

    return true;
  } catch (error) {
    console.error('Failed to seed starter source files:', error);
    return false;
  }
}
