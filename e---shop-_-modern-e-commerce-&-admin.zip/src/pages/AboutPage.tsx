import React from 'react';
import { ShieldCheck, Sparkles, Award, Globe, ArrowRight } from 'lucide-react';

interface AboutPageProps {
  onNavigate: (path: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-16">
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          The E - SHOP Philosophy
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
          Pioneering the Future of Premium Digital Commerce
        </h1>
        <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
          Founded with a commitment to engineering precision, timeless aesthetics, and frictionless technology, E - SHOP delivers curated high-end products to creators and discerning individuals across the globe.
        </p>
      </div>

      <div className="relative rounded-3xl overflow-hidden shadow-2xl h-80 sm:h-96">
        <img
          src="https://images.unsplash.com/photo-1497215728101-856f4ea42174?auto=format&fit=crop&w=1400&q=80"
          alt="E-SHOP studio"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent flex items-end p-8">
          <p className="text-white text-sm sm:text-base font-medium max-w-lg">
            &ldquo;Every item in our collection is rigorously evaluated for build quality, sustainable materials, and enduring design integrity.&rdquo;
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Zero Compromise Quality</h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            From CNC-milled titanium smartwatches to handcrafted Italian leather goods, we partner exclusively with verified master manufacturers.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Globe className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Carbon-Neutral Logistics</h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            All customer shipments are carbon-neutralized with 100% recyclable biodegradable packaging and express route optimization.
          </p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Lifetime Support & Care</h3>
          <p className="text-sm text-slate-500 leading-relaxed">
            Every product includes full manufacturer warranties, dedicated concierge technical support, and hassle-free returns.
          </p>
        </div>
      </div>

      <div className="text-center pt-8">
        <button
          onClick={() => onNavigate('/products')}
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-100"
        >
          <span>Explore Current Catalog</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
