import React, { useState } from 'react';
import { useCart } from '../contexts/CartContext';
import { EmptyState } from '../components/EmptyState';
import {
  Trash2,
  ArrowRight,
  ShieldCheck,
  ShoppingBag,
  ArrowLeft,
  Tag,
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { getCouponByCode } from '../firebase/services';

interface CartPageProps {
  onNavigate: (path: string) => void;
}

export const CartPage: React.FC<CartPageProps> = ({ onNavigate }) => {
  const {
    items,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    discount,
    shippingFee,
    totalAmount,
  } = useCart();

  const [couponCode, setCouponCode] = useState('');
  const [couponDiscount, setCouponDiscount] = useState(0);
  const { showToast } = useToast();

  const handleApplyCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;

    try {
      const liveCoupon = await getCouponByCode(couponCode.trim());
      if (liveCoupon && liveCoupon.isActive) {
        if (new Date(liveCoupon.expiryDate) < new Date()) {
          showToast('This coupon code has expired.', 'warning');
          return;
        }
        if (subtotal < liveCoupon.minOrderAmount) {
          showToast(`Minimum order amount of $${liveCoupon.minOrderAmount} required for this coupon.`, 'warning');
          return;
        }
        if (liveCoupon.discountType === 'percentage') {
          const calculated = (subtotal * liveCoupon.discountValue) / 100;
          const capped = liveCoupon.maxDiscount ? Math.min(calculated, liveCoupon.maxDiscount) : calculated;
          setCouponDiscount(Math.round(capped));
        } else {
          setCouponDiscount(Math.round(liveCoupon.discountValue));
        }
        showToast(`Coupon "${liveCoupon.code}" applied successfully!`, 'success');
        return;
      }
    } catch {
      // Continue to static check
    }

    if (couponCode.trim().toUpperCase() === 'ESHOP10') {
      const disc = Math.round(subtotal * 0.1);
      setCouponDiscount(disc);
      showToast('10% VIP Coupon code applied successfully!', 'success');
    } else {
      showToast('Invalid or expired coupon code.', 'warning');
    }
  };

  const finalTotal = Math.max(0, totalAmount - couponDiscount);

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <EmptyState
          icon={ShoppingBag}
          title="Your Shopping Cart is Empty"
          description="Looks like you haven't added anything to your cart yet. Explore our latest arrivals and exclusive deals."
          actionText="Start Shopping"
          onAction={() => onNavigate('/products')}
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="flex items-center justify-between pb-6 border-b border-slate-200 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Shopping Cart
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Review your items and proceed to secure checkout
          </p>
        </div>
        <button
          onClick={clearCart}
          className="text-xs text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1.5"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear All
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Cart Items List */}
        <div className="lg:col-span-2 space-y-4">
          {items.map(({ product, quantity }) => {
            const unitPrice = product.discountPrice ?? product.price;
            const lineTotal = unitPrice * quantity;

            return (
              <div
                key={product.id}
                className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 sm:p-5 rounded-2xl bg-white border border-slate-100 shadow-xs hover:shadow-sm transition-all gap-4"
              >
                {/* Thumbnail & Titles */}
                <div
                  onClick={() => onNavigate(`/product/${product.slug}`)}
                  className="flex items-center gap-4 cursor-pointer group flex-1"
                >
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-slate-50 shrink-0 border border-slate-100">
                    <img
                      src={product.mainImage}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      {product.brand}
                    </span>
                    <h3 className="font-semibold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-indigo-600 transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      SKU: <span className="font-mono">{product.sku}</span>
                    </p>
                    <div className="text-sm font-bold text-slate-900 mt-1 sm:hidden">
                      ${unitPrice.toFixed(2)}
                    </div>
                  </div>
                </div>

                {/* Quantity Controls & Line Total */}
                <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  <div className="hidden sm:block text-right">
                    <p className="text-xs text-slate-400">Unit Price</p>
                    <p className="text-sm font-bold text-slate-900">${unitPrice.toFixed(2)}</p>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center border border-slate-200 rounded-xl bg-slate-50">
                    <button
                      onClick={() => updateQuantity(product.id, quantity - 1)}
                      className="px-2.5 py-1 text-slate-600 hover:text-slate-900 font-bold"
                      aria-label="Decrease quantity"
                    >
                      -
                    </button>
                    <span className="px-3 py-1 text-xs font-semibold text-slate-900 min-w-[28px] text-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(product.id, quantity + 1)}
                      disabled={quantity >= product.stock}
                      className="px-2.5 py-1 text-slate-600 hover:text-slate-900 font-bold disabled:opacity-40"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>

                  {/* Line Total */}
                  <div className="text-right min-w-[70px]">
                    <p className="text-xs text-slate-400 hidden sm:block">Subtotal</p>
                    <p className="text-base font-extrabold text-slate-900">
                      ${lineTotal.toFixed(2)}
                    </p>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => removeFromCart(product.id)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                    title="Remove item"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}

          <div className="pt-4">
            <button
              onClick={() => onNavigate('/products')}
              className="inline-flex items-center gap-2 text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Continue Shopping
            </button>
          </div>
        </div>

        {/* Order Summary Sidebar */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <h2 className="text-lg font-bold text-slate-900">Order Summary</h2>

            {/* Promo Code Input */}
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Discount code (e.g. ESHOP10)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full pl-8 pr-3 py-2 text-xs rounded-xl border border-slate-200 uppercase tracking-wider outline-none focus:border-indigo-500"
                />
                <Tag className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors"
              >
                Apply
              </button>
            </form>

            {/* Calculations Breakdown */}
            <div className="space-y-3 text-sm border-t border-slate-100 pt-4">
              <div className="flex justify-between text-slate-600">
                <span>Items Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Product Savings</span>
                  <span>-${discount.toFixed(2)}</span>
                </div>
              )}

              {couponDiscount > 0 && (
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>VIP Promo (ESHOP10)</span>
                  <span>-${couponDiscount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between text-slate-600">
                <span>Estimated Shipping</span>
                <span>{shippingFee === 0 ? 'FREE' : `$${shippingFee.toFixed(2)}`}</span>
              </div>

              <div className="flex justify-between text-lg font-extrabold text-slate-900 pt-3 border-t border-slate-100">
                <span>Total Amount</span>
                <span>${finalTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Proceed to Checkout button */}
            <button
              onClick={() => onNavigate('/checkout')}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-100 active:scale-98"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* Security Guarantee */}
            <div className="flex items-center justify-center gap-2 text-xs text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Safe 256-Bit SSL Encrypted Checkout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
