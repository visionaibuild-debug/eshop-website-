import React, { useState, useEffect } from 'react';
import { Category, Product } from '../types';
import { getCategories, getProducts } from '../firebase/services';
import { ArrowRight, Layers } from 'lucide-react';

interface CategoriesPageProps {
  onNavigate: (path: string) => void;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ onNavigate }) => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      try {
        const [catRes, prodRes] = await Promise.all([getCategories(), getProducts()]);
        if (isMounted) {
          setCategories(catRes?.filter((c) => c.isActive) || []);
          setProducts(prodRes || []);
        }
      } catch (err) {
        console.error('Error fetching categories:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, []);

  const getProductCountForCategory = (catName: string) => {
    return products.filter((p) => p.category?.toLowerCase() === catName.toLowerCase() && p.isPublished).length;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold uppercase tracking-wider mb-3">
          <Layers className="w-3.5 h-3.5" />
          <span>Catalog Explorer</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Browse All Categories
        </h1>
        <p className="text-slate-500 text-sm sm:text-base mt-2">
          Discover handpicked tech, audio monitors, designer wearables, and productivity essentials.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-64 bg-slate-200 rounded-3xl animate-pulse" />
            ))
          : categories.map((cat) => {
              const count = getProductCountForCategory(cat.name);
              return (
                <div
                  key={cat.id}
                  onClick={() =>
                    onNavigate(`/products?category=${encodeURIComponent(cat.name)}`)
                  }
                  className="group relative h-72 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer bg-slate-900"
                >
                  <img
                    src={
                      cat.image ||
                      'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=800&q=80'
                    }
                    alt={cat.name}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out brightness-[0.65]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                  <div className="absolute inset-0 p-6 flex flex-col justify-end">
                    <span className="text-xs font-semibold text-indigo-300 uppercase tracking-wider mb-1">
                      {count} {count === 1 ? 'Product' : 'Products'} Available
                    </span>
                    <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-indigo-200 transition-colors">
                      {cat.name}
                    </h3>
                    {cat.description && (
                      <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 mb-4 font-normal">
                        {cat.description}
                      </p>
                    )}
                    <div className="flex items-center gap-1.5 text-xs font-bold text-white group-hover:translate-x-1 transition-transform">
                      <span>Explore Category</span>
                      <ArrowRight className="w-4 h-4 text-indigo-400" />
                    </div>
                  </div>
                </div>
              );
            })}
      </div>
    </div>
  );
};
