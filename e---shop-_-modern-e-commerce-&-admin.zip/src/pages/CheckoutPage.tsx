import React, { useState, useEffect } from 'react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { createOrder, getProductById, updateProduct } from '../firebase/services';
import { OrderItem, Order } from '../types';
import { useToast } from '../contexts/ToastContext';
import confetti from 'canvas-confetti';
import {
  ShieldCheck,
  CreditCard,
  Banknote,
  Smartphone,
  CheckCircle2,
  Lock,
  ArrowRight,
  ShoppingBag,
} from 'lucide-react';

interface CheckoutPageProps {
  onNavigate: (path: string) => void;
}

export const CheckoutPage: React.FC<CheckoutPageProps> = ({ onNavigate }) => {
  const { items, subtotal, shippingFee, totalAmount, clearCart } = useCart();
  const { user, userProfile } = useAuth();
  const { showToast } = useToast();

  const [formData, setFormData] = useState({
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    shippingAddress: '',
    city: '',
    area: '',
    deliveryNotes: '',
    paymentMethod: 'Cash on Delivery' as 'Cash on Delivery' | 'Credit/Debit Card' | 'Mobile Banking',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderCompleted, setOrderCompleted] = useState<Order | null>(null);

  // Auto-fill customer profile details
  useEffect(() => {
    if (user || userProfile) {
      setFormData((prev) => ({
        ...prev,
        customerName: userProfile?.displayName || user?.displayName || prev.customerName,
        customerEmail: userProfile?.email || user?.email || prev.customerEmail,
        customerPhone: userProfile?.phone || prev.customerPhone,
        shippingAddress: userProfile?.address || prev.shippingAddress,
        city: userProfile?.city || prev.city,
        area: userProfile?.area || prev.area,
      }));
    }
  }, [user, userProfile]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();

    if (items.length === 0) {
      showToast('Your shopping cart is empty.', 'warning');
      return;
    }

    // Validation
    if (
      !formData.customerName.trim() ||
      !formData.customerEmail.trim() ||
      !formData.customerPhone.trim() ||
      !formData.shippingAddress.trim() ||
      !formData.city.trim() ||
      !formData.area.trim()
    ) {
      showToast('Please fill in all required shipping fields.', 'warning');
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Verify stocks before placing order
      for (const item of items) {
        const liveProduct = await getProductById(item.product.id);
        if (!liveProduct || liveProduct.stock < item.quantity) {
          showToast(
            `Sorry, "${item.product.name}" only has ${liveProduct?.stock || 0} left in stock. Please adjust your cart.`,
            'error'
          );
          setIsSubmitting(false);
          return;
        }
      }

      // 2. Prepare Order Items
      const orderItems: OrderItem[] = items.map((i) => ({
        productId: i.product.id,
        name: i.product.name,
        slug: i.product.slug,
        price: i.product.price,
        discountPrice: i.product.discountPrice,
        quantity: i.quantity,
        image: i.product.mainImage,
        sku: i.product.sku,
      }));

      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const orderNumber = `ESHOP-${Date.now().toString().slice(-6)}-${randomSuffix}`;

      const newOrderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'> = {
        orderNumber,
        userId: user ? user.uid : 'guest',
        customerName: formData.customerName.trim(),
        customerEmail: formData.customerEmail.trim(),
        customerPhone: formData.customerPhone.trim(),
        shippingAddress: formData.shippingAddress.trim(),
        city: formData.city.trim(),
        area: formData.area.trim(),
        deliveryNotes: formData.deliveryNotes.trim(),
        items: orderItems,
        subtotal,
        shippingFee,
        discount: 0,
        totalAmount,
        paymentMethod: formData.paymentMethod,
        paymentStatus: formData.paymentMethod === 'Cash on Delivery' ? 'Pending' : 'Paid',
        orderStatus: 'Pending',
      };

      // 3. Save order to Cloud Firestore
      const orderId = await createOrder(newOrderData);

      // 4. Decrement product stock in Firestore
      for (const item of items) {
        try {
          const liveProduct = await getProductById(item.product.id);
          if (liveProduct) {
            await updateProduct(item.product.id, {
              stock: Math.max(0, liveProduct.stock - item.quantity),
            });
          }
        } catch (stockErr) {
          console.warn('Non-fatal stock sync warning:', stockErr);
        }
      }

      // 5. Trigger celebration confetti
      try {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore confetti failure if canvas not supported
      }

      const completedOrder: Order = {
        id: orderId,
        ...newOrderData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setOrderCompleted(completedOrder);
      clearCart();
      showToast('Order placed successfully! Thank you.', 'success');
    } catch (err) {
      console.error('Checkout error:', err);
      showToast('Could not complete order. Please try again.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Order Success Screen
  if (orderCompleted) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
          Thank You for Your Order!
        </h1>
        <p className="text-slate-500 mb-6">
          Your order{' '}
          <span className="font-mono font-bold text-slate-900">
            #{orderCompleted.orderNumber}
          </span>{' '}
          has been confirmed and is now being processed.
        </p>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm text-left mb-8 space-y-4">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100">
            <div>
              <p className="text-xs text-slate-400 font-medium">Order Status</p>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 mt-0.5">
                {orderCompleted.orderStatus}
              </span>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-400 font-medium">Total Paid</p>
              <p className="text-base font-extrabold text-slate-900">
                ${orderCompleted.totalAmount.toFixed(2)}
              </p>
            </div>
          </div>

          <div>
            <p className="text-xs text-slate-400 font-medium">Shipping Destination</p>
            <p className="text-sm font-semibold text-slate-800">
              {orderCompleted.customerName} ({orderCompleted.customerPhone})
            </p>
            <p className="text-xs text-slate-600">
              {orderCompleted.shippingAddress}, {orderCompleted.area}, {orderCompleted.city}
            </p>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <p className="text-xs text-slate-400 font-medium mb-2">Ordered Items</p>
            <div className="space-y-2">
              {orderCompleted.items.map((item, idx) => (
                <div key={idx} className="flex justify-between text-xs">
                  <span className="text-slate-700">
                    {item.quantity}x {item.name}
                  </span>
                  <span className="font-semibold text-slate-900">
                    ${((item.discountPrice ?? item.price) * item.quantity).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => onNavigate(`/orders`)}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all"
          >
            View My Orders
          </button>
          <button
            onClick={() => onNavigate('/products')}
            className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-sm transition-all"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-md mx-auto text-center">
          <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Your Cart is Empty</h2>
          <p className="text-slate-500 text-sm mb-6">
            Please add items to your cart before proceeding to checkout.
          </p>
          <button
            onClick={() => onNavigate('/products')}
            className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-sm hover:bg-indigo-700"
          >
            Browse Catalog
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="pb-6 border-b border-slate-200 mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Checkout
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Complete your delivery and payment information
        </p>
      </div>

      <form onSubmit={handleSubmitOrder}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Shipping & Payment Form */}
          <div className="lg:col-span-2 space-y-8">
            {/* 1. Customer & Delivery Information */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-5">
              <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
                1. Delivery Details
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="customerName"
                    required
                    placeholder="e.g. Alexander Vance"
                    value={formData.customerName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="customerPhone"
                    required
                    placeholder="e.g. +1 (555) 234-5678"
                    value={formData.customerPhone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="customerEmail"
                  required
                  placeholder="e.g. alexander@example.com"
                  value={formData.customerEmail}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                  Street Address *
                </label>
                <input
                  type="text"
                  name="shippingAddress"
                  required
                  placeholder="e.g. 742 Evergreen Terrace, Suite 4B"
                  value={formData.shippingAddress}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                    City *
                  </label>
                  <input
                    type="text"
                    name="city"
                    required
                    placeholder="e.g. San Francisco"
                    value={formData.city}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                    Area / State / Zip *
                  </label>
                  <input
                    type="text"
                    name="area"
                    required
                    placeholder="e.g. California 94107"
                    value={formData.area}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1.5">
                  Special Delivery Instructions (Optional)
                </label>
                <textarea
                  name="deliveryNotes"
                  rows={2}
                  placeholder="e.g. Ring doorbell or leave with concierge"
                  value={formData.deliveryNotes}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 outline-none"
                />
              </div>
            </div>

            {/* 2. Payment Method */}
            <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-4">
              <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
                2. Payment Method
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <label
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    formData.paymentMethod === 'Cash on Delivery'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 font-semibold'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="Cash on Delivery"
                    checked={formData.paymentMethod === 'Cash on Delivery'}
                    onChange={handleInputChange}
                    className="sr-only"
                  />
                  <Banknote className="w-6 h-6 mb-2" />
                  <span className="text-xs text-center">Cash on Delivery</span>
                </label>

                <label
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    formData.paymentMethod === 'Credit/Debit Card'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 font-semibold'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="Credit/Debit Card"
                    checked={formData.paymentMethod === 'Credit/Debit Card'}
                    onChange={handleInputChange}
                    className="sr-only"
                  />
                  <CreditCard className="w-6 h-6 mb-2" />
                  <span className="text-xs text-center">Credit / Debit Card</span>
                </label>

                <label
                  className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                    formData.paymentMethod === 'Mobile Banking'
                      ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700 font-semibold'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="Mobile Banking"
                    checked={formData.paymentMethod === 'Mobile Banking'}
                    onChange={handleInputChange}
                    className="sr-only"
                  />
                  <Smartphone className="w-6 h-6 mb-2" />
                  <span className="text-xs text-center">Mobile Banking</span>
                </label>
              </div>

              {formData.paymentMethod === 'Credit/Debit Card' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-2">
                  <p className="font-semibold text-slate-800">Card Payment Simulator (Sandbox)</p>
                  <p>In this prototype demo, payment is processed securely via mock gateway.</p>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Order Review & Submit */}
          <div>
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6 sticky top-24">
              <h3 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
                Order Review ({items.length} {items.length === 1 ? 'item' : 'items'})
              </h3>

              {/* Items overview */}
              <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
                {items.map(({ product, quantity }) => {
                  const price = product.discountPrice ?? product.price;
                  return (
                    <div key={product.id} className="flex items-center gap-3">
                      <img
                        src={product.mainImage}
                        alt={product.name}
                        className="w-12 h-12 rounded-xl object-cover border border-slate-100 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-slate-800 truncate">
                          {product.name}
                        </p>
                        <p className="text-[11px] text-slate-400">Qty: {quantity}</p>
                      </div>
                      <span className="text-xs font-bold text-slate-900">
                        ${(price * quantity).toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Price calculations */}
              <div className="space-y-2.5 text-xs text-slate-600 border-t border-slate-100 pt-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>{shippingFee === 0 ? 'FREE' : `$${shippingFee.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-base font-extrabold text-slate-900 pt-2 border-t border-slate-100">
                  <span>Grand Total</span>
                  <span>${totalAmount.toFixed(2)}</span>
                </div>
              </div>

              {/* Place Order CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 py-4 px-6 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-100 disabled:opacity-50 active:scale-98"
              >
                {isSubmitting ? (
                  <span>Processing Order...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Confirm & Place Order</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>100% Secure Checkout Guarantee</span>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
