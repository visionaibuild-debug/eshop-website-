import React, { useEffect, useState } from 'react';
import { Product, Category, Banner } from '../types';
import {
  getProducts,
  getCategories,
  getActiveBanners,
} from '../firebase/services';
import { BannerCarousel } from '../components/BannerCarousel';
import { PromoBanner } from '../components/PromoBanner';
import { ProductCard } from '../components/ProductCard';
import { ProductCardSkeleton, BannerSkeleton } from '../components/SkeletonLoader';
import { ArrowRight, Flame, Sparkles, TrendingUp, Layers } from 'lucide-react';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const [heroBanners, setHeroBanners] = useState<Banner[]>([]);
  const [middleBanner, setMiddleBanner] = useState<Banner | null>(null);
  const [bottomBanner, setBottomBanner] = useState<Banner | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [latestProducts, setLatestProducts] = useState<Product[]>([]);
  const [popularProducts, setPopularProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;

    async function loadHomeData() {
      try {
        const [heroRes, midRes, botRes, catRes, allProds] = await Promise.all([
          getActiveBanners('home_hero').catch(() => []),
          getActiveBanners('homepage_middle').catch(() => []),
          getActiveBanners('bottom_advertisement').catch(() => []),
          getCategories().catch(() => []),
          getProducts({ limitCount: 24 }).catch(() => []),
        ]);

        if (isMounted) {
          setHeroBanners(heroRes || []);
          if (midRes && midRes.length > 0) setMiddleBanner(midRes[0]);
          if (botRes && botRes.length > 0) setBottomBanner(botRes[0]);
          setCategories(catRes?.filter((c) => c.isActive) || []);

          if (allProds) {
            setFeaturedProducts(allProds.filter((p) => p.isFeatured && p.isPublished).slice(0, 4));
            setPopularProducts(allProds.filter((p) => p.isPopular && p.isPublished).slice(0, 4));
            // Sort by newest for latest arrivals
            const sortedByNew = [...allProds]
              .filter((p) => p.isPublished)
              .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
            setLatestProducts(sortedByNew.slice(0, 8));
          }
        }
      } catch (err) {
        console.error('Error loading homepage:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadHomeData();

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="space-y-16 sm:space-y-20">
      {/* 1. Hero Banner Carousel */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 sm:pt-6">
        {loading ? (
          <BannerSkeleton />
        ) : (
          heroBanners.length > 0 && (
            <BannerCarousel
              banners={heroBanners}
              onNavigate={(url) => onNavigate(url)}
            />
          )
        )}
      </section>

      {/* 2. Category Highlights */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6 sm:mb-8">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 font-semibold text-xs uppercase tracking-wider mb-1">
              <Layers className="w-4 h-4" />
              <span>Curated Collections</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Explore by Category
            </h2>
          </div>
          <button
            onClick={() => onNavigate('/categories')}
            className="group flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
          >
            <span>All Categories</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
          {loading
            ? Array.from({ length: 5 }).map((_, i) => (
                <div
                  key={i}
                  className="aspect-square bg-slate-100 rounded-2xl animate-pulse"
                />
              ))
            : categories.map((cat) => (
                <div
                  key={cat.id}
                  onClick={() =>
                    onNavigate(`/products?category=${encodeURIComponent(cat.name)}`)
                  }
                  className="group relative aspect-square rounded-2xl overflow-hidden bg-slate-900 cursor-pointer shadow-sm hover:shadow-xl transition-all duration-300"
                >
                  <img
                    src={
                      cat.image ||
                      'https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=600&q=80'
                    }
                    alt={cat.name}
                    className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-500 ease-out brightness-[0.7]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
                  <div className="absolute bottom-3 left-3 right-3">
                    <p className="text-white text-xs sm:text-sm font-bold leading-tight group-hover:text-indigo-300 transition-colors">
                      {cat.name}
                    </p>
                  </div>
                </div>
              ))}
        </div>
      </section>

      {/* 3. Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6 sm:mb-8">
            <div>
              <div className="flex items-center gap-2 text-rose-600 font-semibold text-xs uppercase tracking-wider mb-1">
                <Sparkles className="w-4 h-4" />
                <span>Handpicked Excellence</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
                Featured Products
              </h2>
            </div>
            <button
              onClick={() => onNavigate('/products?featured=true')}
              className="group flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
            >
              <span>View All</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {loading
              ? Array.from({ length: 4 }).map((_, i) => <ProductCardSkeleton key={i} />)
              : featuredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onNavigate={(slug) => onNavigate(`/product/${slug}`)}
                  />
                ))}
          </div>
        </section>
      )}

      {/* 4. Middle Promotional Banner */}
      {middleBanner && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <PromoBanner
            banner={middleBanner}
            onNavigate={(url) => onNavigate(url)}
          />
        </section>
      )}

      {/* 5. Latest Arrivals */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6 sm:mb-8">
          <div>
            <div className="flex items-center gap-2 text-indigo-600 font-semibold text-xs uppercase tracking-wider mb-1">
              <Flame className="w-4 h-4 text-amber-500" />
              <span>Just In Stock</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
              Latest Arrivals
            </h2>
          </div>
          <button
            onClick={() => onNavigate('/products')}
            className="group flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
          >
            <span>See Catalog</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {loading
            ? Array.from({ length: 8 }).map((_, i) => <ProductCardSkeleton key={i} />)
            : latestProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onNavigate={(slug) => onNavigate(`/product/${slug}`)}
                />
              ))}
        </div>
      </section>

      {/* 6. Popular / Best Sellers */}
      {popularProducts.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6 sm:mb-8">
            <div>
              <div className="flex items-center gap-2 text-amber-600 font-semibold text-xs uppercase tracking-wider mb-1">
                <TrendingUp className="w-4 h-4" />
                <span>Customer Favorites</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
                Trending & Popular
              </h2>
            </div>
            <button
              onClick={() => onNavigate('/products?popular=true')}
              className="group flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-700 transition-colors"
            >
              <span>Explore All</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
            {loading
              ? Array.from({ length: 4 }).map((_, i) => <ProductCardSkeleton key={i} />)
              : popularProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onNavigate={(slug) => onNavigate(`/product/${slug}`)}
                  />
                ))}
          </div>
        </section>
      )}

      {/* 7. Bottom Advertisement Banner Section */}
      {bottomBanner && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <PromoBanner
            banner={bottomBanner}
            onNavigate={(url) => onNavigate(url)}
          />
        </section>
      )}
    </div>
  );
};
