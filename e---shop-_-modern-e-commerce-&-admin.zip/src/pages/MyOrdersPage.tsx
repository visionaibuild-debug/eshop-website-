import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getUserOrders } from '../firebase/services';
import { Order, OrderStatus } from '../types';
import { EmptyState } from '../components/EmptyState';
import { Package, ChevronRight, Clock, AlertCircle } from 'lucide-react';

interface MyOrdersPageProps {
  onNavigate: (path: string) => void;
}

export const MyOrdersPage: React.FC<MyOrdersPageProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadOrders() {
      if (!user) {
        setLoading(false);
        return;
      }
      try {
        const userOrders = await getUserOrders(user.uid);
        if (isMounted) {
          setOrders(userOrders || []);
        }
      } catch (err) {
        console.error('Failed to load user orders:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadOrders();

    return () => {
      isMounted = false;
    };
  }, [user]);

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Sign In to View Orders</h2>
        <p className="text-slate-500 text-sm mb-6">
          Track active orders, view receipts, and review past purchases.
        </p>
        <button
          onClick={() => onNavigate('/login')}
          className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white font-semibold text-sm hover:bg-indigo-700"
        >
          Sign In
        </button>
      </div>
    );
  }

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'Delivered':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Shipped':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'Processing':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Confirmed':
        return 'bg-violet-50 text-violet-700 border-violet-200';
      case 'Cancelled':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-amber-50 text-amber-700 border-amber-200';
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="pb-6 border-b border-slate-200 mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          My Orders
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Track and review your recent store purchases
        </p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-32 bg-slate-100 rounded-3xl animate-pulse" />
          ))}
        </div>
      ) : orders.length === 0 ? (
        <EmptyState
          icon={Package}
          title="No Orders Found"
          description="You haven't placed any orders yet. Discover our premium gear and place your first order today!"
          actionText="Start Shopping"
          onAction={() => onNavigate('/products')}
        />
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div
              key={order.id}
              onClick={() => onNavigate(`/order/${order.id}`)}
              className="group bg-white p-5 sm:p-6 rounded-3xl border border-slate-100 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-6"
            >
              {/* Order Info */}
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-sm sm:text-base font-extrabold text-slate-900">
                    #{order.orderNumber}
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${getStatusBadge(
                      order.orderStatus
                    )}`}
                  >
                    {order.orderStatus}
                  </span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <div className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{new Date(order.createdAt).toLocaleDateString()}</span>
                  </div>
                  <span>•</span>
                  <span>{order.paymentMethod}</span>
                  <span>•</span>
                  <span>{order.items.length} {order.items.length === 1 ? 'item' : 'items'}</span>
                </div>

                {/* Thumbnail Previews */}
                <div className="flex items-center gap-2 pt-1">
                  {order.items.slice(0, 4).map((item, idx) => (
                    <img
                      key={idx}
                      src={item.image}
                      alt={item.name}
                      className="w-10 h-10 rounded-lg object-cover border border-slate-100"
                    />
                  ))}
                  {order.items.length > 4 && (
                    <span className="w-10 h-10 rounded-lg bg-slate-50 border border-slate-100 text-xs font-bold text-slate-500 flex items-center justify-center">
                      +{order.items.length - 4}
                    </span>
                  )}
                </div>
              </div>

              {/* Price & Action */}
              <div className="flex items-center justify-between md:flex-col md:items-end gap-2 pt-4 md:pt-0 border-t md:border-t-0 border-slate-100">
                <div className="text-left md:text-right">
                  <p className="text-xs text-slate-400">Total Price</p>
                  <p className="text-lg font-extrabold text-slate-900">
                    ${order.totalAmount.toFixed(2)}
                  </p>
                </div>

                <div className="flex items-center gap-1 text-xs font-bold text-indigo-600 group-hover:translate-x-1 transition-transform">
                  <span>View Order Details</span>
                  <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
