import React, { useState, useEffect } from 'react';
import { getOrderById } from '../firebase/services';
import { Order, OrderStatus } from '../types';
import { EmptyState } from '../components/EmptyState';
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Truck,
  PackageCheck,
  Ban,
  MapPin,
  CreditCard,
} from 'lucide-react';

interface OrderDetailsPageProps {
  orderId: string;
  onNavigate: (path: string) => void;
}

export const OrderDetailsPage: React.FC<OrderDetailsPageProps> = ({ orderId, onNavigate }) => {
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    async function loadOrder() {
      try {
        const res = await getOrderById(orderId);
        if (isMounted) setOrder(res);
      } catch (err) {
        console.error('Error fetching order:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    loadOrder();
    return () => {
      isMounted = false;
    };
  }, [orderId]);

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 animate-pulse space-y-6">
        <div className="h-8 bg-slate-200 rounded w-1/3" />
        <div className="h-32 bg-slate-200 rounded-3xl" />
        <div className="h-64 bg-slate-200 rounded-3xl" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <EmptyState
          title="Order Not Found"
          description="We couldn't locate this order in our system. It may have been placed under another account or ID."
          actionText="Go to My Orders"
          onAction={() => onNavigate('/orders')}
        />
      </div>
    );
  }

  // Order Stepper calculation
  const statusSteps: OrderStatus[] = ['Pending', 'Confirmed', 'Processing', 'Shipped', 'Delivered'];
  const currentIndex = statusSteps.indexOf(order.orderStatus);
  const isCancelled = order.orderStatus === 'Cancelled';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Top bar */}
      <div className="flex items-center justify-between pb-6 border-b border-slate-200 mb-8">
        <button
          onClick={() => onNavigate('/orders')}
          className="inline-flex items-center gap-2 text-xs font-bold text-indigo-600 hover:text-indigo-800"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to All Orders</span>
        </button>

        <span className="text-xs text-slate-400 font-medium">
          Placed on {new Date(order.createdAt).toLocaleDateString()}
        </span>
      </div>

      {/* Header Info Card */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-100 shadow-sm mb-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Order Reference
            </span>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono mt-0.5">
              #{order.orderNumber}
            </h1>
          </div>

          <div className="text-left sm:text-right">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Total Amount
            </span>
            <span className="text-2xl font-extrabold text-slate-900">
              ${order.totalAmount.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Progress Timeline Stepper */}
        {isCancelled ? (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 flex items-center gap-3 text-rose-700 text-sm font-semibold">
            <Ban className="w-5 h-5 shrink-0" />
            <span>This order was cancelled. Please contact customer care for any questions.</span>
          </div>
        ) : (
          <div className="pt-4 border-t border-slate-100">
            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-6">
              Delivery Tracker
            </p>
            <div className="grid grid-cols-5 gap-2 relative">
              {statusSteps.map((step, idx) => {
                const isPassed = idx <= currentIndex;
                const isCurrent = idx === currentIndex;

                return (
                  <div key={step} className="flex flex-col items-center text-center">
                    <div
                      className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all mb-2 shadow-xs ${
                        isPassed
                          ? 'bg-indigo-600 text-white shadow-indigo-200'
                          : 'bg-slate-100 text-slate-400'
                      } ${isCurrent ? 'ring-4 ring-indigo-100' : ''}`}
                    >
                      {isPassed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                    </div>
                    <span
                      className={`text-[11px] leading-tight ${
                        isCurrent
                          ? 'font-bold text-indigo-600'
                          : isPassed
                          ? 'font-medium text-slate-800'
                          : 'text-slate-400'
                      }`}
                    >
                      {step}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Two Column Layout: Order items & Customer info */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Left: Ordered Items */}
        <div className="md:col-span-2 bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
            Items Ordered ({order.items.length})
          </h2>

          <div className="divide-y divide-slate-100">
            {order.items.map((item, idx) => {
              const unit = item.discountPrice ?? item.price;
              return (
                <div key={idx} className="py-3 flex items-center justify-between gap-4">
                  <div
                    onClick={() => onNavigate(`/product/${item.slug}`)}
                    className="flex items-center gap-3 cursor-pointer group"
                  >
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-14 h-14 rounded-xl object-cover border border-slate-100 shrink-0"
                    />
                    <div>
                      <h4 className="text-xs sm:text-sm font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1">
                        {item.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Qty: {item.quantity} × ${unit.toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <span className="text-sm font-bold text-slate-900">
                    ${(unit * item.quantity).toFixed(2)}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="border-t border-slate-100 pt-4 space-y-2 text-xs text-slate-600">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>${order.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Shipping Fee</span>
              <span>{order.shippingFee === 0 ? 'FREE' : `$${order.shippingFee.toFixed(2)}`}</span>
            </div>
            <div className="flex justify-between text-base font-extrabold text-slate-900 pt-2 border-t border-slate-100">
              <span>Grand Total</span>
              <span>${order.totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Right: Shipping & Payment summary */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm border-b border-slate-100 pb-3">
              <MapPin className="w-4 h-4 text-indigo-600" />
              <span>Shipping Address</span>
            </div>
            <div className="text-xs text-slate-600 space-y-1">
              <p className="font-bold text-slate-800 text-sm">{order.customerName}</p>
              <p>{order.customerPhone}</p>
              <p>{order.customerEmail}</p>
              <p className="pt-2">{order.shippingAddress}</p>
              <p>
                {order.area}, {order.city}
              </p>
              {order.deliveryNotes && (
                <p className="pt-2 italic text-slate-400">
                  Note: &ldquo;{order.deliveryNotes}&rdquo;
                </p>
              )}
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-sm border-b border-slate-100 pb-3">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              <span>Payment Details</span>
            </div>
            <div className="text-xs text-slate-600 space-y-2">
              <div className="flex justify-between">
                <span>Method:</span>
                <span className="font-semibold text-slate-800">{order.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <span className="font-bold text-emerald-600">{order.paymentStatus}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
