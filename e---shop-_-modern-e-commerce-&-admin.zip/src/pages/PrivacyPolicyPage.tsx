import React from 'react';

export const PrivacyPolicyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-100 shadow-sm space-y-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Legal</span>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Privacy Policy
          </h1>
          <p className="text-xs text-slate-400 mt-1">Effective Date: October 2, 2026</p>
        </div>

        <div className="prose prose-slate max-w-none text-sm leading-relaxed space-y-6 text-slate-600">
          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">1. Information We Collect</h3>
            <p>
              When you purchase or register on E - SHOP, we collect information including your name, email address, phone number, shipping address, and order history. We utilize industry-standard Google Firebase authentication and Cloud Firestore storage.
            </p>
          </section>

          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">2. How We Use Your Data</h3>
            <p>
              Your information is exclusively utilized to process, dispatch, and track your purchases, verify transactions, send updates regarding shipments, and enhance your digital shopping experience. We never sell your personal data to third parties.
            </p>
          </section>

          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">3. Data Security & Storage</h3>
            <p>
              All interactions are secured through 256-bit SSL encryption. Role-based security rules restrict access to user records and order information strictly to the verified account owner and authorized administrators.
            </p>
          </section>

          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">4. Your Privacy Rights</h3>
            <p>
              You have the right to inspect, update, or request the erasure of your personal data at any time through your Profile Dashboard or by contacting our Data Protection Officer at privacy@e-shop.com.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
