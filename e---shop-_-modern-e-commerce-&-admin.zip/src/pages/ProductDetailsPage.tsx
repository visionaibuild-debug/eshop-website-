import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { getProductBySlug, getProducts } from '../firebase/services';
import { useCart } from '../contexts/CartContext';
import { ProductCard } from '../components/ProductCard';
import { EmptyState } from '../components/EmptyState';
import {
  ShoppingCart,
  Zap,
  Check,
  ShieldCheck,
  Truck,
  RotateCcw,
  Share2,
  Tag,
  Package,
  Heart,
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import { useWishlist } from '../contexts/WishlistContext';

interface ProductDetailsPageProps {
  slug: string;
  onNavigate: (path: string) => void;
}

export const ProductDetailsPage: React.FC<ProductDetailsPageProps> = ({ slug, onNavigate }) => {
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'description' | 'specifications'>('description');
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const { addToCart, items } = useCart();
  const { isInWishlist, toggleWishlist } = useWishlist();
  const { showToast } = useToast();

  useEffect(() => {
    let isMounted = true;
    async function loadProduct() {
      setLoading(true);
      try {
        const prod = await getProductBySlug(slug);
        if (isMounted) {
          if (prod) {
            setProduct(prod);
            setSelectedImage(prod.mainImage);
            setQuantity(1);

            // Fetch related products in same category
            const related = await getProducts({ category: prod.category, limitCount: 5 });
            if (isMounted) {
              setRelatedProducts(related.filter((r) => r.id !== prod.id).slice(0, 4));
            }
          } else {
            setProduct(null);
          }
        }
      } catch (err) {
        console.error('Failed to load product details:', err);
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    loadProduct();

    return () => {
      isMounted = false;
    };
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-pulse">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="aspect-square bg-slate-200 rounded-3xl" />
          <div className="space-y-4">
            <div className="h-6 bg-slate-200 rounded w-1/4" />
            <div className="h-10 bg-slate-200 rounded w-3/4" />
            <div className="h-8 bg-slate-200 rounded w-1/3" />
            <div className="h-24 bg-slate-200 rounded" />
            <div className="h-12 bg-slate-200 rounded w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <EmptyState
          title="Product Not Found"
          description="The product you are looking for might have been moved or removed from our catalog."
          actionText="Browse Catalog"
          onAction={() => onNavigate('/products')}
        />
      </div>
    );
  }

  const allImages = [product.mainImage, ...(product.images || [])].filter(
    (img, idx, arr) => img && arr.indexOf(img) === idx
  );

  const cartItem = items.find((i) => i.product.id === product.id);
  const currentInCart = cartItem ? cartItem.quantity : 0;
  const isOutOfStock = product.stock <= 0;
  const maxAvailableToAdd = Math.max(0, product.stock - currentInCart);

  const discountPercentage = product.discountPrice
    ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
    : 0;

  const handleAddToCart = () => {
    if (isOutOfStock || quantity > maxAvailableToAdd) return;
    addToCart(product, quantity);
  };

  const handleBuyNow = () => {
    if (isOutOfStock) return;
    const success = addToCart(product, quantity);
    if (success) {
      onNavigate('/checkout');
    }
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setIsCopied(true);
      showToast('Product link copied to clipboard!', 'info');
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-xs text-slate-500 mb-6 font-medium">
        <button onClick={() => onNavigate('/')} className="hover:text-indigo-600 transition-colors">
          Home
        </button>
        <span>/</span>
        <button
          onClick={() => onNavigate(`/products?category=${encodeURIComponent(product.category)}`)}
          className="hover:text-indigo-600 transition-colors"
        >
          {product.category}
        </button>
        <span>/</span>
        <span className="text-slate-900 truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main Product Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-14">
        {/* Left Column: Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square w-full rounded-3xl overflow-hidden bg-white border border-slate-100 shadow-sm group">
            <img
              src={selectedImage || product.mainImage}
              alt={product.name}
              className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
            />
            {discountPercentage > 0 && (
              <div className="absolute top-4 left-4 px-3 py-1 rounded-xl bg-rose-600 text-white font-bold text-xs tracking-wider uppercase shadow-md">
                Save {discountPercentage}%
              </div>
            )}
            {isOutOfStock && (
              <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center">
                <span className="px-4 py-2 rounded-2xl bg-rose-600 text-white font-bold text-sm tracking-wider uppercase">
                  Out of Stock
                </span>
              </div>
            )}
          </div>

          {/* Thumbnails */}
          {allImages.length > 1 && (
            <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-none">
              {allImages.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedImage(img)}
                  className={`relative w-20 h-20 rounded-2xl overflow-hidden shrink-0 border-2 transition-all ${
                    selectedImage === img
                      ? 'border-indigo-600 shadow-md ring-2 ring-indigo-100'
                      : 'border-transparent hover:border-slate-300'
                  }`}
                >
                  <img
                    src={img}
                    alt={`${product.name} preview ${i + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Product Info & Buy Box */}
        <div className="flex flex-col">
          <div className="flex items-center justify-between gap-4 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">
              {product.brand}
            </span>
            <button
              onClick={handleShare}
              className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 transition-colors"
              title="Share product"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mb-4">
            {product.name}
          </h1>

          {/* SKU & Category & Stock */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 mb-6 pb-6 border-b border-slate-100">
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-slate-700">SKU:</span>
              <span className="font-mono">{product.sku}</span>
            </div>
            <span>•</span>
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-slate-700">Category:</span>
              <span>{product.category}</span>
            </div>
            <span>•</span>
            <div>
              {product.stock > 0 ? (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  {product.stock} in stock
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-700 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  Out of stock
                </span>
              )}
            </div>
          </div>

          {/* Price Section */}
          <div className="mb-6">
            <div className="flex items-baseline gap-3">
              <span className="text-3xl sm:text-4xl font-extrabold text-slate-900">
                ${(product.discountPrice ?? product.price).toFixed(2)}
              </span>
              {product.discountPrice && (
                <span className="text-lg sm:text-xl text-slate-400 line-through">
                  ${product.price.toFixed(2)}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1">Tax included. Free shipping on orders over $150.</p>
          </div>

          {/* Short description */}
          {product.shortDescription && (
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              {product.shortDescription}
            </p>
          )}

          {/* Quantity & CTA Buttons */}
          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                Quantity
              </span>
              <div className="flex items-center border border-slate-200 rounded-xl bg-white shadow-xs">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  disabled={quantity <= 1 || isOutOfStock}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 font-bold disabled:opacity-40"
                >
                  -
                </button>
                <span className="px-4 py-1.5 text-sm font-semibold text-slate-900 min-w-[36px] text-center">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                  disabled={quantity >= product.stock || isOutOfStock}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 font-bold disabled:opacity-40"
                >
                  +
                </button>
              </div>
              {currentInCart > 0 && (
                <span className="text-xs text-indigo-600 font-medium">
                  ({currentInCart} already in your cart)
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                onClick={handleAddToCart}
                disabled={isOutOfStock || maxAvailableToAdd <= 0}
                className="w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all shadow-md shadow-indigo-100 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed active:scale-98"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>{isOutOfStock ? 'Out of Stock' : 'Add to Cart'}</span>
              </button>

              <button
                onClick={handleBuyNow}
                disabled={isOutOfStock}
                className="w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm transition-all shadow-md shadow-slate-200 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed active:scale-98"
              >
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Buy It Now</span>
              </button>
            </div>

            {/* Wishlist & Share Actions */}
            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => toggleWishlist(product)}
                className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-semibold transition-all active:scale-95 ${
                  isInWishlist(product.id)
                    ? 'bg-rose-50 border-rose-200 text-rose-600 shadow-xs'
                    : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Heart className={`w-4 h-4 ${isInWishlist(product.id) ? 'fill-rose-500 text-rose-500' : 'text-slate-500'}`} />
                <span>{isInWishlist(product.id) ? 'Saved in Wishlist' : 'Add to Wishlist'}</span>
              </button>

              <button
                type="button"
                onClick={handleShare}
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-all"
              >
                <Share2 className="w-4 h-4 text-slate-500" />
                <span>{isCopied ? 'Link Copied!' : 'Share Product'}</span>
              </button>
            </div>
          </div>

          {/* Trust Guarantees */}
          <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs text-slate-600 mt-auto">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>Fast Express Dispatch</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>Authentic Guarantee</span>
            </div>
            <div className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>30-Day Free Return</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs: Full Description & Specifications */}
      <div className="mt-16 border-t border-slate-200 pt-10">
        <div className="flex items-center gap-6 border-b border-slate-200 pb-4 mb-6">
          <button
            onClick={() => setActiveTab('description')}
            className={`text-base font-bold pb-2 transition-all relative ${
              activeTab === 'description'
                ? 'text-indigo-600'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Product Overview
            {activeTab === 'description' && (
              <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-600" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('specifications')}
            className={`text-base font-bold pb-2 transition-all relative ${
              activeTab === 'specifications'
                ? 'text-indigo-600'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            Specifications & Details
            {activeTab === 'specifications' && (
              <span className="absolute bottom-[-17px] left-0 right-0 h-0.5 bg-indigo-600" />
            )}
          </button>
        </div>

        {activeTab === 'description' ? (
          <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed text-sm sm:text-base space-y-4">
            <p>{product.description}</p>
            {product.tags && product.tags.length > 0 && (
              <div className="flex items-center gap-2 pt-4 flex-wrap">
                <Tag className="w-4 h-4 text-slate-400" />
                {product.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-600 text-xs font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl text-sm">
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Brand</span>
              <span className="font-semibold text-slate-800">{product.brand}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">SKU Code</span>
              <span className="font-mono text-slate-800">{product.sku}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Category</span>
              <span className="font-semibold text-slate-800">{product.category}</span>
            </div>
            {product.subcategory && (
              <div className="flex justify-between py-2 border-b border-slate-100">
                <span className="text-slate-500">Subcategory</span>
                <span className="font-semibold text-slate-800">{product.subcategory}</span>
              </div>
            )}
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Stock Availability</span>
              <span className="font-semibold text-slate-800">{product.stock} units</span>
            </div>
            <div className="flex justify-between py-2 border-b border-slate-100">
              <span className="text-slate-500">Listing Status</span>
              <span className="font-semibold text-slate-800">
                {product.isPublished ? 'Published & Active' : 'Draft'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <div className="mt-20 border-t border-slate-200 pt-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6 tracking-tight">
            You Might Also Like
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {relatedProducts.map((rel) => (
              <ProductCard
                key={rel.id}
                product={rel}
                onNavigate={(slug) => onNavigate(`/product/${slug}`)}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
