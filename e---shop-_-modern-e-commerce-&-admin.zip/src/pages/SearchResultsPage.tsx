import React, { useState, useEffect } from 'react';
import { Search, Filter, X, Layers } from 'lucide-react';
import { ProductsPage } from './ProductsPage';
import { getCategories } from '../firebase/services';
import { Category } from '../types';

interface SearchResultsPageProps {
  query: string;
  initialCategory?: string;
  onNavigate: (path: string) => void;
}

export const SearchResultsPage: React.FC<SearchResultsPageProps> = ({
  query,
  initialCategory = 'All',
  onNavigate,
}) => {
  const [searchTerm, setSearchTerm] = useState(query);
  const [category, setCategory] = useState(initialCategory || 'All');
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    setSearchTerm(query);
  }, [query]);

  useEffect(() => {
    if (initialCategory) setCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    let isMounted = true;
    getCategories()
      .then((cats) => {
        if (isMounted) setCategories(cats || []);
      })
      .catch(() => {});
    return () => {
      isMounted = false;
    };
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      onNavigate(`/search?q=${encodeURIComponent(searchTerm.trim())}&category=${encodeURIComponent(category)}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Header with Real-Time Filtering Controls */}
      <div className="bg-white border-b border-slate-200/80 py-8 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                Product Search & Filter
              </p>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {searchTerm.trim() ? (
                  <>
                    Results for &ldquo;<span className="text-indigo-600">{searchTerm}</span>&rdquo;
                  </>
                ) : (
                  'Browse Products'
                )}
                {category !== 'All' && (
                  <span className="text-slate-500 font-normal text-lg sm:text-xl ml-2">
                    in {category}
                  </span>
                )}
              </h1>
            </div>
          </div>

          {/* Real-time search & Category bar */}
          <form
            onSubmit={handleSearchSubmit}
            className="flex flex-col sm:flex-row items-stretch gap-2.5 max-w-3xl"
          >
            {/* Category Dropdown */}
            <div className="relative sm:w-56 shrink-0">
              <select
                value={category}
                onChange={(e) => {
                  const newCat = e.target.value;
                  setCategory(newCat);
                  onNavigate(`/search?q=${encodeURIComponent(searchTerm.trim())}&category=${encodeURIComponent(newCat)}`);
                }}
                className="w-full h-11 pl-9 pr-8 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 outline-none focus:border-indigo-500 focus:bg-white appearance-none transition-colors"
              >
                <option value="All">All Categories</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
              <Layers className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
                ▼
              </div>
            </div>

            {/* Keyword Input */}
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Search products by title, brand, or tag..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full h-11 pl-10 pr-10 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 outline-none focus:border-indigo-500 focus:bg-white transition-colors"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="p-1 text-slate-400 hover:text-slate-600 absolute right-3 top-1/2 -translate-y-1/2"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <button
              type="submit"
              className="h-11 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-all shadow-sm active:scale-95 shrink-0"
            >
              Search
            </button>
          </form>
        </div>
      </div>

      <ProductsPage
        initialSearch={searchTerm}
        initialCategory={category === 'All' ? undefined : category}
        onNavigate={onNavigate}
      />
    </div>
  );
};
