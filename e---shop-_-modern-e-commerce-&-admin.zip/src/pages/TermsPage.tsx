import React from 'react';

export const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16">
      <div className="bg-white p-8 sm:p-12 rounded-3xl border border-slate-100 shadow-sm space-y-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Legal</span>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Terms & Conditions
          </h1>
          <p className="text-xs text-slate-400 mt-1">Last Updated: October 2, 2026</p>
        </div>

        <div className="prose prose-slate max-w-none text-sm leading-relaxed space-y-6 text-slate-600">
          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">1. Agreement to Terms</h3>
            <p>
              By accessing, browsing, or purchasing items from E - SHOP, you agree to be legally bound by these Terms and Conditions and our Privacy Policy. If you do not agree, please discontinue use immediately.
            </p>
          </section>

          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">2. Products, Pricing & Availability</h3>
            <p>
              All products listed are subject to real-time inventory availability. While we make every attempt to ensure pricing and descriptions are exact, E - SHOP reserves the right to correct typographical errors or revise pricing prior to order dispatch.
            </p>
          </section>

          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">3. Orders & Payment</h3>
            <p>
              An order is confirmed upon receipt of our order reference number. Payment methods include Cash on Delivery, Mobile Banking, and supported cards. We reserve the right to cancel any order suspected of fraudulent conduct.
            </p>
          </section>

          <section>
            <h3 className="text-base font-bold text-slate-900 mb-2">4. 30-Day Returns & Warranty</h3>
            <p>
              Unused items in their original undamaged packaging may be returned within 30 days of delivery. Manufacturer defects are covered under standard device warranty terms.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
};
