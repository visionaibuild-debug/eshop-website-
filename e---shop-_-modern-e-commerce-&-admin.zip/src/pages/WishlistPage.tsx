import React, { useState } from 'react';
import { Heart, ShoppingCart, Trash2, ArrowRight, Package, Check, Sparkles, AlertCircle } from 'lucide-react';
import { useWishlist } from '../contexts/WishlistContext';
import { useCart } from '../contexts/CartContext';
import { useToast } from '../contexts/ToastContext';
import { Product } from '../types';

interface WishlistPageProps {
  onNavigate: (path: string) => void;
}

export const WishlistPage: React.FC<WishlistPageProps> = ({ onNavigate }) => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { showToast } = useToast();
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [addedItems, setAddedItems] = useState<{ [id: string]: boolean }>({});

  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      showToast('This product is currently out of stock.', 'warning');
      return;
    }

    const success = addToCart(product, 1);
    if (success) {
      setAddedItems((prev) => ({ ...prev, [product.id]: true }));
      setTimeout(() => {
        setAddedItems((prev) => ({ ...prev, [product.id]: false }));
      }, 1500);
      showToast(`Added "${product.name}" to your cart!`, 'success');
    }
  };

  const handleAddAllToCart = () => {
    let addedCount = 0;
    wishlist.forEach((product) => {
      if (product.stock > 0) {
        addToCart(product, 1);
        addedCount++;
      }
    });

    if (addedCount > 0) {
      showToast(`Moved ${addedCount} available item(s) to your cart!`, 'success');
      onNavigate('/cart');
    } else {
      showToast('None of the items in your wishlist are in stock.', 'warning');
    }
  };

  if (wishlist.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="max-w-md mx-auto text-center space-y-6">
          <div className="w-20 h-20 rounded-3xl bg-rose-50 text-rose-500 flex items-center justify-center mx-auto shadow-sm">
            <Heart className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Your Wishlist is Empty
            </h1>
            <p className="text-slate-500 text-sm leading-relaxed">
              Explore our curated catalog and tap the heart icon on any product to save it here for later.
            </p>
          </div>

          <div>
            <button
              onClick={() => onNavigate('/products')}
              className="inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md shadow-indigo-200 transition-all active:scale-95"
            >
              <span>Explore Products</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 text-rose-600 font-semibold text-xs uppercase tracking-wider mb-1">
            <Heart className="w-4 h-4 fill-rose-600" />
            <span>Saved Items</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            My Wishlist ({wishlist.length})
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Keep track of products you love and quickly move them to your shopping cart.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleAddAllToCart}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-md shadow-indigo-100 transition-all active:scale-95"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Add All to Cart</span>
          </button>

          <button
            onClick={() => setShowClearConfirm(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-200 hover:border-rose-200 text-slate-600 hover:text-rose-600 hover:bg-rose-50 text-xs font-semibold transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear All</span>
          </button>
        </div>
      </div>

      {/* Wishlist Items Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {wishlist.map((product) => {
          const discountPercentage = product.discountPrice
            ? Math.round(((product.price - product.discountPrice) / product.price) * 100)
            : 0;
          const isOutOfStock = product.stock <= 0;
          const isRecentlyAdded = addedItems[product.id];

          return (
            <div
              key={product.id}
              className="group bg-white rounded-2xl border border-slate-200/80 p-3 sm:p-4 shadow-xs hover:shadow-xl hover:border-indigo-100 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Image Container with Badges */}
                <div
                  onClick={() => onNavigate(`/product/${product.slug}`)}
                  className="relative aspect-square w-full rounded-xl overflow-hidden bg-slate-50 mb-3 cursor-pointer"
                >
                  <img
                    src={product.mainImage}
                    alt={product.name}
                    loading="lazy"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                  />

                  {/* Discount Badge */}
                  {discountPercentage > 0 && (
                    <span className="absolute top-2 left-2 px-2 py-0.5 rounded-lg text-[10px] font-bold bg-rose-500 text-white shadow-xs">
                      -{discountPercentage}%
                    </span>
                  )}

                  {/* Stock Status Badge */}
                  {isOutOfStock ? (
                    <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center">
                      <span className="px-3 py-1 rounded-xl text-xs font-bold bg-rose-600 text-white tracking-wider uppercase">
                        Out of Stock
                      </span>
                    </div>
                  ) : product.stock <= 5 ? (
                    <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-amber-500 text-white">
                      Only {product.stock} left
                    </span>
                  ) : null}

                  {/* Remove Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeFromWishlist(product.id);
                    }}
                    title="Remove from wishlist"
                    className="absolute top-2 right-2 p-1.5 rounded-full bg-white/90 hover:bg-rose-50 text-slate-400 hover:text-rose-600 shadow-sm transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Details */}
                <div className="mb-2">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-0.5">
                    {product.category}
                  </span>
                  <h3
                    onClick={() => onNavigate(`/product/${product.slug}`)}
                    className="font-semibold text-slate-900 text-sm leading-snug line-clamp-2 hover:text-indigo-600 cursor-pointer transition-colors"
                  >
                    {product.name}
                  </h3>
                </div>
              </div>

              {/* Price & Add to Cart Action */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between mt-auto">
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-base font-bold text-slate-900">
                      ${((product.discountPrice ?? product.price) || 0).toFixed(2)}
                    </span>
                    {product.discountPrice && (
                      <span className="text-xs text-slate-400 line-through">
                        ${(product.price || 0).toFixed(2)}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => handleAddToCart(product)}
                  disabled={isOutOfStock}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 ${
                    isOutOfStock
                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      : isRecentlyAdded
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200'
                      : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm shadow-indigo-100'
                  }`}
                >
                  {isRecentlyAdded ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Added!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>Add to Cart</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-slate-100">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-rose-50 text-rose-600">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-base">Clear Wishlist?</h3>
                <p className="text-xs text-slate-500">
                  This will remove all {wishlist.length} saved products.
                </p>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-semibold hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  clearWishlist();
                  setShowClearConfirm(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow-md shadow-rose-200 transition-colors"
              >
                Confirm Clear
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
