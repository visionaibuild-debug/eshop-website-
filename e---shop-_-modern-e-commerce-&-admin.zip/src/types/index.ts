export type OrderStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Processing'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled';

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDescription: string;
  price: number;
  discountPrice?: number;
  stock: number;
  sku: string;
  category: string;
  subcategory?: string;
  brand: string;
  mainImage: string;
  images: string[];
  tags: string[];
  isPublished: boolean;
  isFeatured: boolean;
  isPopular: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  image?: string;
  isActive: boolean;
  productCount?: number;
  createdAt: string;
  updatedAt: string;
}

export type BannerPosition =
  | 'home_hero'
  | 'homepage_middle'
  | 'bottom_advertisement'
  | 'category_page'
  | 'product_page';

export interface Banner {
  id: string;
  title: string;
  subtitle?: string;
  image: string;
  buttonText?: string;
  destinationUrl?: string;
  position: BannerPosition;
  isActive: boolean;
  startDate?: string;
  endDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  slug: string;
  price: number;
  discountPrice?: number;
  quantity: number;
  image: string;
  sku: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string; // user uid or 'guest'
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  area: string;
  deliveryNotes?: string;
  items: OrderItem[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  totalAmount: number;
  paymentMethod: 'Cash on Delivery' | 'Credit/Debit Card' | 'Mobile Banking';
  paymentStatus: 'Pending' | 'Paid' | 'Failed';
  orderStatus: OrderStatus;
  createdAt: string;
  updatedAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName?: string;
  phone?: string;
  address?: string;
  city?: string;
  area?: string;
  role?: 'customer' | 'admin' | 'super_admin';
  createdAt?: string;
  updatedAt?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount: number;
  maxDiscount?: number;
  expiryDate: string;
  usageLimit?: number;
  usageCount: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  userId: string;
  userName: string;
  userEmail?: string;
  rating: number; // 1 to 5
  comment: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
}

export interface WebsiteSettings {
  storeName: string;
  logoUrl?: string;
  storePhone: string;
  storeEmail: string;
  address: string;
  currency: string;
  currencySymbol: string;
  shippingCharge: number;
  freeShippingThreshold: number;
  lowStockThreshold: number;
  socialLinks: {
    facebook?: string;
    twitter?: string;
    instagram?: string;
    youtube?: string;
    linkedin?: string;
  };
  updatedAt: string;
}

export interface CustomerSummary {
  uid: string;
  displayName: string;
  email: string;
  phone: string;
  registrationDate: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate?: string;
  city?: string;
  address?: string;
}

// ---------------- SOURCE MANAGER TYPES ----------------

export interface SourceFile {
  id: string;
  fileName: string;
  filePath: string;
  fileType: string;
  sourceCode: string;
  currentVersion: string;
  description: string;
  changeNotes?: string;
  lastModified: string;
  modifiedBy: string;
  isActive: boolean;
  isArchived?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SourceFileSnapshot {
  fileId: string;
  fileName: string;
  filePath: string;
  fileType: string;
  version: string;
  sourceCode: string;
}

export interface SourceVersion {
  id: string;
  versionNumber: string;
  releaseTitle: string;
  releaseNotes: string;
  changedFiles: SourceFileSnapshot[];
  createdDate: string;
  createdBy: string;
  status: 'Draft' | 'Active' | 'Archived';
  createdAt: string;
  updatedAt: string;
}

export type SourceAction = 'Added' | 'Updated' | 'Deleted' | 'Restored';

export interface SourceChangeLogEntry {
  id: string;
  date: string;
  version: string;
  file: string;
  action: SourceAction;
  changedBy: string;
  description: string;
  previousCode?: string;
  newCode?: string;
  createdAt: string;
}

export interface SourceImportRecord {
  id: string;
  importDate: string;
  importedBy: string;
  fileCount: number;
  files: Array<{
    fileName: string;
    filePath: string;
    fileType: string;
    sourceCode: string;
    version?: string;
  }>;
  status: 'Draft' | 'Confirmed' | 'Cancelled';
  createdAt: string;
}

export interface SourceManifest {
  projectName: string;
  exportVersion: string;
  exportDate: string;
  applicationVersion: string;
  includedFiles: string[];
  excludedFiles: string[];
  sourceManagerVersion: string;
}

